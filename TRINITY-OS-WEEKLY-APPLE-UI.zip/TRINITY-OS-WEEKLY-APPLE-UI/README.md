# TRINITY OS · Weekly Plan Apple-style UI patch

현재 GitHub `main`의 `WeeklyGoals.tsx` 구조를 기준으로 만든 UI 패치입니다.

## 변경 사항
- 거대한 Weekly 목표 카드 제거
- 문서형 goal list로 변경
- 상단 요약 strip: 목표 / 완료 / 진행 중 / Daily 연결
- `수정` 버튼 상시 노출 제거 → `…` 메뉴
- 진행 상태를 버튼이 아닌 badge로 변경
- 하단 상시 입력폼 제거
- `+ 추가` 클릭 시 우측 sheet editor 오픈
- sheet 안에서 해당 주의 Daily Plan 직접 연결 가능
- Weekly Execution 헤더/표도 더 얇고 정돈된 스타일로 재설계
- iPad/모바일/다크모드 대응

## 적용
TRINITY-OS 루트에 이 ZIP을 풀고:

```bash
bash APPLY_PATCH.sh
```

빌드 성공 후:

```bash
git add -A
git commit -m "ui: refine weekly plan"
git push origin main
```
