#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
if [ ! -f "$ROOT/package.json" ] || [ ! -d "$ROOT/src/pages" ]; then
  echo "❌ TRINITY-OS 루트에서 실행해 주세요."
  echo "예: cd /workspaces/TRINITY-OS && bash APPLY_PATCH.sh"
  exit 1
fi

PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_DIR="$ROOT/.patch-backup-weekly-ui-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR/src/pages" "$BACKUP_DIR/src"

for f in src/pages/WeeklyGoals.tsx src/main.tsx; do
  if [ -f "$ROOT/$f" ]; then
    mkdir -p "$BACKUP_DIR/$(dirname "$f")"
    cp "$ROOT/$f" "$BACKUP_DIR/$f"
  fi
done

cp "$PATCH_DIR/src/pages/WeeklyGoals.tsx" "$ROOT/src/pages/WeeklyGoals.tsx"
cp "$PATCH_DIR/src/weekly-plan-polish.css" "$ROOT/src/weekly-plan-polish.css"

# main.tsx는 전체 교체 대신 import 한 줄만 안전하게 추가한다.
python3 - "$ROOT/src/main.tsx" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text(encoding='utf-8-sig')
line="import './weekly-plan-polish.css';"
if line not in s:
    anchor="import './trinity-ui-v3.css';"
    if anchor not in s:
        raise SystemExit("❌ src/main.tsx에서 trinity-ui-v3.css import를 찾지 못했습니다.")
    s=s.replace(anchor, anchor+"\n"+line)
p.write_text(s,encoding='utf-8')
PY

echo "✅ Weekly Plan UI 파일 적용 완료"
echo "백업: $BACKUP_DIR"
echo
npm run build

echo
echo "===== 변경 파일 ====="
git status --short

echo
echo "✅ 빌드까지 완료했습니다. 확인 후 git add/commit/push 하세요."
