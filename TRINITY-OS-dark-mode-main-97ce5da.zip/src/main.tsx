import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
import './ordering.css';
import './auth.css';
import './timer-enhanced.css';
import './ui-polish.css';
import './ui-system.css';
import './teacher.css';
import './study-room.css'; 
import './theme.css';

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);

if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js'));
