#!/usr/bin/env python3
from pathlib import Path
import argparse
import shutil
import sys

def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 anchor, found {count}")
    return text.replace(old, new, 1)

def patch_file(root: Path, rel: str, fn):
    path = root / rel
    if not path.exists():
        raise FileNotFoundError(f"missing: {rel}")
    original = path.read_text(encoding="utf-8")
    updated = fn(original)
    if updated == original:
        raise RuntimeError(f"{rel}: no changes produced")
    backup = path.with_suffix(path.suffix + ".pre-core-wrong.bak")
    if not backup.exists():
        shutil.copy2(path, backup)
    path.write_text(updated, encoding="utf-8")
    print(f"patched {rel}")

def patch_archive_api(c: str) -> str:
    c = replace_once(
        c,
        "export type CoreRule={id:string;subject:ArchiveSubject;title:string;content:string;tags:string[];masteryStatus:MasteryStatus;usageCount:number};\n"
        "export type RuleLink={archiveEntryId:string;coreRuleId:string;relationType?:'derived'|'applied'|'failed'|'reinforced';createdAt?:string};",
        "export type RuleRelation='derived'|'applied'|'failed'|'reinforced';\n"
        "export type CoreRule={id:string;subject:ArchiveSubject;title:string;content:string;tags:string[];masteryStatus:MasteryStatus;usageCount:number;wrongAnswerCount?:number;relationType?:RuleRelation};\n"
        "export type RuleLink={archiveEntryId:string;coreRuleId:string;relationType?:RuleRelation;createdAt?:string};",
        "archiveApi RuleRelation",
    )
    c = replace_once(
        c,
        "export type WrongAnswerLink={archiveEntryId:string;wrongAnswerId:string;createdAt?:string};",
        "export type WrongAnswerLink={archiveEntryId:string;wrongAnswerId:string;createdAt?:string};\n"
        "export type CoreRuleWrongAnswerLink={coreRuleId:string;wrongAnswerId:string;relationType:RuleRelation;createdAt?:string};",
        "archiveApi direct link type",
    )
    c = replace_once(
        c,
        "wrongAnswerLinks:WrongAnswerLink[];coreRuleDrillLinks?:{coreRuleId:string;drillId:string;createdAt?:string}[];",
        "wrongAnswerLinks:WrongAnswerLink[];coreRuleWrongAnswerLinks?:CoreRuleWrongAnswerLink[];coreRuleDrillLinks?:{coreRuleId:string;drillId:string;createdAt?:string}[];",
        "archiveApi backup direct links",
    )
    return c

def patch_learning_intelligence(c: str) -> str:
    old = """async function targetOwned(env:Env,userId:number,type:string,id:string){if(type==='learning_item')return Boolean(await entryOwner(env.DB,id,userId));if(type==='core_rule')return Boolean(await ruleOwner(env.DB,id,userId));const app=await state(env,userId),rows=type==='wrong_answer'?app.wrongAnswerDrills:app.dailyDrills;return Array.isArray(rows)&&rows.some(v=>v&&typeof v==='object'&&(v as {id?:unknown}).id===id)}
"""
    new = old + """const relations=['derived','applied','failed','reinforced'];
async function ensureWrongAnswerLinks(db:D1Database,userId:number){
 await db.batch([
  db.prepare("CREATE TABLE IF NOT EXISTS core_rule_wrong_answer_links(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,core_rule_id TEXT NOT NULL REFERENCES core_rules(id) ON DELETE CASCADE,wrong_answer_id TEXT NOT NULL,relation_type TEXT NOT NULL DEFAULT 'failed',created_at TEXT NOT NULL,PRIMARY KEY(core_rule_id,wrong_answer_id))"),
  db.prepare("CREATE INDEX IF NOT EXISTS core_rule_wrong_answer_user_wrong ON core_rule_wrong_answer_links(user_id,wrong_answer_id)")
 ]);
 await db.prepare("INSERT OR IGNORE INTO core_rule_wrong_answer_links(user_id,core_rule_id,wrong_answer_id,relation_type,created_at) SELECT w.user_id,l.core_rule_id,w.wrong_answer_id,COALESCE(l.relation_type,'failed'),? FROM archive_wrong_answer_links w JOIN archive_entry_core_rules l ON l.archive_entry_id=w.archive_entry_id JOIN core_rules r ON r.id=l.core_rule_id WHERE w.user_id=? AND r.user_id=?").bind(new Date().toISOString(),userId,userId).run();
}
async function wrongOwned(env:Env,userId:number,id:string){
 if(await targetOwned(env,userId,'wrong_answer',id))return true;
 return Boolean(await env.DB.prepare('SELECT archive_entry_id FROM archive_wrong_answer_links WHERE user_id=? AND wrong_answer_id=? LIMIT 1').bind(userId,id).first());
}
const coreRuleDto=(r:Record<string,unknown>)=>({id:String(r.id),subject:r.subject,title:r.title,content:r.content,tags:parse<string[]>(String(r.tags_json??'[]'),[]),masteryStatus:r.mastery_status,usageCount:Number(r.usage_count??0),relationType:r.relation_type??'failed'});
"""
    c = replace_once(c, old, new, "learning intelligence helpers")

    old = """ const url=new URL(request.url),path=url.pathname;if(!path.startsWith('/api/learning-intelligence')&&!path.match(/^\\/api\\/core-rules\\/[^/]+\\/intelligence$/))return null;const out=(v:unknown,s=200)=>h.json(v,s,origin);if(!user)return out({error:'Unauthorized'},401);
"""
    new = old + " await ensureWrongAnswerLinks(env.DB,user.id);\n"
    c = replace_once(c, old, new, "learning intelligence ensure links")

    marker = """ const rule=path.match(/^\\/api\\/core-rules\\/([^/]+)\\/intelligence$/);if(rule&&request.method==='GET'){
"""
    wrong_get = """ const wrong=path.match(/^\\/api\\/learning-intelligence\\/wrong-answers\\/([^/]+)$/);if(wrong&&request.method==='GET'){
  const id=decodeURIComponent(wrong[1]),app=await state(env,user.id),rows=Array.isArray(app.wrongAnswerDrills)?app.wrongAnswerDrills:[],wrongAnswer=rows.find(v=>v&&typeof v==='object'&&String((v as {id?:unknown}).id)===id)??null;
  const linked=await env.DB.prepare('SELECT r.*,l.relation_type FROM core_rule_wrong_answer_links l JOIN core_rules r ON r.id=l.core_rule_id WHERE l.user_id=? AND l.wrong_answer_id=? AND r.user_id=? ORDER BY r.updated_at DESC').bind(user.id,id,user.id).all<Record<string,unknown>>();
  return out({wrongAnswer,coreRules:linked.results.map(coreRuleDto)})
 }
"""
    c = replace_once(c, marker, wrong_get + marker, "wrong answer intelligence GET")

    old_query = """env.DB.prepare('SELECT w.wrong_answer_id FROM archive_wrong_answer_links w JOIN archive_entry_core_rules l ON l.archive_entry_id=w.archive_entry_id WHERE l.core_rule_id=? AND w.user_id=?').bind(id,user.id).all<{wrong_answer_id:string}>()"""
    new_query = """env.DB.prepare('SELECT wrong_answer_id,relation_type FROM core_rule_wrong_answer_links WHERE core_rule_id=? AND user_id=?').bind(id,user.id).all<{wrong_answer_id:string;relation_type:string}>()"""
    c = replace_once(c, old_query, new_query, "core rule direct wrong answers")

    marker = """ if(path==='/api/learning-intelligence/drill-links'&&request.method==='POST'){"""
    direct_api = """ if(path==='/api/learning-intelligence/wrong-answer-links'&&request.method==='POST'){
  const b=await h.boundedJson<Record<string,unknown>>(request),ruleId=clean(b.coreRuleId,80),wrongId=clean(b.wrongAnswerId,100),relation=clean(b.relationType,20)||'failed';
  if(!relations.includes(relation))return out({error:'Invalid relation type'},400);
  if(!await ruleOwner(env.DB,ruleId,user.id)||!await wrongOwned(env,user.id,wrongId))return out({error:'Not found'},404);
  await env.DB.prepare('INSERT INTO core_rule_wrong_answer_links(user_id,core_rule_id,wrong_answer_id,relation_type,created_at) VALUES(?,?,?,?,?) ON CONFLICT(core_rule_id,wrong_answer_id) DO UPDATE SET relation_type=excluded.relation_type').bind(user.id,ruleId,wrongId,relation,new Date().toISOString()).run();
  return out({ok:true},201)
 }
 const wrongRuleLink=path.match(/^\\/api\\/learning-intelligence\\/wrong-answer-links\\/([^/]+)\\/([^/]+)$/);if(wrongRuleLink&&request.method==='DELETE'){
  const ruleId=decodeURIComponent(wrongRuleLink[1]),wrongId=decodeURIComponent(wrongRuleLink[2]);if(!await ruleOwner(env.DB,ruleId,user.id))return out({error:'Not found'},404);
  await env.DB.prepare('DELETE FROM core_rule_wrong_answer_links WHERE user_id=? AND core_rule_id=? AND wrong_answer_id=?').bind(user.id,ruleId,wrongId).run();return out({ok:true})
 }
"""
    c = replace_once(c, marker, direct_api + marker, "wrong answer link APIs")
    return c

def patch_archive(c: str) -> str:
    c = replace_once(
        c,
        "const ruleOut=(r:Record<string,unknown>)=>({id:r.id,subject:r.subject,title:r.title,content:r.content,tags:parseJson(r.tags_json),masteryStatus:r.mastery_status,usageCount:Number(r.usage_count??0),createdAt:r.created_at,updatedAt:r.updated_at});",
        "const ruleOut=(r:Record<string,unknown>)=>({id:r.id,subject:r.subject,title:r.title,content:r.content,tags:parseJson(r.tags_json),masteryStatus:r.mastery_status,usageCount:Number(r.usage_count??0),wrongAnswerCount:Number(r.wrong_answer_count??0),relationType:r.relation_type??undefined,createdAt:r.created_at,updatedAt:r.updated_at});",
        "archive ruleOut relation",
    )

    c = replace_once(
        c,
        "const [entries,annotations,rules,links,reviews,wrong,settings,drillLinks,learningReviews]=await Promise.all([",
        "const [entries,annotations,rules,links,reviews,wrong,settings,drillLinks,wrongRuleLinks,learningReviews]=await Promise.all([",
        "archive export destructure",
    )
    c = replace_once(
        c,
        "  db.prepare('SELECT * FROM core_rule_drill_links WHERE user_id=? ORDER BY core_rule_id,drill_id').bind(userId).all<Record<string,unknown>>(),\n"
        "  db.prepare('SELECT * FROM learning_reviews WHERE user_id=? ORDER BY id').bind(userId).all<Record<string,unknown>>()",
        "  db.prepare('SELECT * FROM core_rule_drill_links WHERE user_id=? ORDER BY core_rule_id,drill_id').bind(userId).all<Record<string,unknown>>(),\n"
        "  db.prepare('SELECT * FROM core_rule_wrong_answer_links WHERE user_id=? ORDER BY core_rule_id,wrong_answer_id').bind(userId).all<Record<string,unknown>>(),\n"
        "  db.prepare('SELECT * FROM learning_reviews WHERE user_id=? ORDER BY id').bind(userId).all<Record<string,unknown>>()",
        "archive export query",
    )
    c = replace_once(
        c,
        "wrongAnswerLinks:wrong.results.map(r=>({archiveEntryId:r.archive_entry_id,wrongAnswerId:r.wrong_answer_id,createdAt:r.created_at})),coreRuleDrillLinks:drillLinks.results.map",
        "wrongAnswerLinks:wrong.results.map(r=>({archiveEntryId:r.archive_entry_id,wrongAnswerId:r.wrong_answer_id,createdAt:r.created_at})),coreRuleWrongAnswerLinks:wrongRuleLinks.results.map(r=>({coreRuleId:r.core_rule_id,wrongAnswerId:r.wrong_answer_id,relationType:r.relation_type??'failed',createdAt:r.created_at})),coreRuleDrillLinks:drillLinks.results.map",
        "archive export payload",
    )

    old = "const entries=arrayOf(source.entries,300),annotations=arrayOf(source.annotations,2000),rules=arrayOf(source.coreRules,500),links=arrayOf(source.ruleLinks,2000),reviews=arrayOf(source.reviews,3000),wrongLinks=arrayOf(source.wrongAnswerLinks,300),drillLinks=source.coreRuleDrillLinks===undefined?[]:arrayOf(source.coreRuleDrillLinks,2000),learningReviews=source.learningReviews===undefined?[]:arrayOf(source.learningReviews,5000);"
    new = "const entries=arrayOf(source.entries,300),annotations=arrayOf(source.annotations,2000),rules=arrayOf(source.coreRules,500),links=arrayOf(source.ruleLinks,2000),reviews=arrayOf(source.reviews,3000),wrongLinks=arrayOf(source.wrongAnswerLinks,300),wrongRuleLinks=source.coreRuleWrongAnswerLinks===undefined?[]:arrayOf(source.coreRuleWrongAnswerLinks,5000),drillLinks=source.coreRuleDrillLinks===undefined?[]:arrayOf(source.coreRuleDrillLinks,2000),learningReviews=source.learningReviews===undefined?[]:arrayOf(source.learningReviews,5000);"
    c = replace_once(c, old, new, "archive import direct links array")

    c = replace_once(
        c,
        "for(const item of links){requiredId(item.archiveEntryId);requiredId(item.coreRuleId);optionalDate(item.createdAt)}",
        "for(const item of links){requiredId(item.archiveEntryId);requiredId(item.coreRuleId);const relation=optionalText(item.relationType,20)??'derived';if(!['derived','applied','failed','reinforced'].includes(relation))throw new Error('INVALID_BACKUP');optionalDate(item.createdAt)}",
        "archive rule link validation",
    )
    c = replace_once(
        c,
        "for(const item of wrongLinks){requiredId(item.archiveEntryId);requiredId(item.wrongAnswerId);optionalDate(item.createdAt)}",
        "for(const item of wrongLinks){requiredId(item.archiveEntryId);requiredId(item.wrongAnswerId);optionalDate(item.createdAt)}\n"
        " for(const item of wrongRuleLinks){requiredId(item.coreRuleId);requiredId(item.wrongAnswerId);const relation=optionalText(item.relationType,20)??'failed';if(!['derived','applied','failed','reinforced'].includes(relation))throw new Error('INVALID_BACKUP');optionalDate(item.createdAt)}",
        "archive direct link validation",
    )

    old = "seenLinks.add(key);linkStatements.push(db.prepare('INSERT OR IGNORE INTO archive_entry_core_rules(archive_entry_id,core_rule_id,created_at) VALUES(?,?,?)').bind(entry,rule,iso(item.createdAt)?item.createdAt:now))"
    new = "seenLinks.add(key);const relation=optionalText(item.relationType,20)??'derived';linkStatements.push(db.prepare('INSERT INTO archive_entry_core_rules(archive_entry_id,core_rule_id,created_at,relation_type) VALUES(?,?,?,?) ON CONFLICT(archive_entry_id,core_rule_id) DO UPDATE SET relation_type=excluded.relation_type').bind(entry,rule,iso(item.createdAt)?item.createdAt:now,relation))"
    c = replace_once(c, old, new, "archive import relation preservation")

    marker = " const validDrills=new Set((Array.isArray(app.dailyDrills)?app.dailyDrills:[])"
    direct_import = """ const wrongRuleStatements:D1PreparedStatement[]=[];for(const item of wrongRuleLinks){const rule=ruleMap.get(requiredId(item.coreRuleId)),wrong=requiredId(item.wrongAnswerId),relation=optionalText(item.relationType,20)??'failed';if(!rule||!validWrong.has(wrong)){warnings.push(`Core Rule ↔ Wrong Answer ${wrong}: parent 없음`);continue}wrongRuleStatements.push(db.prepare('INSERT INTO core_rule_wrong_answer_links(user_id,core_rule_id,wrong_answer_id,relation_type,created_at) VALUES(?,?,?,?,?) ON CONFLICT(core_rule_id,wrong_answer_id) DO UPDATE SET relation_type=excluded.relation_type').bind(userId,rule,wrong,relation,iso(item.createdAt)?item.createdAt:now))}if(wrongRuleStatements.length)await db.batch(wrongRuleStatements);
"""
    c = replace_once(c, marker, direct_import + marker, "archive import direct link statements")

    c = replace_once(
        c,
        "wrongAnswerLinks:wrongStatements.length,coreRuleDrillLinks:drillStatements.length,learningReviews:learningReviewStatements.length",
        "wrongAnswerLinks:wrongStatements.length,coreRuleWrongAnswerLinks:wrongRuleStatements.length,coreRuleDrillLinks:drillStatements.length,learningReviews:learningReviewStatements.length",
        "archive import report",
    )

    old = """async function ensureIntelligence(db:D1Database){
 await db.batch([db.prepare("CREATE TABLE IF NOT EXISTS core_rule_drill_links(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,core_rule_id TEXT NOT NULL REFERENCES core_rules(id) ON DELETE CASCADE,drill_id TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(core_rule_id,drill_id))"),db.prepare("CREATE TABLE IF NOT EXISTS learning_reviews(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,target_type TEXT NOT NULL,target_id TEXT NOT NULL,review_type TEXT NOT NULL DEFAULT 'retry',scheduled_at TEXT,reviewed_at TEXT,result TEXT NOT NULL DEFAULT 'pending',notes TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL)")]);
 const columns=await db.prepare('PRAGMA table_info(archive_entry_core_rules)').all<{name:string}>();if(!columns.results.some(v=>v.name==='relation_type'))await db.prepare("ALTER TABLE archive_entry_core_rules ADD COLUMN relation_type TEXT NOT NULL DEFAULT 'derived'").run();
}"""
    new = """async function ensureIntelligence(db:D1Database,userId:number){
 await db.batch([db.prepare("CREATE TABLE IF NOT EXISTS core_rule_drill_links(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,core_rule_id TEXT NOT NULL REFERENCES core_rules(id) ON DELETE CASCADE,drill_id TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(core_rule_id,drill_id))"),db.prepare("CREATE TABLE IF NOT EXISTS core_rule_wrong_answer_links(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,core_rule_id TEXT NOT NULL REFERENCES core_rules(id) ON DELETE CASCADE,wrong_answer_id TEXT NOT NULL,relation_type TEXT NOT NULL DEFAULT 'failed',created_at TEXT NOT NULL,PRIMARY KEY(core_rule_id,wrong_answer_id))"),db.prepare("CREATE INDEX IF NOT EXISTS core_rule_wrong_answer_user_wrong ON core_rule_wrong_answer_links(user_id,wrong_answer_id)"),db.prepare("CREATE TABLE IF NOT EXISTS learning_reviews(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,target_type TEXT NOT NULL,target_id TEXT NOT NULL,review_type TEXT NOT NULL DEFAULT 'retry',scheduled_at TEXT,reviewed_at TEXT,result TEXT NOT NULL DEFAULT 'pending',notes TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL)")]);
 const columns=await db.prepare('PRAGMA table_info(archive_entry_core_rules)').all<{name:string}>();if(!columns.results.some(v=>v.name==='relation_type'))await db.prepare("ALTER TABLE archive_entry_core_rules ADD COLUMN relation_type TEXT NOT NULL DEFAULT 'derived'").run();
 await db.prepare("INSERT OR IGNORE INTO core_rule_wrong_answer_links(user_id,core_rule_id,wrong_answer_id,relation_type,created_at) SELECT w.user_id,l.core_rule_id,w.wrong_answer_id,COALESCE(l.relation_type,'failed'),? FROM archive_wrong_answer_links w JOIN archive_entry_core_rules l ON l.archive_entry_id=w.archive_entry_id JOIN core_rules r ON r.id=l.core_rule_id WHERE w.user_id=? AND r.user_id=?").bind(new Date().toISOString(),userId,userId).run();
}"""
    c = replace_once(c, old, new, "archive ensure intelligence")

    c = replace_once(c, "await ensureIntelligence(env.DB);", "await ensureIntelligence(env.DB,user.id);", "archive ensure call")

    c = replace_once(
        c,
        "SELECT r.*,COUNT(l.archive_entry_id) usage_count FROM core_rules r LEFT JOIN archive_entry_core_rules l ON l.core_rule_id=r.id WHERE r.user_id=? GROUP BY r.id ORDER BY r.updated_at DESC",
        "SELECT r.*,COUNT(DISTINCT l.archive_entry_id) usage_count,(SELECT COUNT(*) FROM core_rule_wrong_answer_links w WHERE w.core_rule_id=r.id AND w.user_id=r.user_id) wrong_answer_count FROM core_rules r LEFT JOIN archive_entry_core_rules l ON l.core_rule_id=r.id WHERE r.user_id=? GROUP BY r.id ORDER BY r.updated_at DESC",
        "archive rules wrong-answer count",
    )

    c = replace_once(
        c,
        "SELECT l.archive_entry_id,r.* FROM archive_entry_core_rules l JOIN core_rules r",
        "SELECT l.archive_entry_id,l.relation_type,r.* FROM archive_entry_core_rules l JOIN core_rules r",
        "archive bundle relation",
    )

    old = """if(path==='/api/archive/rule-links'&&method==='POST'){const b=await h.boundedJson<Record<string,unknown>>(request),entryId=clean(b.archiveEntryId,80),ruleId=clean(b.coreRuleId,80),relation=clean(b.relationType,20)||'derived';if(!['derived','applied','failed','reinforced'].includes(relation))return out({error:'Invalid relation type'},400);const [e,r]=await Promise.all([owner(env.DB,entryId,user.id),env.DB.prepare('SELECT id FROM core_rules WHERE id=? AND user_id=?').bind(ruleId,user.id).first()]);if(!e||!r)return out({error:'Not found'},404);await env.DB.prepare('INSERT INTO archive_entry_core_rules(archive_entry_id,core_rule_id,created_at,relation_type) VALUES(?,?,?,?) ON CONFLICT(archive_entry_id,core_rule_id) DO UPDATE SET relation_type=excluded.relation_type').bind(entryId,ruleId,new Date().toISOString(),relation).run();return out({ok:true},201)}"""
    new = """if(path==='/api/archive/rule-links'&&method==='POST'){const b=await h.boundedJson<Record<string,unknown>>(request),entryId=clean(b.archiveEntryId,80),ruleId=clean(b.coreRuleId,80),relation=clean(b.relationType,20)||'derived';if(!['derived','applied','failed','reinforced'].includes(relation))return out({error:'Invalid relation type'},400);const [e,r]=await Promise.all([owner(env.DB,entryId,user.id),env.DB.prepare('SELECT id FROM core_rules WHERE id=? AND user_id=?').bind(ruleId,user.id).first()]);if(!e||!r)return out({error:'Not found'},404);const now=new Date().toISOString();await env.DB.prepare('INSERT INTO archive_entry_core_rules(archive_entry_id,core_rule_id,created_at,relation_type) VALUES(?,?,?,?) ON CONFLICT(archive_entry_id,core_rule_id) DO UPDATE SET relation_type=excluded.relation_type').bind(entryId,ruleId,now,relation).run();const wrong=await env.DB.prepare('SELECT wrong_answer_id FROM archive_wrong_answer_links WHERE archive_entry_id=? AND user_id=?').bind(entryId,user.id).first<{wrong_answer_id:string}>();if(wrong?.wrong_answer_id)await env.DB.prepare('INSERT INTO core_rule_wrong_answer_links(user_id,core_rule_id,wrong_answer_id,relation_type,created_at) VALUES(?,?,?,?,?) ON CONFLICT(core_rule_id,wrong_answer_id) DO UPDATE SET relation_type=excluded.relation_type').bind(user.id,ruleId,wrong.wrong_answer_id,relation,now).run();return out({ok:true},201)}"""
    c = replace_once(c, old, new, "archive rule link auto direct")

    old = """if(path==='/api/archive/wrong-answer-links'&&method==='POST'){const b=await h.boundedJson<Record<string,unknown>>(request),entryId=clean(b.archiveEntryId,80),wrong=clean(b.wrongAnswerId,100);if(!wrong||!await owner(env.DB,entryId,user.id))return out({error:'Not found'},404);await env.DB.prepare('INSERT INTO archive_wrong_answer_links VALUES(?,?,?,?) ON CONFLICT(archive_entry_id) DO UPDATE SET wrong_answer_id=excluded.wrong_answer_id').bind(entryId,user.id,wrong,new Date().toISOString()).run();return out({ok:true},201)}"""
    new = """if(path==='/api/archive/wrong-answer-links'&&method==='POST'){const b=await h.boundedJson<Record<string,unknown>>(request),entryId=clean(b.archiveEntryId,80),wrong=clean(b.wrongAnswerId,100);if(!wrong||!await owner(env.DB,entryId,user.id))return out({error:'Not found'},404);const now=new Date().toISOString();await env.DB.prepare('INSERT INTO archive_wrong_answer_links VALUES(?,?,?,?) ON CONFLICT(archive_entry_id) DO UPDATE SET wrong_answer_id=excluded.wrong_answer_id').bind(entryId,user.id,wrong,now).run();await env.DB.prepare("INSERT INTO core_rule_wrong_answer_links(user_id,core_rule_id,wrong_answer_id,relation_type,created_at) SELECT ?,l.core_rule_id,?,COALESCE(l.relation_type,'failed'),? FROM archive_entry_core_rules l JOIN core_rules r ON r.id=l.core_rule_id WHERE l.archive_entry_id=? AND r.user_id=? ON CONFLICT(core_rule_id,wrong_answer_id) DO UPDATE SET relation_type=excluded.relation_type").bind(user.id,wrong,now,entryId,user.id).run();return out({ok:true},201)}"""
    c = replace_once(c, old, new, "archive wrong answer auto direct")
    return c

def patch_learning_archive(c: str) -> str:
    c = replace_once(
        c,
        "import { archiveApi,type ArchiveEntry,type ArchiveSubject,type CoreRule,type MasteryStatus } from '../lib/archiveApi';",
        "import { archiveApi,type ArchiveEntry,type ArchiveSubject,type CoreRule,type MasteryStatus,type RuleRelation } from '../lib/archiveApi';",
        "LearningArchive relation import",
    )
    c = replace_once(
        c,
        "import type { AppData } from '../types';",
        "import type { AppData } from '../types';\nimport { getCurrentStudyDay } from '../lib/date';",
        "LearningArchive study day import",
    )
    c = replace_once(
        c,
        "const mastery:{id:MasteryStatus;label:string}[]=[{id:'input',label:'입력'},{id:'understanding',label:'이해'},{id:'reproduction',label:'재현'},{id:'automated',label:'자동화'}];\nconst today=()=>new Date().toISOString().slice(0,10);",
        "const mastery:{id:MasteryStatus;label:string}[]=[{id:'input',label:'입력'},{id:'understanding',label:'이해'},{id:'reproduction',label:'재현'},{id:'automated',label:'자동화'}];\n"
        "const relationLabel:Record<RuleRelation,string>={derived:'도출',applied:'적용',failed:'적용 실패',reinforced:'강화'};\n"
        "const today=()=>getCurrentStudyDay();",
        "LearningArchive labels/study day",
    )
    c = replace_once(
        c,
        "<span className=\"card-label\">{subjects.find(s=>s.id===rule.subject)?.label} · 사용 {rule.usageCount}회</span>",
        "<span className=\"card-label\">{subjects.find(s=>s.id===rule.subject)?.label} · Archive {rule.usageCount} · Wrong Answer {rule.wrongAnswerCount??0}</span>",
        "LearningArchive rule wrong-answer count",
    )
    c = replace_once(
        c,
        "{entries.filter(e=>e.coreRules.some(r=>r.id===rule.id)).map(e=><button className=\"row-link\" key={e.id} onClick={()=>{openEntry(e,'rules');setView('archive')}}>{e.title}</button>)}",
        "{entries.filter(e=>e.coreRules.some(r=>r.id===rule.id)).map(e=>{const linked=e.coreRules.find(r=>r.id===rule.id);return <button className=\"row-link\" key={e.id} onClick={()=>{openEntry(e,'rules');setView('archive')}}>{e.title} · [{relationLabel[(linked?.relationType??'derived') as RuleRelation]}]</button>})}",
        "LearningArchive reverse trace relation",
    )
    c = replace_once(
        c,
        "<button className=\"archive-rule-title\" onClick={()=>startRuleEdit(r)}><b>{r.title}</b><span>{r.content}</span></button>",
        "<button className=\"archive-rule-title\" onClick={()=>startRuleEdit(r)}><b>{r.title} <span className=\"rule-chip\">{relationLabel[(r.relationType??'derived') as RuleRelation]}</span></b><span>{r.content}</span></button>",
        "LearningArchive detail relation badge",
    )
    return c

def patch_archive_explorer(c: str) -> str:
    c = replace_once(
        c,
        "import type { ArchiveEntry } from '../lib/archiveApi';",
        "import type { ArchiveEntry } from '../lib/archiveApi';\nimport { getCurrentStudyDay } from '../lib/date';",
        "ArchiveExplorer study day import",
    )
    c = replace_once(
        c,
        "  const today = new Date().toISOString().slice(0, 10);",
        "  const today = getCurrentStudyDay();",
        "ArchiveExplorer review study day",
    )
    return c

def patch_train_hub(c: str) -> str:
    c = replace_once(c, "import { useMemo, useRef, useState } from 'react';", "import { useEffect, useMemo, useRef, useState } from 'react';", "TrainHub useEffect")
    c = replace_once(c, "import { ArrowRight, Crosshair, X } from 'lucide-react';", "import { ArrowRight, Link2, X } from 'lucide-react';", "TrainHub icons")
    c = replace_once(
        c,
        "import { useDialogFocus } from '../components/motion/useDialogFocus';",
        "import { useDialogFocus } from '../components/motion/useDialogFocus';\nimport { archiveApi, type CoreRule, type RuleRelation } from '../lib/archiveApi';",
        "TrainHub archive API import",
    )
    c = replace_once(
        c,
        "const tabs = [{ id: 'timer', label: 'Timer' }, { id: 'drill', label: 'Drill' }, { id: 'wrong', label: 'Wrong Answers' }, { id: 'resources', label: 'Resources' }] as const;",
        "const tabs = [{ id: 'timer', label: 'Timer' }, { id: 'drill', label: 'Drill' }, { id: 'wrong', label: 'Wrong Answers' }, { id: 'resources', label: 'Resources' }] as const;\n"
        "const relationLabels:Record<RuleRelation,string>={derived:'도출',applied:'적용',failed:'적용 실패',reinforced:'강화'};\n"
        "type LinkedCoreRule=CoreRule&{relationType?:RuleRelation};",
        "TrainHub relation metadata",
    )

    old = """  const [open, setOpen] = useState<Record<string, boolean>>({});
  const sheetRef = useRef<HTMLElement>(null);
  useDialogFocus(Boolean(selected), sheetRef, () => setSelected(null));"""
    new = """  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [linkedRules,setLinkedRules]=useState<LinkedCoreRule[]>([]);
  const [allRules,setAllRules]=useState<CoreRule[]>([]);
  const [ruleToLink,setRuleToLink]=useState('');
  const [linkRelation,setLinkRelation]=useState<RuleRelation>('failed');
  const [linkBusy,setLinkBusy]=useState(false);
  const [linkError,setLinkError]=useState('');
  const sheetRef = useRef<HTMLElement>(null);
  useDialogFocus(Boolean(selected), sheetRef, () => setSelected(null));
  const loadRuleLinks=async(id:string)=>{const [graph,library]=await Promise.all([archiveApi<{coreRules:LinkedCoreRule[]}>(`/api/learning-intelligence/wrong-answers/${encodeURIComponent(id)}`),archiveApi<{rules:CoreRule[]}>('/api/archive/rules')]);setLinkedRules(graph.coreRules);setAllRules(library.rules);};
  useEffect(()=>{if(!selected){setLinkedRules([]);setRuleToLink('');setLinkError('');return}let live=true;setLinkError('');Promise.all([archiveApi<{coreRules:LinkedCoreRule[]}>(`/api/learning-intelligence/wrong-answers/${encodeURIComponent(selected.id)}`),archiveApi<{rules:CoreRule[]}>('/api/archive/rules')]).then(([graph,library])=>{if(!live)return;setLinkedRules(graph.coreRules);setAllRules(library.rules)}).catch(error=>{if(live)setLinkError(error instanceof Error?error.message:'Core Rule 연결 정보를 불러오지 못했습니다.')});return()=>{live=false}},[selected?.id]);
  const linkCoreRule=async()=>{if(!selected||!ruleToLink)return;setLinkBusy(true);setLinkError('');try{await archiveApi('/api/learning-intelligence/wrong-answer-links','POST',{coreRuleId:ruleToLink,wrongAnswerId:selected.id,relationType:linkRelation});await loadRuleLinks(selected.id);setRuleToLink('')}catch(error){setLinkError(error instanceof Error?error.message:'Core Rule 연결 실패')}finally{setLinkBusy(false)}};
  const unlinkCoreRule=async(ruleId:string)=>{if(!selected)return;setLinkBusy(true);setLinkError('');try{await archiveApi(`/api/learning-intelligence/wrong-answer-links/${encodeURIComponent(ruleId)}/${encodeURIComponent(selected.id)}`,'DELETE');await loadRuleLinks(selected.id)}catch(error){setLinkError(error instanceof Error?error.message:'Core Rule 연결 해제 실패')}finally{setLinkBusy(false)}};"""
    c = replace_once(c, old, new, "TrainHub link states")

    old = """<section><b>재도전</b><p>{selected.retries?.map((retry) => `${retry.label} ${retry.completedDate ? '✓' : retry.dueDate}`).join(' · ') || '일정 없음'}</p></section></div><button className="button primary" """
    new = """<section><b>재도전</b><p>{selected.retries?.map((retry) => `${retry.label} ${retry.completedDate ? '✓' : retry.dueDate}`).join(' · ') || '일정 없음'}</p></section><section><b>연결된 Core Rule</b>{linkError&&<p className="team-error">{linkError}</p>}{linkedRules.length?<div className="record-links">{linkedRules.map(rule=><span key={rule.id}><b>[{relationLabels[(rule.relationType??'failed') as RuleRelation]}]</b> {rule.title} <button className="button small" disabled={linkBusy} onClick={()=>void unlinkCoreRule(rule.id)}>해제</button></span>)}</div>:<p>연결된 Core Rule이 없습니다.</p>}<div className="form-grid two"><select aria-label="Core Rule 관계" value={linkRelation} onChange={event=>setLinkRelation(event.target.value as RuleRelation)}><option value="failed">적용 실패</option><option value="applied">적용</option><option value="derived">도출</option><option value="reinforced">강화</option></select><select aria-label="연결할 Core Rule" value={ruleToLink} onChange={event=>setRuleToLink(event.target.value)}><option value="">Core Rule 선택</option>{allRules.filter(rule=>!linkedRules.some(linked=>linked.id===rule.id)).map(rule=><option key={rule.id} value={rule.id}>{rule.title}</option>)}</select></div><button className="button" disabled={linkBusy||!ruleToLink} onClick={()=>void linkCoreRule()}><Link2 size={14}/>Core Rule 연결</button></section></div><button className="button primary" """
    c = replace_once(c, old, new, "TrainHub wrong answer Core Rule UI")
    return c

def patch_schema(c: str) -> str:
    if "CREATE TABLE IF NOT EXISTS core_rule_wrong_answer_links" in c:
        return c
    anchor = """CREATE TABLE IF NOT EXISTS learning_reviews (
"""
    block = """CREATE TABLE IF NOT EXISTS core_rule_wrong_answer_links (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  core_rule_id TEXT NOT NULL REFERENCES core_rules(id) ON DELETE CASCADE,
  wrong_answer_id TEXT NOT NULL,
  relation_type TEXT NOT NULL DEFAULT 'failed'
    CHECK(relation_type IN ('derived','applied','failed','reinforced')),
  created_at TEXT NOT NULL,
  PRIMARY KEY(core_rule_id,wrong_answer_id)
);
CREATE INDEX IF NOT EXISTS core_rule_wrong_answer_user_wrong ON core_rule_wrong_answer_links(user_id,wrong_answer_id);
"""
    return replace_once(c, anchor, block + anchor, "schema direct link table")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", nargs="?", default=".", help="TRINITY-OS repository root")
    args = parser.parse_args()
    root = Path(args.repo).resolve()

    patch_file(root, "src/lib/archiveApi.ts", patch_archive_api)
    patch_file(root, "worker/src/learning-intelligence.ts", patch_learning_intelligence)
    patch_file(root, "worker/src/archive.ts", patch_archive)
    patch_file(root, "src/pages/LearningArchive.tsx", patch_learning_archive)
    patch_file(root, "src/components/ArchiveExplorer.tsx", patch_archive_explorer)
    patch_file(root, "src/pages/TrainHub.tsx", patch_train_hub)
    patch_file(root, "worker/schema.sql", patch_schema)

    migration_src = Path(__file__).resolve().parent / "worker/migrations/0013_core_rule_wrong_answer_links.sql"
    migration_dst = root / "worker/migrations/0013_core_rule_wrong_answer_links.sql"
    migration_dst.parent.mkdir(parents=True, exist_ok=True)
    if not migration_dst.exists():
        shutil.copy2(migration_src, migration_dst)
        print("created worker/migrations/0013_core_rule_wrong_answer_links.sql")
    elif migration_dst.read_text(encoding="utf-8") != migration_src.read_text(encoding="utf-8"):
        raise RuntimeError("migration 0013 already exists with different content")

    print("\nPatch complete.")
    print("Next:")
    print("  npm test")
    print("  npm run build")
    print("  cd worker && npx wrangler deploy --dry-run --config wrangler.toml")
    print("  npx wrangler d1 migrations apply trinity-os-db --remote --config worker/wrangler.toml")
    print("  deploy Worker, then frontend")

if __name__ == "__main__":
    main()
