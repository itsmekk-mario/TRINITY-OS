# TRINITY OS — Core Rule ↔ Wrong Answer direct-link fix

이 패키지는 2026-09-18 GitHub `main` 코드 구조를 기준으로 작성되었습니다.

## 수정 내용

- `core_rule_wrong_answer_links` M:N 링크 테이블 추가
- 기존 `Core Rule ↔ Archive ↔ Wrong Answer` 간접 관계를 migration으로 직접 링크로 승격
- Archive에 Core Rule을 연결할 때 이미 Wrong Answer가 있으면 자동 직접 연결
- Archive에 Wrong Answer를 연결할 때 기존 Core Rule 전부 자동 직접 연결
- Wrong Answer 상세 화면에서 Core Rule 연결/해제 및 관계 선택
- Core Rule Library에서 연결된 Wrong Answer 개수 표시
- 관계: `도출 / 적용 / 적용 실패 / 강화`
- Core Rule intelligence가 Archive 간접 JOIN이 아니라 직접 링크를 우선 사용
- Backup v2 export/import에 직접 링크 포함
- Archive의 Core Rule 관계값 `relationType` 조회/복원 보존
- Learning Archive의 날짜 기본값을 TRINITY 공통 06:00 Study Day로 변경
- Archive Core Rule UI에서 관계 badge 표시

## 적용

현재 최신 repository root에서:

```bash
python apply_core_rule_wrong_answer_fix.py .
```

그 다음:

```bash
npm test
npm run build
cd worker
npx wrangler deploy --dry-run --config wrangler.toml
```

D1 migration:

```bash
npx wrangler d1 migrations apply trinity-os-db --remote --config worker/wrangler.toml
```

그 후 Worker와 frontend를 기존 배포 절차로 배포합니다.

## 데이터 보존

기존 Archive/오답/Core Rule 데이터는 삭제하지 않습니다.
0013 migration이 기존 간접 관계를 `INSERT OR IGNORE`로 직접 링크에 승격합니다.

## 주의

GitHub connector가 현재 파일 쓰기 권한을 반환하지 않아 이 대화에서 원격 `main`에 직접 commit/push는 수행하지 못했습니다.
이 패키지는 최신 main의 확인된 코드 anchor를 기준으로 자동 수정하도록 작성되어 있습니다.
