#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path.cwd()

def fail(message: str):
    print(f"[ERROR] {message}")
    raise SystemExit(1)

def replace_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        print(f"[SKIP] {label}: already applied")
        return text
    if old not in text:
        fail(f"{label}: expected source block not found. 최신 main에서 실행했는지 확인하세요.")
    print(f"[OK] {label}")
    return text.replace(old, new, 1)

for required in [ROOT / "src/App.tsx", ROOT / "src/main.tsx", ROOT / "index.html"]:
    if not required.exists():
        fail(f"{required} not found. TRINITY-OS 저장소 루트에서 실행하세요.")

backup_dir = ROOT / ".trinity-theme-backup"
backup_dir.mkdir(exist_ok=True)
for rel in ["src/App.tsx", "src/main.tsx", "index.html"]:
    src = ROOT / rel
    dst = backup_dir / rel.replace("/", "__")
    if not dst.exists():
        shutil.copy2(src, dst)

app_path = ROOT / "src/App.tsx"
app = app_path.read_text(encoding="utf-8")

app = replace_once(
    app,
    "import { BookMarked, BrainCircuit, CalendarRange, ChartNoAxesCombined, Menu, Download, Gauge, Home, MessageSquareText, NotebookTabs, Settings, ShieldCheck, Swords, Target, Upload, UserRound, Video, X } from 'lucide-react';",
    "import { BookMarked, BrainCircuit, CalendarRange, ChartNoAxesCombined, Menu, Download, Gauge, Home, Laptop, MessageSquareText, Moon, NotebookTabs, Settings, ShieldCheck, Sun, Swords, Target, Upload, UserRound, Video, X } from 'lucide-react';",
    "theme icons"
)

theme_helpers = """const queryView = () => new URLSearchParams(window.location.search).get('view');
type ThemePreference = 'system' | 'light' | 'dark';
const THEME_KEY = 'trinity-os:theme-preference';
const getThemePreference = (): ThemePreference => {
  const value = localStorage.getItem(THEME_KEY);
  return value === 'light' || value === 'dark' || value === 'system' ? value : 'system';
};
const resolveTheme = (preference: ThemePreference) =>
  preference === 'system'
    ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    : preference;
"""
app = replace_once(
    app,
    "const queryView = () => new URLSearchParams(window.location.search).get('view');\n",
    theme_helpers,
    "theme helpers"
)

app = replace_once(
    app,
    "const syncing = useRef(false); const scrollPositions = useRef(new Map<string, number>());",
    "const syncing = useRef(false); const scrollPositions = useRef(new Map<string, number>()); const [themePreference, setThemePreference] = useState<ThemePreference>(getThemePreference);",
    "theme state"
)

effect_marker = "  const username = loadCloudflareConfig().username || '내 계정';\n"
effect_block = effect_marker + """  useEffect(() => {
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const applyTheme = () => {
      const theme = resolveTheme(themePreference);
      document.documentElement.dataset.theme = theme;
      document.documentElement.style.colorScheme = theme;
      document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#0f1115' : '#0b1628');
    };
    applyTheme();
    const onSystemThemeChange = () => { if (themePreference === 'system') applyTheme(); };
    media.addEventListener('change', onSystemThemeChange);
    return () => media.removeEventListener('change', onSystemThemeChange);
  }, [themePreference]);
"""
app = replace_once(app, effect_marker, effect_block, "theme runtime")

app = replace_once(
    app,
    "  const screen = page === 'today' ?",
    """  const changeTheme = (next: ThemePreference) => {
    localStorage.setItem(THEME_KEY, next);
    setThemePreference(next);
  };
  const screen = page === 'today' ?""",
    "theme change handler"
)

settings_old = '<div className="sheet-content"><div className="inline-settings">'
settings_new = """<div className="sheet-content"><section className="theme-setting" aria-labelledby="theme-setting-title"><div><b id="theme-setting-title">화면 테마</b><p>시스템은 기기 설정을 따르고, 라이트·다크는 직접 고정합니다.</p></div><div className="theme-options" role="group" aria-label="화면 테마 선택"><button className={themePreference === 'system' ? 'active' : ''} aria-pressed={themePreference === 'system'} onClick={() => changeTheme('system')}><Laptop size={16} />시스템</button><button className={themePreference === 'light' ? 'active' : ''} aria-pressed={themePreference === 'light'} onClick={() => changeTheme('light')}><Sun size={16} />라이트</button><button className={themePreference === 'dark' ? 'active' : ''} aria-pressed={themePreference === 'dark'} onClick={() => changeTheme('dark')}><Moon size={16} />다크</button></div></section><div className="inline-settings">"""
app = replace_once(app, settings_old, settings_new, "theme settings UI")
app_path.write_text(app, encoding="utf-8")

main_path = ROOT / "src/main.tsx"
main = main_path.read_text(encoding="utf-8")
main = replace_once(
    main,
    "import './study-room.css'; \n",
    "import './study-room.css'; \nimport './theme-dark.css';\n",
    "theme stylesheet import"
)
main_path.write_text(main, encoding="utf-8")

index_path = ROOT / "index.html"
index = index_path.read_text(encoding="utf-8")
boot_script = """    <script>
      (() => {
        const key = 'trinity-os:theme-preference';
        const saved = localStorage.getItem(key);
        const preference = saved === 'light' || saved === 'dark' || saved === 'system' ? saved : 'system';
        const dark = preference === 'dark' || (preference === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
        document.documentElement.dataset.theme = dark ? 'dark' : 'light';
        document.documentElement.style.colorScheme = dark ? 'dark' : 'light';
      })();
    </script>
"""
if "trinity-os:theme-preference" not in index:
    needle = '    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />\n'
    if needle not in index:
        fail("index theme bootstrap: viewport marker not found")
    index = index.replace(needle, needle + boot_script, 1)
    print("[OK] pre-paint theme bootstrap")
else:
    print("[SKIP] pre-paint theme bootstrap: already applied")
index_path.write_text(index, encoding="utf-8")

source_css = Path(__file__).resolve().parent / "src/theme-dark.css"
target_css = ROOT / "src/theme-dark.css"
if not source_css.exists():
    fail("patch package is missing src/theme-dark.css")
shutil.copy2(source_css, target_css)
print("[OK] src/theme-dark.css installed")

print()
print("Dark mode patch applied.")
print("Next:")
print("  npm run build")
print("  git status")
print("  git add src/App.tsx src/main.tsx src/theme-dark.css index.html")
print('  git commit -m "feat: add safe explicit dark mode"')
print("  git push origin main")
