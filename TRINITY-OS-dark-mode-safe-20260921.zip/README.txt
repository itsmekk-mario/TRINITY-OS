TRINITY OS — Safe Dark Mode Patch
기준: 2026-09-21 UI rollback 이후 main

적용:
1. ZIP을 TRINITY-OS 저장소 루트에 압축 해제
2. python3 apply-dark-mode.py
3. npm run build
4. git add src/App.tsx src/main.tsx src/theme-dark.css index.html
5. git commit -m "feat: add safe explicit dark mode"
6. git push origin main

원칙:
- 현재 라이트 UI 유지
- 시스템 / 라이트 / 다크 선택
- 다크모드는 semantic color token + 페이지별 색상 override
- 전역 display/overflow/line-clamp/layout 강제 금지
- AI Coach / Core Rules / Arena의 고유 구조 보존
