"""Local AI tests."""
