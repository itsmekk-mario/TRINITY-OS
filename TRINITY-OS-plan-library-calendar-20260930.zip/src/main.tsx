import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
import './ordering.css';
import './auth.css';
import './timer-enhanced.css';
import './ui-polish.css';
import './ui-system.css';
import './math-record.css';
import './teacher.css';
import './homeroom.css';
import './study-room.css'; 
import './theme-dark.css';
import './mobile.css';
import './monthly-plan.css';
import './plan-library.css';

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);

if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js'));
