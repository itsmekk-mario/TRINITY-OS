import DayLabelEditor from '../components/DayLabelEditor';
import PlanLinks from '../components/PlanLinks';
import WeeklyGoals from './WeeklyGoals';
import { bumpDrafts } from '../lib/planGraph';
import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, Check, ChevronLeft, ChevronRight, CircleDashed, GripVertical, Pencil, Plus, Trash2, TriangleAlert, X } from 'lucide-react';
import type { AppData, CalendarEntry, CalendarPlan, MonthlyPlan, PlanOutcome, Subject } from '../types';
import { SUBJECTS } from '../data/config';
import { Card, Empty, Field, PageHeader, SaveButton, TextArea } from '../components/Ui';
import { shouldAutoAdvanceWeek, toDateKey, uid, weekStartKey } from '../lib/date';

type WeeklyTaskDraft = CalendarPlan & { date: string };
const emptyCalendar = (date: string): CalendarEntry => ({ date, study: '', minutes: 0, exam: '', event: '', condition: 3, reflection: '', plans: [] });
const blankPlan = (): MonthlyPlan => ({ id: '', month: toDateKey().slice(0, 7), subject: '국어', title: '', objective: '', successCriterion: '', strategy: '', done: false });
const blankTask = (date: string): WeeklyTaskDraft => ({ id: '', date, subject: '국어', title: '', detail: '', quantity: '', done: false });
const outcomeOf=(item:CalendarPlan):PlanOutcome=>item.outcome??(item.done?'achieved':'partial');
const outcomeLabel:Record<PlanOutcome,string>={achieved:'달성',partial:'세모',failed:'실패'};
const dateLabel = (date: string) => new Intl.DateTimeFormat('ko-KR', { month: 'numeric', day: 'numeric', weekday: 'short' }).format(new Date(`${date}T00:00:00`));
const weekDates = (start: string) => Array.from({ length: 7 }, (_, index) => { const date = new Date(`${start}T00:00:00`); date.setDate(date.getDate() + index); return toDateKey(date); });

export default function PlanningPage({ data, update, initialTab = 'weekly' }: { data: AppData; update: (fn: (value: AppData) => AppData) => void; initialTab?: 'weekly' | 'monthly' }) {
  const [tab, setTab] = useState<'weekly' | 'monthly'>(initialTab);
  const [weekStart, setWeekStart] = useState(weekStartKey());
  const currentWeekRef = useRef(weekStartKey());
  const [month, setMonth] = useState(toDateKey().slice(0, 7));
  const [taskDate, setTaskDate] = useState<string | null>(null);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [task, setTask] = useState<WeeklyTaskDraft>(blankTask(weekStartKey()));
  const [openMonthly, setOpenMonthly] = useState(false);
  const [monthlyDraft, setMonthlyDraft] = useState(blankPlan());
  const [editingMonthlyId, setEditingMonthlyId] = useState<string | null>(null);
  const [dragging, setDragging] = useState<{ kind: 'weekly'; date: string; id: string } | { kind: 'monthly'; id: string } | null>(null);
  const [dragHint, setDragHint] = useState('');
  const dragTimer = useState<{ current: number | null }>({ current: null })[0];
  useEffect(() => {
    const syncWeek = () => {
      const previousCurrentWeek = currentWeekRef.current;
      const currentWeek = weekStartKey();
      if (currentWeek === previousCurrentWeek) return;
      currentWeekRef.current = currentWeek;
      setWeekStart((selectedWeek) => shouldAutoAdvanceWeek(selectedWeek, previousCurrentWeek, currentWeek) ? currentWeek : selectedWeek);
    };
    const syncWhenVisible = () => { if (document.visibilityState === 'visible') syncWeek(); };
    const interval = window.setInterval(syncWeek, 60_000);
    window.addEventListener('focus', syncWeek);
    document.addEventListener('visibilitychange', syncWhenVisible);
    return () => {
      window.clearInterval(interval);
      window.removeEventListener('focus', syncWeek);
      document.removeEventListener('visibilitychange', syncWhenVisible);
    };
  }, []);
  const dates = useMemo(() => weekDates(weekStart), [weekStart]);
  const monthlyPlans = useMemo(() => data.monthlyPlans.filter((item) => item.month === month), [data.monthlyPlans, month]);
  const openTask = (date: string, existing?: CalendarPlan) => { setTaskDate(date); setEditingTaskId(existing?.id ?? null); setTask(existing ? { ...existing, date } : blankTask(date)); };
  const closeTask = () => { setTaskDate(null); setEditingTaskId(null); };
  const saveTask = () => {
    if (!taskDate || !task.title.trim()) return;
    update((value) => {
      const entry = value.calendar[taskDate] ?? emptyCalendar(taskDate);
      const previous=editingTaskId?(entry.plans??[]).find(item=>item.id===editingTaskId):undefined;
      const saved: CalendarPlan = { ...task, id: editingTaskId ?? uid(), subject: task.subject, inquiryTrack: task.inquiryTrack, title: task.title.trim(), detail: task.detail.trim(), quantity: task.quantity.trim(), done: previous?.done ?? false, outcome: previous?.outcome };
      const plans = editingTaskId ? (entry.plans ?? []).map((item) => item.id === editingTaskId ? saved : item) : [...(entry.plans ?? []), saved];
      return { ...value, calendar: { ...value.calendar, [taskDate]: { ...entry, plans } } };
    });
    closeTask();
  };
  const setOutcome=(date:string,id:string,outcome:PlanOutcome)=>update(value=>{const entry=value.calendar[date];if(!entry)return value;return {...value,calendar:{...value.calendar,[date]:{...entry,plans:(entry.plans??[]).map(item=>item.id===id?{...item,outcome,done:outcome==='achieved'}:item)}}}});
  const removeTask = (date: string, id: string) => update((value) => { const entry = value.calendar[date]; if (!entry) return value; return { ...value, calendar: { ...value.calendar, [date]: { ...entry, plans: (entry.plans ?? []).filter((item) => item.id !== id) } } }; });
  const moveTask = (date: string, index: number, delta: number) => update((value) => { const entry = value.calendar[date]; const plans = [...(entry?.plans ?? [])]; const target = index + delta; if (!entry || target < 0 || target >= plans.length) return value; [plans[index], plans[target]] = [plans[target], plans[index]]; return { ...value, calendar: { ...value.calendar, [date]: { ...entry, plans } } }; });
  const moveTaskTo = (sourceDate: string, id: string, targetDate: string, targetIndex: number) => update((value) => {
    const source = value.calendar[sourceDate]; const item = source?.plans?.find((plan) => plan.id === id);
    if (!source || !item) return value;
    const sourcePlans = (source.plans ?? []).filter((plan) => plan.id !== id);
    const destination = targetDate === sourceDate ? sourcePlans : (value.calendar[targetDate] ?? emptyCalendar(targetDate)).plans ?? [];
    const plans = [...destination]; plans.splice(Math.max(0, Math.min(targetIndex, plans.length)), 0, item);
    return { ...value, calendar: { ...value.calendar, [sourceDate]: { ...source, plans: sourcePlans }, [targetDate]: { ...(value.calendar[targetDate] ?? emptyCalendar(targetDate)), plans } } };
  });
  const openMonthlyEditor = (item?: MonthlyPlan) => { setEditingMonthlyId(item?.id ?? null); setMonthlyDraft(item ? { ...item } : { ...blankPlan(), month }); setOpenMonthly(true); };
  const closeMonthlyEditor = () => { setOpenMonthly(false); setEditingMonthlyId(null); setMonthlyDraft({ ...blankPlan(), month }); };
  const saveMonthly = () => {
    if (!monthlyDraft.title.trim() || !monthlyDraft.objective.trim()) return;
    const saved = { ...monthlyDraft, id: editingMonthlyId ?? uid(), month: monthlyDraft.month || month, title: monthlyDraft.title.trim() };
    update((value) => ({ ...value, monthlyPlans: editingMonthlyId ? value.monthlyPlans.map((item) => item.id === editingMonthlyId ? saved : item) : [...value.monthlyPlans, saved] }));
    closeMonthlyEditor();
  };
  const toggleMonthly = (id: string) => update((value) => ({ ...value, monthlyPlans: value.monthlyPlans.map((item) => item.id === id ? { ...item, done: !item.done } : item) }));
  const removeMonthly = (id: string) => update((value) => ({ ...value, monthlyPlans: value.monthlyPlans.filter((item) => item.id !== id) }));
  const moveMonthlyTo = (id: string, targetIndex: number) => update((value) => {
    const sourceIndex = value.monthlyPlans.findIndex((item) => item.id === id); if (sourceIndex < 0) return value;
    const plans = [...value.monthlyPlans]; const [item] = plans.splice(sourceIndex, 1); plans.splice(Math.max(0, Math.min(targetIndex, plans.length)), 0, item); return { ...value, monthlyPlans: plans };
  });
  const startDrag = (event: React.PointerEvent<HTMLElement>, value: NonNullable<typeof dragging>) => {
    if (event.button !== 0 || (event.target as HTMLElement).closest('button, input, textarea, select')) return;
    event.currentTarget.setPointerCapture?.(event.pointerId);
    dragTimer.current = window.setTimeout(() => { setDragging(value); setDragHint('놓으면 이 위치로 이동합니다'); navigator.vibrate?.(12); }, 380);
  };
  const cancelDrag = () => { if (dragTimer.current) window.clearTimeout(dragTimer.current); dragTimer.current = null; };
  const finishDrag = (event: React.PointerEvent<HTMLElement>) => {
    cancelDrag(); if (!dragging) return;
    const target = document.elementFromPoint(event.clientX, event.clientY)?.closest<HTMLElement>('[data-week-drop], [data-month-drop]');
    if (dragging.kind === 'weekly' && target?.dataset.weekDrop) {
      const targetRow = document.elementFromPoint(event.clientX, event.clientY)?.closest<HTMLElement>('[data-week-task-index]');
      moveTaskTo(dragging.date, dragging.id, target.dataset.weekDrop, Number(targetRow?.dataset.weekTaskIndex ?? target.querySelectorAll('[data-week-task-index]').length));
    }
    if (dragging.kind === 'monthly' && target?.dataset.monthDrop) moveMonthlyTo(dragging.id, Number(target.dataset.monthDrop));
    setDragging(null); setDragHint('');
  };
  const moveWeek = (delta: number) => { const next = new Date(`${weekStart}T00:00:00`); next.setDate(next.getDate() + delta * 7); setWeekStart(toDateKey(next)); };
  const monthWeekCount = useMemo(() => { const map = new Map<string, number>(); Object.values(data.calendar).forEach((entry) => { if (entry.date.startsWith(month)) { const key = weekStartKey(new Date(`${entry.date}T00:00:00`)); map.set(key, (map.get(key) ?? 0) + (entry.plans?.length ?? 0)); } }); return [...map.entries()].sort(([a], [b]) => a.localeCompare(b)); }, [data.calendar, month]);

  return <div>
    <PageHeader eyebrow="LEARNING PLAN" title="Weekly · Monthly Plan" description="달력 칸 대신, 표에서 날짜별 실행 계획과 월간 방향을 한눈에 설계합니다." />
    <div className="plan-tabs"><button className={tab === 'weekly' ? 'active' : ''} onClick={() => setTab('weekly')}>WEEKLY PLAN</button><button className={tab === 'monthly' ? 'active' : ''} onClick={() => setTab('monthly')}>MONTHLY PLAN</button></div>
    {tab === 'weekly' ? <>
      <WeeklyGoals data={data} update={update} weekStart={weekStart}/><Card className="weekly-plan-head"><button aria-label="이전 주" onClick={() => moveWeek(-1)}><ChevronLeft /></button><div><span className="card-label">WEEKLY EXECUTION</span><h2>{dateLabel(dates[0])} — {dateLabel(dates[6])}</h2><p>계획마다 달성(✓)·세모(△)·실패(×)로 실제 결과를 남깁니다.</p></div><button aria-label="다음 주" onClick={() => moveWeek(1)}><ChevronRight /></button></Card>
      <div className="weekly-table card"><div className="weekly-table-head"><span>날짜</span><span>학습 계획 · 목표량</span></div>{dates.map((date) => {
        const plans = data.calendar[date]?.plans ?? [];
        return <div className="weekly-day-row" key={date}><div className="weekly-date"><strong>{dateLabel(date)}</strong><details><summary>{data.calendar[date]?.dayLabel || data.calendar[date]?.dayType?.toUpperCase() || '날짜 이름'}</summary><DayLabelEditor entry={data.calendar[date] ?? emptyCalendar(date)} onChange={entry=>update(v=>({...v,calendar:{...v.calendar,[date]:entry}}))}/></details>{data.calendar[date]?.dayType==='bump' && <button onClick={()=>{const drafts=bumpDrafts(data,date); if(drafts.length && window.confirm(drafts.map(p=>p.title).join('\n')+'\n위 항목을 Daily Plan에 추가할까요?')) update(v=>({...v,calendar:{...v.calendar,[date]:{...(v.calendar[date] ?? emptyCalendar(date)),plans:[...(v.calendar[date]?.plans ?? []),...drafts]}}}));}}>BUMP Plan 검토</button>}<button className="add-day-plan" onClick={() => openTask(date)}><Plus size={15} /> 추가</button></div><div className="weekly-task-list" data-week-drop={date}>{plans.length ? plans.map((item, index) => <div className={`weekly-task-row ${item.done ? 'done' : ''} ${dragging?.kind === 'weekly' && dragging.id === item.id ? 'is-dragging' : ''}`} data-week-task-index={index} key={item.id} onPointerDown={(event) => startDrag(event, { kind: 'weekly', date, id: item.id })} onPointerUp={finishDrag} onPointerCancel={cancelDrag}>
          <span className="drag-handle" aria-hidden="true"><GripVertical size={16} /></span><div className="plan-outcome" aria-label={`${item.title} 결과`}><button className={outcomeOf(item)==='achieved'?'active achieved':''} title="달성" onClick={() => setOutcome(date,item.id,'achieved')}><Check size={13}/></button><button className={outcomeOf(item)==='partial'?'active partial':''} title="세모" onClick={() => setOutcome(date,item.id,'partial')}><CircleDashed size={13}/></button><button className={outcomeOf(item)==='failed'?'active failed':''} title="실패" onClick={() => setOutcome(date,item.id,'failed')}><TriangleAlert size={13}/></button></div><span className={`subject-badge ${item.subject}`}>{item.subject}{item.inquiryTrack?` · ${item.inquiryTrack}`:''}</span><div className="weekly-task-main"><b>{item.title}</b>{item.detail && <small>{item.detail}</small>}</div><span className="weekly-task-quantity">{outcomeLabel[outcomeOf(item)]} · {item.quantity || '—'}</span><div className="weekly-task-actions"><button aria-label="수정" onClick={() => openTask(date, item)}><Pencil size={14} /></button><button aria-label="위로 이동" disabled={index === 0} onClick={() => moveTask(date, index, -1)}><ArrowUp size={14} /></button><button aria-label="아래로 이동" disabled={index === plans.length - 1} onClick={() => moveTask(date, index, 1)}><ArrowDown size={14} /></button><button className="row-delete" aria-label="삭제" onClick={() => removeTask(date, item.id)}><Trash2 size={14} /></button></div>
        </div>) : <p className="weekly-empty">계획 없음 — 추가 버튼으로 오늘의 훈련을 넣어보세요.</p>}</div></div>;
      })}</div>
    </> : <>
      <Card className="monthly-plan-head"><div><span className="card-label">MONTHLY DIRECTION</span><h2>{month.replace('-', '년 ')}월 계획</h2><p>과제 나열보다 이달에 만들 능력·검증 기준·운영 전략을 먼저 정합니다.</p></div><div><input className="date-input" type="month" value={month} onChange={(event) => setMonth(event.target.value)} /><button className="button primary" onClick={() => openMonthlyEditor()}><Plus size={16} /> 월간 목표</button></div></Card>
      {openMonthly && <Card className="monthly-form"><div className="form-grid two"><Field label="과목"><select value={monthlyDraft.subject} onChange={(event) => setMonthlyDraft({ ...monthlyDraft, subject: event.target.value as Subject, inquiryTrack:event.target.value==='탐구'?monthlyDraft.inquiryTrack:undefined })}>{SUBJECTS.map((item) => <option key={item}>{item}</option>)}</select></Field>{monthlyDraft.subject==='탐구'&&<Field label="탐구 세부"><select value={monthlyDraft.inquiryTrack??'통사'} onChange={event=>setMonthlyDraft({...monthlyDraft,inquiryTrack:event.target.value as '통사'|'통과'})}><option>통사</option><option>통과</option></select></Field>}<Field label="목표명"><input value={monthlyDraft.title} onChange={(event) => setMonthlyDraft({ ...monthlyDraft, title: event.target.value })} placeholder="예: 수1 기출 완주 및 확통 전환" /></Field></div><Field label="이달의 목적"><TextArea value={monthlyDraft.objective} onChange={(value) => setMonthlyDraft({ ...monthlyDraft, objective: value })} placeholder="어떤 능력 또는 범위를 확보할 것인지" /></Field><Field label="검증 기준"><TextArea value={monthlyDraft.successCriterion} onChange={(value) => setMonthlyDraft({ ...monthlyDraft, successCriterion: value })} placeholder="완료 여부를 판단할 점수·문항·재현 기준" /></Field><Field label="운영 전략"><TextArea value={monthlyDraft.strategy} onChange={(value) => setMonthlyDraft({ ...monthlyDraft, strategy: value })} placeholder="주차별 배분, 휴식·모의고사일 조정 원칙" /></Field><div className="modal-actions"><button className="button" type="button" onClick={closeMonthlyEditor}>취소</button><SaveButton onClick={saveMonthly} label={editingMonthlyId ? '월간 목표 수정' : '월간 목표 저장'} /></div></Card>}
      <div className="monthly-goal-grid">{monthlyPlans.length ? monthlyPlans.map((item, index) => <Card className={`monthly-goal-card ${item.done ? 'done' : ''} ${dragging?.kind === 'monthly' && dragging.id === item.id ? 'is-dragging' : ''}`} key={item.id}><article data-month-drop={index} onPointerDown={(event) => startDrag(event, { kind: 'monthly', id: item.id })} onPointerUp={finishDrag} onPointerCancel={cancelDrag}><div><span className="drag-handle" aria-hidden="true"><GripVertical size={16} /></span><span className={`subject-badge ${item.subject}`}>{item.subject}</span><span><button className="monthly-edit" aria-label={`${item.title} 수정`} title="월간 목표 수정" onClick={() => openMonthlyEditor(item)}><Pencil size={14} /></button><button className="goal-check" aria-label={`${item.title} 완료 상태 변경`} onClick={() => toggleMonthly(item.id)}>{item.done ? <Check size={14} /> : '○'}</button><button className="goal-delete" aria-label={`${item.title} 삭제`} onClick={() => removeMonthly(item.id)}><Trash2 size={14} /></button></span></div><h3>{item.title}</h3><section><b>목적</b><p>{item.objective}</p></section><section><b>검증 기준</b><p>{item.successCriterion || '미설정'}</p></section><section><b>운영 전략</b><p>{item.strategy || '미설정'}</p></section></article></Card>) : <Empty>이달에 확보할 능력 또는 완주할 학습 범위를 설정하세요.</Empty>}</div>
      <Card className="monthly-week-summary"><div><span className="card-label">WEEKLY LOAD</span><h3>주차별 배치 현황</h3></div>{monthWeekCount.length ? <div>{monthWeekCount.map(([week, count]) => <span key={week}><b>{week.slice(5).replace('-', '.')} 주</b> {count}개 일정</span>)}</div> : <p>Weekly Plan에서 일정을 추가하면 이달의 주차별 계획량이 표시됩니다.</p>}</Card>
    </>}
    {taskDate && <div className="modal-backdrop" onClick={closeTask}><div className="modal plan-task-modal" onClick={(event) => event.stopPropagation()}><div className="modal-head"><div><p className="eyebrow">{editingTaskId ? 'EDIT DAILY PLAN' : 'ADD DAILY PLAN'}</p><h2>{dateLabel(taskDate)} 일정</h2></div><button onClick={closeTask}><X /></button></div><div className="form-grid two"><Field label="과목"><select value={task.subject} onChange={(event) => setTask({ ...task, subject: event.target.value as Subject, inquiryTrack:event.target.value==='탐구'?task.inquiryTrack:undefined })}>{SUBJECTS.map((item) => <option key={item}>{item}</option>)}</select></Field>{task.subject==='탐구'&&<Field label="탐구 세부"><select value={task.inquiryTrack??'통사'} onChange={event=>setTask({...task,inquiryTrack:event.target.value as '통사'|'통과'})}><option>통사</option><option>통과</option></select></Field>}<Field label="훈련명"><input value={task.title} onChange={(event) => setTask({ ...task, title: event.target.value })} placeholder="예: 수1 뉴런 1단원" /></Field><Field label="세부 내용"><input value={task.detail} onChange={(event) => setTask({ ...task, detail: event.target.value })} placeholder="예: 정적분으로 정의된 함수" /></Field><Field label="목표량"><input value={task.quantity} onChange={(event) => setTask({ ...task, quantity: event.target.value })} placeholder="예: 31문제 · 90분" /></Field></div><PlanLinks data={data} date={taskDate} plan={task} onChange={patch=>setTask({...task,...patch})}/><div className="modal-actions"><SaveButton onClick={saveTask} label={editingTaskId ? '주간 계획 수정' : '주간 계획 추가'} /></div></div></div>}
    {dragHint && <div className="drag-toast">{dragHint}</div>}
  </div>;
}
