# TRINITY OS Library Actions Patch

현재 `main`의 ResourceLibrary 구조 기준 패치입니다.

## 추가 기능

- **공용 기출**
  - PDF 열기
  - 다운로드
  - 내 자료실에 추가

- **내 자료실**
  - PDF 열기
  - 다운로드
  - Daily Plan 연결
  - 삭제

## 삭제 동작

- 개인 업로드 PDF: AppData의 자료 항목 + Supabase 비공개 버킷 PDF 원본을 함께 삭제
- 공용 기출을 내 자료실에 추가한 항목: 내 자료실 연결만 삭제하며 공용 원본은 유지
- 링크/일반 자료: 내 자료실 항목만 삭제
- 기존 Timer/오답/Daily Plan 기록 자체는 보존하고 삭제된 resourceId 연결만 해제

Worker의 `/api/library/files` DELETE는 현재 main에 이미 구현되어 있으므로 Worker 코드 수정은 필요하지 않습니다.

## 적용

TRINITY-OS 루트에 압축을 덮어쓴 뒤:

```bash
bash APPLY_PATCH.sh
```

빌드가 정상이라면:

```bash
git add -A
git commit -m "feat: add library download and delete actions"
git push origin main
```
