# TRINITY OS — Learning Intelligence UI Integration (fixed)

이 패키지는 이전 생성 과정의 CSS/Python 중첩 문자열 오류를 제거한 수정본입니다.

## UI 변경
- Learning Archive에 `Intelligence` 탭 추가
- Active Core Rules Top 10
- Priority / ACTIVE / WATCH / MASTERED / ARCHIVED
- 최근 7/30일 실패, Wrong Answer, Drill, Review, Mastery Rate
- Evidence Timeline
- Wrong Answers: 전체 / 과목별 / 출처별 / 시간별
- Archive: 최초 100개 + cursor 기반 `더 보기`

## 실행
Codespaces 저장소 루트에 ZIP 업로드 후:

```bash
cd /workspaces/TRINITY-OS
rm -rf /tmp/trinity-learning-intelligence-ui
unzip -q -o TRINITY-OS-learning-intelligence-ui-fixed-20260918.zip -d /tmp/trinity-learning-intelligence-ui

python3 /tmp/trinity-learning-intelligence-ui/apply_learning_intelligence_ui.py   --repo /workspaces/TRINITY-OS   --commit   --push
```

스크립트는 `git pull → git diff --check → npm test → npm run build → Worker dry-run`이 전부 성공한 경우에만 commit/push합니다.

DB migration은 추가하지 않습니다. Worker 응답에 Evidence 목록만 추가하므로 마지막에 Worker만 재배포하면 됩니다.
