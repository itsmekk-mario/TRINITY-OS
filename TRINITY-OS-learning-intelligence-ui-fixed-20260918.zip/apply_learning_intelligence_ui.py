#!/usr/bin/env python3
from pathlib import Path
import argparse, subprocess, shutil

def run(cmd,cwd):
    print("+"," ".join(cmd))
    subprocess.run(cmd,cwd=cwd,check=True)

def out(cmd,cwd):
    return subprocess.check_output(cmd,cwd=cwd,text=True).strip()

def replace_once(text,old,new,label):
    count=text.count(old)
    if count!=1:
        raise RuntimeError(f"{label}: expected one anchor, found {count}")
    return text.replace(old,new,1)

def patch_file(path,fn):
    old=path.read_text(encoding="utf-8")
    new=fn(old)
    if new==old:
        print("unchanged",path)
        return
    path.write_text(new,encoding="utf-8")
    print("patched",path)

def patch_api(c):
    anchor="export type ArchivePage={entries:ArchiveEntry[];nextCursor:string|null;hasMore:boolean};"
    if "export type CoreRuleStatus" not in c:
        addition="""export type CoreRuleStatus='ACTIVE'|'WATCH'|'MASTERED'|'ARCHIVED';
export type CoreRuleStats={evidenceCount:number;archiveCount:number;wrongAnswerCount:number;drillCount:number;derivedCount:number;appliedCount:number;failedCount:number;reinforcedCount:number;failures7d:number;failures30d:number;lastOccurrenceAt:string|null;lastFailureAt:string|null;reviewCount:number;reviewSuccessCount:number;reviewFailureCount:number;masteryRate:number|null;linkedItems?:number};
export type CoreRuleEvidence={sourceType:'archive'|'wrong_answer'|'drill'|'review';sourceId:string;relationType:RuleRelation;occurredAt:string;createdAt:string};
export type ActiveCoreRule={id:string;title:string;subject:ArchiveSubject;content:string;tags:string[];masteryStatus:MasteryStatus;priorityScore:number;status:CoreRuleStatus;stats:CoreRuleStats};
export type CoreRuleIntelligence={coreRule:CoreRule|null;linkedItems:unknown[];wrongAnswers:unknown[];drills:unknown[];reviews:unknown[];evidence:CoreRuleEvidence[];stats:CoreRuleStats;priorityScore:number;status:CoreRuleStatus};
"""
        c=replace_once(c,anchor,anchor+"\n"+addition,"archive API intelligence types")
    return c

def patch_worker(c):
    old="""    const [coreRule,linkedItems,wrongAnswers,drills,reviews,stats]=await Promise.all([
      env.DB.prepare('SELECT * FROM core_rules WHERE id=? AND user_id=?').bind(id,user.id).first<Record<string,unknown>>(),
      env.DB.prepare(`SELECT e.*,l.relation_type FROM archive_entries e JOIN archive_entry_core_rules l ON l.archive_entry_id=e.id
        WHERE l.core_rule_id=? AND e.user_id=? ORDER BY e.studied_at DESC,e.updated_at DESC,e.id DESC`).bind(id,user.id).all(),
      env.DB.prepare(`SELECT w.*,l.relation_type FROM wrong_answers w JOIN core_rule_wrong_answer_links l
        ON l.user_id=w.user_id AND l.wrong_answer_id=w.id WHERE l.core_rule_id=? AND w.user_id=? ORDER BY w.updated_at DESC`).bind(id,user.id).all<Record<string,unknown>>(),
      env.DB.prepare(`SELECT d.* FROM learning_drills d JOIN core_rule_drill_links l
        ON l.user_id=d.user_id AND l.drill_id=d.id WHERE l.core_rule_id=? AND d.user_id=? ORDER BY d.updated_at DESC`).bind(id,user.id).all<Record<string,unknown>>(),
      env.DB.prepare(`SELECT * FROM learning_reviews WHERE user_id=? AND target_type='core_rule' AND target_id=?
        ORDER BY COALESCE(reviewed_at,scheduled_at,created_at) DESC`).bind(user.id,id).all(),
      getCoreRuleStats(env.DB,user.id,id),
    ]);"""
    new="""    const [coreRule,linkedItems,wrongAnswers,drills,reviews,evidence,stats]=await Promise.all([
      env.DB.prepare('SELECT * FROM core_rules WHERE id=? AND user_id=?').bind(id,user.id).first<Record<string,unknown>>(),
      env.DB.prepare(`SELECT e.*,l.relation_type FROM archive_entries e JOIN archive_entry_core_rules l ON l.archive_entry_id=e.id
        WHERE l.core_rule_id=? AND e.user_id=? ORDER BY e.studied_at DESC,e.updated_at DESC,e.id DESC`).bind(id,user.id).all(),
      env.DB.prepare(`SELECT w.*,l.relation_type FROM wrong_answers w JOIN core_rule_wrong_answer_links l
        ON l.user_id=w.user_id AND l.wrong_answer_id=w.id WHERE l.core_rule_id=? AND w.user_id=? ORDER BY w.updated_at DESC`).bind(id,user.id).all<Record<string,unknown>>(),
      env.DB.prepare(`SELECT d.* FROM learning_drills d JOIN core_rule_drill_links l
        ON l.user_id=d.user_id AND l.drill_id=d.id WHERE l.core_rule_id=? AND d.user_id=? ORDER BY d.updated_at DESC`).bind(id,user.id).all<Record<string,unknown>>(),
      env.DB.prepare(`SELECT * FROM learning_reviews WHERE user_id=? AND target_type='core_rule' AND target_id=?
        ORDER BY COALESCE(reviewed_at,scheduled_at,created_at) DESC`).bind(user.id,id).all(),
      env.DB.prepare(`SELECT source_type,source_id,relation_type,occurred_at,created_at FROM core_rule_evidence
        WHERE user_id=? AND core_rule_id=? ORDER BY occurred_at DESC,created_at DESC LIMIT 100`).bind(user.id,id).all<Record<string,unknown>>(),
      getCoreRuleStats(env.DB,user.id,id),
    ]);"""
    c=replace_once(c,old,new,"core rule evidence query")
    old2="""      drills:drills.results.map(drillDto),reviews:reviews.results,
      stats:{...stats,linkedItems:linkedItems.results.length,...priority},"""
    new2="""      drills:drills.results.map(drillDto),reviews:reviews.results,
      evidence:evidence.results.map(row=>({sourceType:row.source_type,sourceId:row.source_id,relationType:row.relation_type,occurredAt:row.occurred_at,createdAt:row.created_at})),
      stats:{...stats,linkedItems:linkedItems.results.length,...priority},"""
    return replace_once(c,old2,new2,"core rule evidence response")

def patch_archive(c):
    if "CoreRuleIntelligencePanel" not in c:
        c=c.replace("import ArchiveExplorer,{AnnotationLegend,type ArchiveBrowseMode} from '../components/ArchiveExplorer';",
                    "import ArchiveExplorer,{AnnotationLegend,type ArchiveBrowseMode} from '../components/ArchiveExplorer';\nimport CoreRuleIntelligencePanel from '../components/learning/CoreRuleIntelligencePanel';")
    c=c.replace(
        "import { archiveAllEntries,archiveApi,type ArchiveEntry,type ArchiveSubject,type CoreRule,type MasteryStatus,type RuleRelation }",
        "import { archiveAllEntries,archiveApi,type ArchiveEntry,type ArchivePage,type ArchiveSubject,type CoreRule,type MasteryStatus,type RuleRelation }"
    )
    c=replace_once(
        c,
        "const [view,setView]=useState<'archive'|'rules'|'review'>('archive'),[entries,setEntries]=useState<ArchiveEntry[]>([]),",
        "const [view,setView]=useState<'archive'|'rules'|'intelligence'|'review'>('archive'),[entries,setEntries]=useState<ArchiveEntry[]>([]),[archiveCursor,setArchiveCursor]=useState<string|null>(null),[archiveHasMore,setArchiveHasMore]=useState(false),",
        "archive state"
    )
    old_load=""" const load=async()=>{setBusy(true);setError('');try{const params=new URLSearchParams();if(query)params.set('q',query);if(subject)params.set('subject',subject);if(color)params.set('color',color);if(year)params.set('year',year);if(month)params.set('month',month);if(institution)params.set('institution',institution);if(examFilter)params.set('exam',examFilter);if(subcategory)params.set('subcategory',subcategory);if(coreFilter)params.set('coreRule',coreFilter);const [archiveEntries,r,reviewEntries]=await Promise.all([archiveAllEntries('/api/archive/entries',params),archiveApi<{rules:CoreRule[]}>('/api/archive/rules'),archiveAllEntries('/api/archive/review')]);const reviews=new Map(reviewEntries.map(entry=>[entry.id,entry]));const merged=archiveEntries.map(entry=>({...entry,...(reviews.get(entry.id)||{})}));setEntries(merged);setRules(r.rules);setSelected(current=>current?merged.find(entry=>entry.id===current.id):undefined);}catch(e){setError(e instanceof Error?e.message:'불러오지 못했습니다.')}finally{setBusy(false)}};"""
    new_load=""" const archiveParams=()=>{const params=new URLSearchParams();params.set('limit','100');if(query)params.set('q',query);if(subject)params.set('subject',subject);if(color)params.set('color',color);if(year)params.set('year',year);if(month)params.set('month',month);if(institution)params.set('institution',institution);if(examFilter)params.set('exam',examFilter);if(subcategory)params.set('subcategory',subcategory);if(coreFilter)params.set('coreRule',coreFilter);return params};
 const load=async()=>{setBusy(true);setError('');try{const params=archiveParams();const [page,r,allReviews]=await Promise.all([archiveApi<ArchivePage>(`/api/archive/entries?${params.toString()}`),archiveApi<{rules:CoreRule[]}>('/api/archive/rules'),archiveAllEntries('/api/archive/review')]);const reviews=new Map(allReviews.map(entry=>[entry.id,entry]));const merged=page.entries.map(entry=>({...entry,...(reviews.get(entry.id)||{})}));setEntries(merged);setArchiveCursor(page.nextCursor);setArchiveHasMore(page.hasMore);setReviewEntries(allReviews);setRules(r.rules);setSelected(current=>current?merged.find(entry=>entry.id===current.id):undefined);}catch(e){setError(e instanceof Error?e.message:'불러오지 못했습니다.')}finally{setBusy(false)}};
 const loadMoreArchive=async()=>{if(!archiveHasMore||!archiveCursor||busy)return;setBusy(true);setError('');try{const params=archiveParams();params.set('cursor',archiveCursor);const page=await archiveApi<ArchivePage>(`/api/archive/entries?${params.toString()}`),reviews=new Map(reviewEntries.map(entry=>[entry.id,entry]));const next=page.entries.map(entry=>({...entry,...(reviews.get(entry.id)||{})}));setEntries(current=>{const ids=new Set(current.map(entry=>entry.id));return [...current,...next.filter(entry=>!ids.has(entry.id))]});setArchiveCursor(page.nextCursor);setArchiveHasMore(page.hasMore);}catch(e){setError(e instanceof Error?e.message:'추가 Archive 조회 실패')}finally{setBusy(false)}};"""
    c=replace_once(c,old_load,new_load,"archive cursor load")

    old_review=""" const openReview=async()=>{setView('review');try{const value=await archiveApi<{entries:ArchiveEntry[]}>('/api/archive/review');setReviewEntries(value.entries)}catch(e){setError(e instanceof Error?e.message:'Review 조회 실패')}};"""
    new_review=""" const openReview=async()=>{setView('review');try{setReviewEntries(await archiveAllEntries('/api/archive/review'))}catch(e){setError(e instanceof Error?e.message:'Review 조회 실패')}};"""
    c=replace_once(c,old_review,new_review,"review paginated load")

    c=replace_once(
        c,
        "([['archive','Archive'],['rules','Core Rules'],['review','Review']] as const)",
        "([['archive','Archive'],['rules','Core Rules'],['intelligence','Intelligence'],['review','Review']] as const)",
        "archive tabs"
    )

    marker=" {view==='archive'&&<section className=\"archive-explorer-panel\">"
    load_more=""" {view==='archive'&&archiveHasMore&&<div className="archive-load-more"><button className="button" disabled={busy} onClick={()=>void loadMoreArchive()}>{busy?'불러오는 중…':'더 보기'}</button><small>현재 {entries.length}개 표시</small></div>}
"""
    c=replace_once(c,marker,load_more+marker,"archive load more button")

    review_marker=" {view==='review'&&<div>"
    intel=" {view==='intelligence'&&<CoreRuleIntelligencePanel onEditRule={startRuleEdit}/>}\\n"
    c=replace_once(c,review_marker,intel+review_marker,"intelligence tab body")
    return c

def patch_train(c):
    c=replace_once(
        c,
        "const [view, setView] = useState<'all'|'subject'>('all');",
        "const [view, setView] = useState<'all'|'subject'|'source'|'time'>('all');",
        "wrong answer modes"
    )
    old_groups="""  const subjects = ['국어','수학','영어','탐구','기타'] as const;
  const grouped = subjects.map(subject => ({ subject, items: items.filter(item => subject === '기타' ? !['국어','수학','영어','탐구'].includes(item.subject) : item.subject === subject) })).filter(group => group.items.length);
  const due = (group:WrongAnswerDrill[]) => group.flatMap(item => item.retries ?? []).filter(retry => !retry.completedDate && retry.dueDate <= new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Seoul'})).length;"""
    new_groups="""  const subjects = ['국어','수학','영어','탐구','기타'] as const;
  const subjectGroups = subjects.map(subject => ({ key:`subject:${subject}`, label:subject, items: items.filter(item => subject === '기타' ? !['국어','수학','영어','탐구'].includes(item.subject) : item.subject === subject) })).filter(group => group.items.length);
  const sourceGroups = [...new Set(items.map(item=>item.source?.trim()||'출처 미지정'))].map(source=>({key:`source:${source}`,label:source,items:items.filter(item=>(item.source?.trim()||'출처 미지정')===source)})).sort((a,b)=>b.items.length-a.items.length||a.label.localeCompare(b.label));
  const timeGroups = [...new Set(items.map(item=>item.date||'날짜 미지정'))].sort((a,b)=>b.localeCompare(a)).map(date=>({key:`time:${date}`,label:date,items:items.filter(item=>(item.date||'날짜 미지정')===date)}));
  const due = (group:WrongAnswerDrill[]) => group.flatMap(item => item.retries ?? []).filter(retry => !retry.completedDate && retry.dueDate <= new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Seoul'})).length;
  const renderGroups=(groups:{key:string;label:string;items:WrongAnswerDrill[]}[])=><div className="wrong-subject-groups">{groups.map((group,index)=>{const expanded=open[group.key]??index===0;const pending=group.items.filter(item=>(item.retries??[]).some(retry=>!retry.completedDate)).length;return <section key={group.key}><button className="wrong-subject-header" onClick={()=>setOpen(value=>({...value,[group.key]:!expanded}))}><span><b>{group.label}</b><small>오답 {group.items.length}개 · 미복습 {pending}개 · 재도전 예정 {due(group.items)}개</small></span><span>{expanded?'접기':'펼치기'}</span></button>{expanded&&<div className="wrong-library">{group.items.map(card)}</div>}</section>})}</div>;"""
    c=replace_once(c,old_groups,new_groups,"wrong answer groups")
    old_render="""    {items.length ? <><div className="wrong-view-toggle"><button className={view==='all'?'active':''} onClick={()=>setView('all')}>전체</button><button className={view==='subject'?'active':''} onClick={()=>setView('subject')}>과목별</button></div>{view==='all'?<div className="wrong-library">{items.map(card)}</div>:<div className="wrong-subject-groups">{grouped.map(group=>{const expanded=open[group.subject]!==false;const pending=group.items.filter(item=>(item.retries??[]).some(retry=>!retry.completedDate)).length;return <section key={group.subject}><button className="wrong-subject-header" onClick={()=>setOpen(value=>({...value,[group.subject]:!expanded}))}><span><b>{group.subject}</b><small>오답 {group.items.length}개 · 미복습 {pending}개 · 재도전 예정 {due(group.items)}개</small></span><span>{expanded?'접기':'펼치기'}</span></button>{expanded&&<div className="wrong-library">{group.items.map(card)}</div>}</section>;})}</div>}</> : <Empty"""
    new_render="""    {items.length ? <><div className="wrong-view-toggle"><button className={view==='all'?'active':''} onClick={()=>setView('all')}>전체</button><button className={view==='subject'?'active':''} onClick={()=>setView('subject')}>과목별</button><button className={view==='source'?'active':''} onClick={()=>setView('source')}>출처별</button><button className={view==='time'?'active':''} onClick={()=>setView('time')}>시간별</button></div>{view==='all'?<div className="wrong-library">{items.map(card)}</div>:view==='subject'?renderGroups(subjectGroups):view==='source'?renderGroups(sourceGroups):renderGroups(timeGroups)}</> : <Empty"""
    return replace_once(c,old_render,new_render,"wrong answer mode UI")

def patch_styles(c,payload):
    marker="/* Learning Intelligence UI */"
    if marker not in c:
        c += "\n" + (payload/"styles-addition.css").read_text(encoding="utf-8") + "\n"
    return c

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--repo",default=".")
    parser.add_argument("--commit",action="store_true")
    parser.add_argument("--push",action="store_true")
    args=parser.parse_args()
    repo=Path(args.repo).resolve()
    payload=Path(__file__).resolve().parent/"payload"

    if out(["git","branch","--show-current"],repo)!="main":
        raise SystemExit("main branch에서 실행하세요.")
    dirty=out(["git","status","--porcelain"],repo)
    if dirty:
        raise SystemExit("Working tree가 clean하지 않습니다. 먼저 commit/stash 하세요.\n"+dirty)

    run(["git","pull","origin","main"],repo)
    print("HEAD",out(["git","rev-parse","HEAD"],repo))

    component=repo/"src/components/learning/CoreRuleIntelligencePanel.tsx"
    component.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(payload/"CoreRuleIntelligencePanel.tsx",component)
    shutil.copy2(payload/"learning-intelligence-ui.test.mjs",repo/"tests/learning-intelligence-ui.test.mjs")

    patch_file(repo/"src/lib/archiveApi.ts",patch_api)
    patch_file(repo/"worker/src/learning-intelligence.ts",patch_worker)
    patch_file(repo/"src/pages/LearningArchive.tsx",patch_archive)
    patch_file(repo/"src/pages/TrainHub.tsx",patch_train)
    patch_file(repo/"src/styles.css",lambda c:patch_styles(c,payload))

    run(["git","diff","--check"],repo)
    run(["npm","test"],repo)
    run(["npm","run","build"],repo)
    run(["npm","ci"],repo/"worker")
    run(["npx","wrangler","deploy","--dry-run","--config",str(repo/"worker/wrangler.toml"),"--outdir",str(repo/".worker-dist")],repo/"worker")
    shutil.rmtree(repo/".worker-dist",ignore_errors=True)

    print("\nChanged files:\n"+out(["git","status","--short"],repo))
    if args.commit or args.push:
        run(["git","add","src/lib/archiveApi.ts","src/pages/LearningArchive.tsx","src/pages/TrainHub.tsx","src/components/learning/CoreRuleIntelligencePanel.tsx","src/styles.css","worker/src/learning-intelligence.ts","tests/learning-intelligence-ui.test.mjs"],repo)
        run(["git","commit","-m","feat: surface learning intelligence in UI"],repo)
        print("COMMIT",out(["git","rev-parse","HEAD"],repo))
    if args.push:
        run(["git","push","origin","main"],repo)
        print("pushed main")

    print("\nDB migration은 없습니다.")
    print("Worker API 응답이 바뀌므로 push 이후 Worker만 재배포하세요:")
    print("cd worker && npx wrangler deploy --config wrangler.toml")

if __name__=="__main__":
    main()
