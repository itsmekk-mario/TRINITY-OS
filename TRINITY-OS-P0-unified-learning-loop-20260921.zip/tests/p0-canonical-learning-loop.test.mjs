import assert from 'node:assert/strict';
import {test} from 'node:test';
import {DatabaseSync} from 'node:sqlite';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import worker from '../worker/src/index.ts';
import {studyDaySchedule} from '../worker/src/reviews.ts';
import {syncLearningProjection} from '../worker/src/learning-graph.ts';

const hash=value=>createHash('sha256').update(value).digest('hex');
const wrap=(stmt,args=[])=>({bind:(...values)=>wrap(stmt,values),first:async()=>stmt.get(...args)??null,run:async()=>stmt.run(...args),all:async()=>({results:stmt.all(...args)})});
function harness(){
 const raw=new DatabaseSync(':memory:');raw.exec('PRAGMA foreign_keys=ON');raw.exec(readFileSync(new URL('../worker/schema.sql',import.meta.url),'utf8'));
 raw.prepare("INSERT INTO users(id,username,created_at,active) VALUES(1,'a','x',1),(2,'b','x',1)").run();
 raw.prepare("INSERT INTO learning_state(user_id,payload,updated_at) VALUES(1,?,'2026-09-21T00:00:00.000Z'),(2,?,'2026-09-21T00:00:00.000Z')").run(JSON.stringify({wrongAnswerDrills:[],dailyDrills:[]}),JSON.stringify({wrongAnswerDrills:[],dailyDrills:[]}));
 const expires=new Date(Date.now()+86400000).toISOString();raw.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').run(hash('a'),1,expires,'x');raw.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').run(hash('b'),2,expires,'x');
 const DB={prepare:sql=>wrap(raw.prepare(sql)),batch:async list=>{raw.exec('BEGIN');try{const out=[];for(const statement of list)out.push(await statement.run());raw.exec('COMMIT');return out}catch(error){raw.exec('ROLLBACK');throw error}}};
 const env={DB,ALLOWED_ORIGIN:'https://trinityos.mcv.kr',ENVIRONMENT:'production'};
 const call=(path,{method='GET',token='a',body}={})=>worker.fetch(new Request(`https://worker.test${path}`,{method,headers:{Authorization:`Bearer ${token}`,...(body===undefined?{}:{'Content-Type':'application/json'})},...(body===undefined?{}:{body:JSON.stringify(body)})}),env);
 return{raw,DB,call};
}
const wrong={requestId:'wa-request-1',date:'2026-09-21',subject:'수학',source:'뉴런 수2',question:'21번',wrongJudgment:'필요조건만 확인',missedCue:'경계값',correction:'원조건 재대입',transfer:'유사문항 검증',bottleneck:'전략·판단'};

test('Wrong Answer canonical CRUD is idempotent and creates 3/7/14 reviews',async()=>{
 const h=harness(),first=await h.call('/api/wrong-answers',{method:'POST',body:wrong});assert.equal(first.status,201);const created=await first.json();
 assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM wrong_answers WHERE user_id=1').get().count,1);
 assert.deepEqual(h.raw.prepare("SELECT review_type FROM learning_reviews WHERE user_id=1 AND target_type='wrong_answer' ORDER BY scheduled_at").all().map(row=>row.review_type),['retry_3d','retry_7d','retry_14d']);
 const duplicate=await h.call('/api/wrong-answers',{method:'POST',body:wrong});assert.equal(duplicate.status,200);assert.equal((await duplicate.json()).wrongAnswer.id,created.wrongAnswer.id);assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM wrong_answers WHERE user_id=1').get().count,1);
 const updated=await h.call(`/api/wrong-answers/${created.wrongAnswer.id}`,{method:'PATCH',body:{...wrong,correction:'경계값부터 재대입'}});assert.equal(updated.status,200);assert.equal((await updated.json()).wrongAnswer.correction,'경계값부터 재대입');
 assert.equal((await h.call(`/api/wrong-answers/${created.wrongAnswer.id}`,{token:'b'})).status,404);
});

test('Archive and Core Rule links create evidence and Wrong Answer delete has no orphans',async()=>{
 const h=harness(),now='2026-09-21T00:00:00.000Z';h.raw.prepare("INSERT INTO archive_entries(id,user_id,subject,year,month,institution,title,studied_at,mastery_status,memo,created_at,updated_at) VALUES('entry',1,'math',2027,9,'KICE','entry','2026-09-21','input','',?,?)").run(now,now);h.raw.prepare("INSERT INTO core_rules VALUES('rule',1,'math','rule','content','[]','input',?,?)").run(now,now);
 const response=await h.call('/api/wrong-answers',{method:'POST',body:{...wrong,requestId:'linked',archiveEntryId:'entry',coreRuleId:'rule'}}),id=(await response.json()).wrongAnswer.id;
 assert.equal(h.raw.prepare('SELECT wrong_answer_id FROM archive_wrong_answer_links').get().wrong_answer_id,id);assert.equal(h.raw.prepare("SELECT COUNT(*) count FROM core_rule_evidence WHERE source_type='wrong_answer'").get().count,1);
 assert.equal((await h.call(`/api/wrong-answers/${id}`,{method:'DELETE'})).status,200);
 for(const table of ['wrong_answers','archive_wrong_answer_links','core_rule_wrong_answer_links','learning_reviews','core_rule_evidence'])assert.equal(h.raw.prepare(`SELECT COUNT(*) count FROM ${table}`).get().count,0,table);
});

test('Wrong Answer archive reassignment is atomic and rejects foreign entries',async()=>{
 const h=harness(),now='2026-09-21T00:00:00.000Z';
 h.raw.prepare("INSERT INTO archive_entries(id,user_id,subject,year,month,institution,title,studied_at,mastery_status,memo,created_at,updated_at) VALUES('mine',1,'math',2027,9,'KICE','mine','2026-09-21','input','',?,?),('foreign',2,'math',2027,9,'KICE','foreign','2026-09-21','input','',?,?)").run(now,now,now,now);
 const created=await(await h.call('/api/wrong-answers',{method:'POST',body:{...wrong,requestId:'archive-patch',archiveEntryId:'mine'}})).json(),id=created.wrongAnswer.id;
 const foreign=await h.call(`/api/wrong-answers/${id}`,{method:'PATCH',body:{...wrong,archiveEntryId:'foreign'}});
 assert.equal(foreign.status,404);
 assert.equal(h.raw.prepare('SELECT archive_entry_id FROM wrong_answers WHERE user_id=1 AND id=?').get(id).archive_entry_id,'mine');
 assert.equal(h.raw.prepare('SELECT archive_entry_id FROM archive_wrong_answer_links WHERE user_id=1 AND wrong_answer_id=?').get(id).archive_entry_id,'mine');
 const cleared=await h.call(`/api/wrong-answers/${id}`,{method:'PATCH',body:{...wrong,archiveEntryId:''}});
 assert.equal(cleared.status,200);
 assert.equal(h.raw.prepare('SELECT archive_entry_id FROM wrong_answers WHERE user_id=1 AND id=?').get(id).archive_entry_id,null);
 assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM archive_wrong_answer_links WHERE user_id=1 AND wrong_answer_id=?').get(id).count,0);
});

test('Drill canonical CRUD links Core Rule evidence and cleans deletion',async()=>{
 const h=harness(),now='2026-09-21T00:00:00.000Z';h.raw.prepare("INSERT INTO core_rules VALUES('rule',1,'math','rule','content','[]','input',?,?)").run(now,now);
 const body={requestId:'drill-request',date:'2026-09-21',subject:'수학',title:'경계값 Drill',action:'후보 재대입',successCriterion:'3문항 재현',minutes:20,done:false,reflection:'',coreRuleId:'rule',reviewAt:'2026-09-24T21:00:00.000Z'};
 const created=await h.call('/api/drills',{method:'POST',body});assert.equal(created.status,201);const id=(await created.json()).drill.id;
 assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM core_rule_drill_links').get().count,1);assert.equal(h.raw.prepare("SELECT relation_type FROM core_rule_evidence WHERE source_type='drill'").get().relation_type,'applied');assert.equal(h.raw.prepare("SELECT COUNT(*) count FROM learning_reviews WHERE target_type='drill'").get().count,1);
 assert.equal((await h.call(`/api/drills/${id}`,{method:'PATCH',body:{...body,done:true}})).status,200);assert.equal(h.raw.prepare('SELECT done FROM learning_drills').get().done,1);assert.equal((await h.call(`/api/drills/${id}`,{token:'b'})).status,404);
 await h.call(`/api/drills/${id}`,{method:'DELETE'});assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM learning_drills').get().count,0);assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM core_rule_evidence').get().count,0);
});

test('Review completion immediately records reinforced and failed Core Rule evidence',async()=>{
 const h=harness(),now='2026-09-21T00:00:00.000Z';h.raw.prepare("INSERT INTO core_rules VALUES('rule',1,'math','rule','content','[]','input',?,?)").run(now,now);
 for(const [suffix,result] of [['success','success'],['fail','fail']]){const created=await h.call('/api/learning-intelligence/reviews',{method:'POST',body:{targetType:'core_rule',targetId:'rule',reviewType:`manual_${suffix}`,scheduledAt:`2026-09-2${suffix==='success'?1:2}T21:00:00.000Z`,result:'pending'}}),id=(await created.json()).id;await h.call(`/api/learning-intelligence/reviews/${id}`,{method:'PATCH',body:{result}})}
 assert.deepEqual(h.raw.prepare("SELECT relation_type FROM core_rule_evidence WHERE source_type='review' ORDER BY relation_type").all().map(row=>row.relation_type),['failed','reinforced']);
 const intelligence=await(await h.call('/api/core-rules/rule/intelligence')).json();assert.equal(intelligence.stats.reviewSuccessCount,1);assert.equal(intelligence.stats.reviewFailureCount,1);
});

test('Study Day retry schedules start at 06:00 Asia/Seoul',()=>{
 assert.equal(studyDaySchedule('2026-09-21',3),'2026-09-23T21:00:00.000Z');
 assert.equal(new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',hour:'2-digit',hourCycle:'h23'}).format(new Date(studyDaySchedule('2026-09-21',3))),'06');
});

test('legacy sync projection is additive and cannot delete canonical records',async()=>{
 const h=harness(),created=await(await h.call('/api/wrong-answers',{method:'POST',body:wrong})).json(),id=created.wrongAnswer.id;assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM wrong_answers').get().count,1);await syncLearningProjection(h.DB,1,{wrongAnswerDrills:[],dailyDrills:[]},'2026-09-22T00:00:00.000Z');assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM wrong_answers').get().count,1);
 const app={calendar:{},sessions:[],mockSchedule:[],journals:{},scores:[],resources:[],goals:[],weeklyCapabilityGoals:[],wrongAnswerDrills:[{...created.wrongAnswer,id,correction:'stale browser value'}],dailyDrills:[],monthlyPlans:[],notionPages:[],routine:[],quotes:[],examDate:'2026-11-19',googleClientId:'',plaire:{},trinity:[]};assert.equal((await h.call('/api/sync',{method:'PUT',body:{data:app}})).status,200);assert.equal(h.raw.prepare('SELECT correction FROM wrong_answers WHERE id=?').get(id).correction,'원조건 재대입');
});

test('Backup v2 exports and restores canonical Wrong Answer, Drill, and Reviews',async()=>{
 const h=harness();
 await h.call('/api/wrong-answers',{method:'POST',body:{...wrong,requestId:'backup-wa'}});
 await h.call('/api/drills',{method:'POST',body:{requestId:'backup-drill',date:'2026-09-21',subject:'수학',title:'복구 Drill',action:'원조건 확인',successCriterion:'3문항 성공',minutes:15,done:false,reflection:'',reviewAt:'2026-09-24T21:00:00.000Z'}});
 const backup=await(await h.call('/api/archive/export')).json();
 assert.deepEqual([backup.wrongAnswers.length,backup.drills.length,backup.learningReviews.length],[1,1,4]);
 const restored=await h.call('/api/archive/import',{method:'POST',token:'b',body:backup});
 assert.equal(restored.status,200);
 assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM wrong_answers WHERE user_id=2').get().count,1);
 assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM learning_drills WHERE user_id=2').get().count,1);
 assert.equal(h.raw.prepare('SELECT COUNT(*) count FROM learning_reviews WHERE user_id=2').get().count,4);
});
