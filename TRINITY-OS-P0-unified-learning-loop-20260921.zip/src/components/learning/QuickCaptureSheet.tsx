import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { X } from 'lucide-react';
import type { DrillBottleneck, Subject } from '../../types';
import { toDateKey } from '../../lib/date';
import { classifyWrongAnswer, suggestCoreRules } from '../../lib/drillClassification';
import { wrongAnswersApi } from '../../lib/api/wrongAnswers';
import { coreRulesApi } from '../../lib/api/coreRules';
import { queryKeys } from '../../lib/api/queryKeys';
import { invalidateLearningLoop } from '../../lib/api/invalidation';
import { subjectToCode } from '../../lib/subject';

const DRILL_BOTTLENECKS: DrillBottleneck[]=['발문·해석','개념 공백','계산 실수','시간 관리','전략·판단','기타'];

export default function QuickCaptureSheet({open,onClose}:{open:boolean;onClose:()=>void}){
 const client=useQueryClient();
 const [subject,setSubject]=useState<Subject>('수학'),[source,setSource]=useState(''),[question,setQuestion]=useState(''),[wrongJudgment,setWrongJudgment]=useState(''),[missedCue,setMissedCue]=useState(''),[correction,setCorrection]=useState(''),[nextAction,setNextAction]=useState(''),[bottleneck,setBottleneck]=useState<DrillBottleneck>('전략·판단'),[ruleId,setRuleId]=useState(''),[error,setError]=useState(''),[saved,setSaved]=useState(false),[requestId,setRequestId]=useState(()=>crypto.randomUUID());
 const rulesQuery=useQuery({queryKey:queryKeys.coreRules,queryFn:coreRulesApi.list,enabled:open});
 const rules=rulesQuery.data?.rules??[];
 const mutation=useMutation({mutationFn:wrongAnswersApi.quickCapture,onSuccess:async()=>{await invalidateLearningLoop(client,'wrong-answer')}});
 useEffect(()=>{if(open){setSaved(false);setError('');setRequestId(crypto.randomUUID())}},[open]);
 const input={subject,source,question,wrongJudgment,missedCue,correction,nextAction},suggestion=classifyWrongAnswer(input),ruleSuggestions=suggestCoreRules(rules,input);
 const submit=async()=>{if(mutation.isPending)return;setError('');try{await mutation.mutateAsync({requestId,subject,coreRuleId:ruleId||undefined,wrongAnswer:{date:toDateKey(),source,question,wrongJudgment,missedCue,correction,nextAction,bottleneck}});setSaved(true)}catch(cause){setError(cause instanceof Error?cause.message:'저장에 실패했습니다.')}};
 if(!open)return null;const code=subjectToCode(subject);
 return <div className="sheet-backdrop" onClick={()=>!mutation.isPending&&onClose()}><aside className="detail-sheet quick-capture-sheet" role="dialog" aria-modal="true" aria-label="빠른 오답 기록" onClick={event=>event.stopPropagation()}><header><div><span className="eyebrow">QUICK CAPTURE</span><h2>빠른 오답 기록</h2><p>판단 오류와 다음 행동만 기록하면 3·7·14일 재도전이 생성됩니다.</p></div><button className="icon-button" aria-label="닫기" onClick={onClose}><X/></button></header><div className="sheet-content">{saved?<section><h3>오답 기록 완료</h3><p>재도전 일정과 선택한 Core Rule 연결을 저장했습니다.</p><button className="button primary" onClick={onClose}>완료</button></section>:<><label>과목<select value={subject} onChange={event=>{setSubject(event.target.value as Subject);setRuleId('')}}>{['국어','수학','영어','탐구'].map(value=><option key={value}>{value}</option>)}</select></label><label>출처<input value={source} onChange={event=>setSource(event.target.value)} placeholder="뉴런 수2 Theme 9"/></label><label>문항<input value={question} onChange={event=>setQuestion(event.target.value)} placeholder="21번"/></label><label>잘못된 판단<textarea value={wrongJudgment} onChange={event=>setWrongJudgment(event.target.value)}/></label><label>놓친 단서<textarea value={missedCue} onChange={event=>setMissedCue(event.target.value)}/></label><label>다음 행동<textarea value={correction} onChange={event=>setCorrection(event.target.value)}/></label><section className="quick-capture-suggestion"><b>추천 병목 · {suggestion.primary}</b><p>{suggestion.rationale}</p><button className="button small" type="button" onClick={()=>setBottleneck(suggestion.primary)}>적용</button></section><label>병목<select value={bottleneck} onChange={event=>setBottleneck(event.target.value as DrillBottleneck)}>{DRILL_BOTTLENECKS.map(value=><option key={value}>{value}</option>)}</select></label><label>Core Rule 연결 (선택)<select value={ruleId} onChange={event=>setRuleId(event.target.value)}><option value="">연결 안 함</option>{rules.filter(rule=>rule.subject===code).map(rule=><option key={rule.id} value={rule.id}>{rule.title}</option>)}</select></label>{ruleSuggestions.length>0&&<section className="quick-capture-suggestion"><b>추천 Core Rule</b>{ruleSuggestions.map(({rule})=><button type="button" className="text-button" key={rule.id} onClick={()=>setRuleId(rule.id)}>{rule.title} 적용</button>)}</section>}{(error||rulesQuery.error)&&<p role="alert" className="team-error">{error||(rulesQuery.error instanceof Error?rulesQuery.error.message:'Core Rule 조회 실패')}</p>}<button className="button primary" disabled={mutation.isPending||!source.trim()||!question.trim()||!wrongJudgment.trim()||!missedCue.trim()||!correction.trim()} onClick={()=>void submit()}>{mutation.isPending?'저장 중…':'저장'}</button></>}</div></aside></div>;
}
