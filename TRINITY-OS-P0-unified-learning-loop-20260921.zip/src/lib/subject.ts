import type { Subject } from '../types';
export type SubjectCode='korean'|'math'|'english'|'inquiry';
const pairs:[Subject,SubjectCode][]=[['국어','korean'],['수학','math'],['영어','english'],['탐구','inquiry']];
const toCode=new Map<Subject,SubjectCode>(pairs),fromCode=new Map<SubjectCode,Subject>(pairs.map(([label,code])=>[code,label]));
export const subjectToCode=(subject:Subject)=>toCode.get(subject)??'inquiry';
export const subjectFromCode=(code:string):Subject=>fromCode.get(code as SubjectCode)??'탐구';
export const subjectLabel=(value:string)=>fromCode.get(value as SubjectCode)??value;
