export const queryKeys={
  wrongAnswers:['wrong-answers'] as const,
  wrongAnswer:(id:string)=>['wrong-answer',id] as const,
  drills:['drills'] as const,
  drill:(id:string)=>['drill',id] as const,
  reviewQueue:['review-queue'] as const,
  coreRules:['core-rules'] as const,
  coreRule:(id:string)=>['core-rule',id] as const,
  activeCoreRules:['active-core-rules'] as const,
  archive:['archive'] as const,
  archiveEntry:(id:string)=>['archive-entry',id] as const,
  learningIntelligence:['learning-intelligence'] as const,
  todayLearningExecution:['today-learning-execution'] as const,
};
