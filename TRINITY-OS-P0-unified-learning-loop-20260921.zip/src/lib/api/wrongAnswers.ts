import type { WrongAnswerDrill } from '../../types';
import { apiRequest } from './client';

export type WrongAnswerList={items:WrongAnswerDrill[];nextCursor:string|null;hasMore:boolean};
export type WrongAnswerInput=Omit<WrongAnswerDrill,'id'|'retries'>&{id?:string;requestId?:string;coreRuleId?:string;coreRuleIds?:string[]};

export const wrongAnswersApi={
  list:(params:Record<string,string|undefined>={})=>{const query=new URLSearchParams();for(const [key,value] of Object.entries(params))if(value)query.set(key,value);const suffix=query.size?`?${query}`:'';return apiRequest<WrongAnswerList>(`/api/wrong-answers${suffix}`)},
  get:(id:string)=>apiRequest<{wrongAnswer:WrongAnswerDrill}>(`/api/wrong-answers/${encodeURIComponent(id)}`),
  create:(value:WrongAnswerInput)=>apiRequest<{wrongAnswer:WrongAnswerDrill;recovered:boolean}>('/api/wrong-answers','POST',value),
  update:(id:string,value:Partial<WrongAnswerInput>)=>apiRequest<{wrongAnswer:WrongAnswerDrill}>(`/api/wrong-answers/${encodeURIComponent(id)}`,'PATCH',value),
  remove:(id:string)=>apiRequest<{ok:boolean}>(`/api/wrong-answers/${encodeURIComponent(id)}`,'DELETE'),
  quickCapture:(value:Record<string,unknown>)=>apiRequest<{wrongAnswer:WrongAnswerDrill;wrongAnswerId:string;recovered?:boolean}>('/api/learning-intelligence/quick-capture','POST',value),
};
