import { apiRequest } from './client';
import type { WrongAnswerDrill } from '../../types';
export type LearningIntelligenceSummary={items:number;coreRules:number;wrongAnswers:number;drills:number;reviews:{count:number;successes:number;failures:number}};
export type AIWrongAnswerGraph={summary:string;patterns:{name:string;evidenceIds:string[];explanation:string}[];links:{sourceId:string;targetId:string;relationType:string;score:number;rationale:string}[];recommendations:{title:string;reason:string;action:string;successCriterion:string;priority:number;wrongAnswerIds:string[]}[]};
export const learningIntelligenceApi={
  summary:()=>apiRequest<LearningIntelligenceSummary>('/api/learning-intelligence'),
  item:(id:string)=>apiRequest<{wrongAnswers:WrongAnswerDrill[]}>(`/api/learning-intelligence/items/${encodeURIComponent(id)}`),
  analyzeWrongAnswers:(subject?:string)=>apiRequest<{analysis:AIWrongAnswerGraph}>('/api/ai/learning-graph/analyze','POST',{subject:subject||'',force:true}),
};
