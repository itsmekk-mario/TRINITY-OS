import type { DailyDrill } from '../../types';
import { apiRequest } from './client';

export type DrillInput=Omit<DailyDrill,'id'>&{id?:string;requestId?:string;coreRuleId?:string;coreRuleIds?:string[];reviewAt?:string};
export const drillsApi={
  list:(params:Record<string,string|undefined>={})=>{const query=new URLSearchParams();for(const [key,value] of Object.entries(params))if(value)query.set(key,value);const suffix=query.size?`?${query}`:'';return apiRequest<{items:DailyDrill[]}>(`/api/drills${suffix}`)},
  get:(id:string)=>apiRequest<{drill:DailyDrill}>(`/api/drills/${encodeURIComponent(id)}`),
  create:(value:DrillInput)=>apiRequest<{drill:DailyDrill;recovered:boolean}>('/api/drills','POST',value),
  update:(id:string,value:Partial<DrillInput>)=>apiRequest<{drill:DailyDrill}>(`/api/drills/${encodeURIComponent(id)}`,'PATCH',value),
  remove:(id:string)=>apiRequest<{ok:boolean}>(`/api/drills/${encodeURIComponent(id)}`,'DELETE'),
};
