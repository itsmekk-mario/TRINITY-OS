import type { ArchivePage } from '../archiveApi';
import { apiRequest } from './client';
export const archiveRepository={
  list:(query='')=>apiRequest<ArchivePage>(`/api/archive/entries${query?`?${query}`:''}`),
  detail:(id:string)=>apiRequest<ArchivePage>(`/api/archive/entries/${encodeURIComponent(id)}`),
};
