import { apiRequest } from './client';

export type ReviewQueueItem={id:string;targetType:'wrong_answer'|'core_rule'|'drill'|'learning_item';targetId:string;subject:string;title:string;reason:string;scheduledAt:string;priority:number;notes:string;detail:Record<string,unknown>};
export type ReviewQueue={overdue:ReviewQueueItem[];today:ReviewQueueItem[];upcoming:ReviewQueueItem[];counts:{overdue:number;today:number;upcoming:number;due:number}};
export const reviewsApi={
  queue:()=>apiRequest<ReviewQueue>('/api/learning-intelligence/reviews?view=queue'),
  create:(value:Record<string,unknown>)=>apiRequest<{ok:boolean;id:string}>('/api/learning-intelligence/reviews','POST',value),
  update:(id:string,value:Record<string,unknown>)=>apiRequest<{ok:boolean;reviewedAt:string|null;updatedAt:string}>(`/api/learning-intelligence/reviews/${encodeURIComponent(id)}`,'PATCH',value),
  remove:(id:string)=>apiRequest<{ok:boolean}>(`/api/learning-intelligence/reviews/${encodeURIComponent(id)}`,'DELETE'),
};
