import { loadCloudflareConfig } from '../cloudflare';

export async function apiRequest<T>(path:string,method='GET',body?:unknown):Promise<T>{
  const config=loadCloudflareConfig();
  if(!config.url||!config.token)throw new Error('다시 로그인해 주세요.');
  const response=await fetch(`${config.url.replace(/\/+$/,'')}${path}`,{
    method,
    headers:{Authorization:`Bearer ${config.token}`,'Content-Type':'application/json'},
    ...(body===undefined?{}:{body:JSON.stringify(body)}),
  });
  const value=await response.json() as T&{error?:string;message?:string};
  if(!response.ok)throw new Error(value.message||value.error||`요청 실패 (${response.status})`);
  return value;
}
