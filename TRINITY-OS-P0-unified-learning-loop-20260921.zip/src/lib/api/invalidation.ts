import type { QueryClient } from '@tanstack/react-query';
import { queryKeys } from './queryKeys';

export async function invalidateLearningLoop(client:QueryClient,scope:'wrong-answer'|'drill'|'review'|'core-rule'|'archive'){
  const keys=scope==='wrong-answer'?[queryKeys.wrongAnswers,queryKeys.reviewQueue,queryKeys.activeCoreRules,queryKeys.learningIntelligence,queryKeys.archive]
    :scope==='drill'?[queryKeys.drills,queryKeys.reviewQueue,queryKeys.activeCoreRules,queryKeys.learningIntelligence]
    :scope==='review'?[queryKeys.reviewQueue,queryKeys.activeCoreRules,queryKeys.learningIntelligence,queryKeys.todayLearningExecution]
    :scope==='core-rule'?[queryKeys.coreRules,queryKeys.activeCoreRules,queryKeys.learningIntelligence,queryKeys.archive,queryKeys.wrongAnswers]
    :[queryKeys.archive,queryKeys.wrongAnswers,queryKeys.activeCoreRules,queryKeys.learningIntelligence];
  await Promise.all(keys.map(queryKey=>client.invalidateQueries({queryKey})));
}
