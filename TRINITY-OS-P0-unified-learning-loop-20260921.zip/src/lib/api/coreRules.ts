import type { CoreRule,CoreRuleIntelligence } from '../archiveApi';
import { apiRequest } from './client';
export const coreRulesApi={
  list:()=>apiRequest<{rules:CoreRule[]}>('/api/archive/rules'),
  intelligence:(id:string)=>apiRequest<CoreRuleIntelligence>(`/api/core-rules/${encodeURIComponent(id)}/intelligence`),
  active:()=>apiRequest<{rules:CoreRule[]}>('/api/learning-intelligence/active-rules'),
};
