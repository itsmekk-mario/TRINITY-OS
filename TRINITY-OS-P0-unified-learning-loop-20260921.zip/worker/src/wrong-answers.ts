import { ensureLearningGraphReady, recordCoreRuleEvidence, wrongAnswerDto } from './learning-graph.ts';
import { wrongAnswerRetryStatements } from './reviews.ts';

type Env={DB:D1Database};
type User={id:number}|null;
type Tools={json:(v:unknown,s?:number,o?:string)=>Response;boundedJson:<T>(r:Request,n?:number)=>Promise<T>;randomHex:(n?:number)=>string};
type CreateResult={wrongAnswer:ReturnType<typeof wrongAnswerDto>;recovered:boolean};

const clean=(value:unknown,max=5000)=>typeof value==='string'?value.trim().slice(0,max):'';
const subjects=new Set(['국어','수학','영어','탐구','korean','math','english','inquiry']);
const bottlenecks=new Set(['발문·해석','개념 공백','계산 실수','시간 관리','전략·판단','기타']);
const datePattern=/^\d{4}-\d{2}-\d{2}$/;
const safeRequestId=(value:string)=>value.replace(/[^A-Za-z0-9._-]/g,'_').slice(0,100);
const retryJson=(date:string)=>[3,7,14].map(days=>{const value=new Date(`${date}T12:00:00.000Z`);value.setUTCDate(value.getUTCDate()+days);return{id:`${days}d`,label:`${days}일 후 재도전`,dueDate:value.toISOString().slice(0,10)}});

async function owned(db:D1Database,table:string,id:string,userId:number){return Boolean(await db.prepare(`SELECT id FROM ${table} WHERE id=? AND user_id=?`).bind(id,userId).first())}
async function row(db:D1Database,userId:number,id:string){return db.prepare('SELECT * FROM wrong_answers WHERE user_id=? AND id=?').bind(userId,id).first<Record<string,unknown>>()}

async function projectLegacy(db:D1Database,userId:number,dto:ReturnType<typeof wrongAnswerDto>,mode:'upsert'|'delete'){
  const state=await db.prepare('SELECT payload FROM learning_state WHERE user_id=?').bind(userId).first<{payload:string}>();
  if(!state)return;
  let app:Record<string,unknown>;try{app=JSON.parse(state.payload) as Record<string,unknown>}catch{return}
  const current=Array.isArray(app.wrongAnswerDrills)?app.wrongAnswerDrills as Record<string,unknown>[]:[];
  app.wrongAnswerDrills=mode==='delete'?current.filter(item=>item.id!==dto.id):[dto,...current.filter(item=>item.id!==dto.id)];
  await db.prepare('UPDATE learning_state SET payload=? WHERE user_id=?').bind(JSON.stringify(app),userId).run();
}

function validate(body:Record<string,unknown>){
  const date=clean(body.date,20),subject=clean(body.subject,20),source=clean(body.source,240),question=clean(body.question,240),wrongJudgment=clean(body.wrongJudgment),missedCue=clean(body.missedCue),correction=clean(body.correction),transfer=clean(body.transfer),bottleneck=clean(body.bottleneck,120);
  if(!datePattern.test(date)||!subjects.has(subject)||!source||!wrongJudgment||!correction)throw new Error('INVALID_WRONG_ANSWER');
  if(bottleneck&&!bottlenecks.has(bottleneck))throw new Error('INVALID_WRONG_ANSWER');
  return {date,subject,source,question,wrongJudgment,missedCue,correction,transfer,bottleneck:bottleneck||null,scoreId:clean(body.scoreId,100)||null,capabilityGoalId:clean(body.capabilityGoalId,100)||null,archiveEntryId:clean(body.archiveEntryId,100)||null};
}

export async function createWrongAnswer(db:D1Database,userId:number,body:Record<string,unknown>,randomHex:(n?:number)=>string):Promise<CreateResult>{
  await ensureLearningGraphReady(db,userId);
  const requestId=clean(body.requestId,100),values=validate(body),id=clean(body.id,100)||(requestId?`wa_${safeRequestId(requestId)}`:randomHex(16));
  if(requestId){
    const prior=await db.prepare("SELECT entity_id FROM canonical_mutation_requests WHERE user_id=? AND request_id=? AND entity_type='wrong_answer'").bind(userId,requestId).first<{entity_id:string}>();
    if(prior){const existing=await row(db,userId,prior.entity_id);if(existing)return{wrongAnswer:wrongAnswerDto(existing),recovered:true}}
  }
  if(values.archiveEntryId&&!await owned(db,'archive_entries',values.archiveEntryId,userId))throw new Error('INVALID_ARCHIVE_ENTRY');
  const coreRuleIds=[...new Set((Array.isArray(body.coreRuleIds)?body.coreRuleIds:[body.coreRuleId]).map(value=>clean(value,80)).filter(Boolean))];
  for(const ruleId of coreRuleIds)if(!await owned(db,'core_rules',ruleId,userId))throw new Error('INVALID_CORE_RULE');
  const now=new Date().toISOString(),retries=retryJson(values.date),statements:D1PreparedStatement[]=[
    db.prepare(`INSERT OR IGNORE INTO wrong_answers(user_id,id,date,subject,source,question,wrong_judgment,missed_cue,correction,transfer,bottleneck,status,score_id,capability_goal_id,archive_entry_id,retries_json,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(userId,id,values.date,values.subject,values.source,values.question,values.wrongJudgment,values.missedCue,values.correction,values.transfer,values.bottleneck,'active',values.scoreId,values.capabilityGoalId,values.archiveEntryId,JSON.stringify(retries),now,now),
    ...wrongAnswerRetryStatements(db,userId,id,values.date,now),
  ];
  if(requestId)statements.push(db.prepare("INSERT OR IGNORE INTO canonical_mutation_requests(user_id,request_id,entity_type,entity_id,created_at) VALUES(?,?,'wrong_answer',?,?)").bind(userId,requestId,id,now));
  if(values.archiveEntryId){
    statements.push(
      db.prepare('UPDATE wrong_answers SET archive_entry_id=NULL WHERE user_id=? AND archive_entry_id=? AND id<>?').bind(userId,values.archiveEntryId,id),
      db.prepare('INSERT INTO archive_wrong_answer_links(archive_entry_id,user_id,wrong_answer_id,created_at) VALUES(?,?,?,?) ON CONFLICT(archive_entry_id) DO UPDATE SET wrong_answer_id=excluded.wrong_answer_id,created_at=excluded.created_at WHERE archive_wrong_answer_links.user_id=excluded.user_id').bind(values.archiveEntryId,userId,id,now),
    );
  }
  for(const ruleId of coreRuleIds){
    statements.push(
      db.prepare("INSERT INTO core_rule_wrong_answer_links(user_id,core_rule_id,wrong_answer_id,relation_type,created_at) VALUES(?,?,?,'failed',?) ON CONFLICT(core_rule_id,wrong_answer_id) DO UPDATE SET relation_type='failed'").bind(userId,ruleId,id,now),
      db.prepare("INSERT INTO core_rule_evidence(id,user_id,core_rule_id,source_type,source_id,relation_type,occurred_at,created_at) VALUES(lower(hex(randomblob(16))),?,?, 'wrong_answer',?,'failed',?,?) ON CONFLICT(user_id,core_rule_id,source_type,source_id,relation_type) DO UPDATE SET occurred_at=excluded.occurred_at").bind(userId,ruleId,id,now,now),
    );
  }
  await db.batch(statements);
  const saved=await row(db,userId,id);if(!saved)throw new Error('CREATE_FAILED');
  const dto={...wrongAnswerDto(saved),retries};await projectLegacy(db,userId,dto,'upsert');
  return {wrongAnswer:dto,recovered:false};
}

export async function wrongAnswers(request:Request,env:Env,user:User,origin:string,h:Tools):Promise<Response|null>{
  const url=new URL(request.url),path=url.pathname,method=request.method;if(!path.startsWith('/api/wrong-answers'))return null;
  const out=(value:unknown,status=200)=>h.json(value,status,origin);if(!user)return out({error:'Unauthorized'},401);
  try{
    await ensureLearningGraphReady(env.DB,user.id);
    if(path==='/api/wrong-answers'&&method==='GET'){
      const conditions=['user_id=?'],bind:unknown[]=[user.id];
      for(const [key,column,max] of [['subject','subject',20],['bottleneck','bottleneck',120]] as const){const value=clean(url.searchParams.get(key),max);if(value){conditions.push(`${column}=?`);bind.push(value)}}
      const from=clean(url.searchParams.get('dateFrom'),20),to=clean(url.searchParams.get('dateTo'),20);if(from){conditions.push('date>=?');bind.push(from)}if(to){conditions.push('date<=?');bind.push(to)}
      const raw=Number(url.searchParams.get('limit')||100),limit=Math.max(1,Math.min(200,Number.isFinite(raw)?Math.floor(raw):100));
      const cursor=clean(url.searchParams.get('cursor'),220);if(cursor){try{const [date,id]=JSON.parse(atob(cursor)) as [string,string];conditions.push('(date<? OR (date=? AND id<?))');bind.push(date,date,id)}catch{return out({error:'Invalid cursor'},400)}}
      const result=await env.DB.prepare(`SELECT * FROM wrong_answers WHERE ${conditions.join(' AND ')} ORDER BY date DESC,id DESC LIMIT ?`).bind(...bind,limit+1).all<Record<string,unknown>>();
      const hasMore=result.results.length>limit,rows=result.results.slice(0,limit),last=rows.at(-1);return out({items:rows.map(wrongAnswerDto),nextCursor:hasMore&&last?btoa(JSON.stringify([last.date,last.id])):null,hasMore});
    }
    if(path==='/api/wrong-answers'&&method==='POST'){
      const result=await createWrongAnswer(env.DB,user.id,await h.boundedJson<Record<string,unknown>>(request),h.randomHex);return out(result,result.recovered?200:201);
    }
    const match=path.match(/^\/api\/wrong-answers\/([^/]+)$/);if(!match)return out({error:'Not found'},404);
    const id=decodeURIComponent(match[1]),existing=await row(env.DB,user.id,id);if(!existing)return out({error:'Not found'},404);
    if(method==='GET')return out({wrongAnswer:wrongAnswerDto(existing)});
    if(method==='PATCH'){
      const patch=await h.boundedJson<Record<string,unknown>>(request),merged={...wrongAnswerDto(existing),...patch,id},values=validate(merged),now=new Date().toISOString();
      if(values.archiveEntryId&&!await owned(env.DB,'archive_entries',values.archiveEntryId,user.id))return out({error:'Archive Entry를 찾을 수 없습니다.'},404);
      const statements:D1PreparedStatement[]=[
        env.DB.prepare(`UPDATE wrong_answers SET date=?,subject=?,source=?,question=?,wrong_judgment=?,missed_cue=?,correction=?,transfer=?,bottleneck=?,score_id=?,capability_goal_id=?,archive_entry_id=?,updated_at=? WHERE user_id=? AND id=?`)
          .bind(values.date,values.subject,values.source,values.question,values.wrongJudgment,values.missedCue,values.correction,values.transfer,values.bottleneck,values.scoreId,values.capabilityGoalId,values.archiveEntryId,now,user.id,id),
        env.DB.prepare('DELETE FROM archive_wrong_answer_links WHERE user_id=? AND wrong_answer_id=?').bind(user.id,id),
      ];
      if(values.archiveEntryId)statements.push(
        env.DB.prepare('UPDATE wrong_answers SET archive_entry_id=NULL WHERE user_id=? AND archive_entry_id=? AND id<>?').bind(user.id,values.archiveEntryId,id),
        env.DB.prepare('INSERT INTO archive_wrong_answer_links(archive_entry_id,user_id,wrong_answer_id,created_at) VALUES(?,?,?,?) ON CONFLICT(archive_entry_id) DO UPDATE SET wrong_answer_id=excluded.wrong_answer_id,created_at=excluded.created_at WHERE archive_wrong_answer_links.user_id=excluded.user_id').bind(values.archiveEntryId,user.id,id,now),
      );
      await env.DB.batch(statements);
      const saved=await row(env.DB,user.id,id);const dto=wrongAnswerDto(saved!);await projectLegacy(env.DB,user.id,dto,'upsert');return out({wrongAnswer:dto});
    }
    if(method==='DELETE'){
      const dto=wrongAnswerDto(existing);await env.DB.batch([
        env.DB.prepare("DELETE FROM core_rule_evidence WHERE user_id=? AND source_type IN ('wrong_answer','review') AND (source_id=? OR source_id IN(SELECT id FROM learning_reviews WHERE user_id=? AND target_type='wrong_answer' AND target_id=?))").bind(user.id,id,user.id,id),
        env.DB.prepare("DELETE FROM learning_reviews WHERE user_id=? AND target_type='wrong_answer' AND target_id=?").bind(user.id,id),
        env.DB.prepare('DELETE FROM core_rule_wrong_answer_links WHERE user_id=? AND wrong_answer_id=?').bind(user.id,id),
        env.DB.prepare('DELETE FROM archive_wrong_answer_links WHERE user_id=? AND wrong_answer_id=?').bind(user.id,id),
        env.DB.prepare('DELETE FROM wrong_answers WHERE user_id=? AND id=?').bind(user.id,id),
      ]);await projectLegacy(env.DB,user.id,dto,'delete');return out({ok:true});
    }
    return out({error:'Method not allowed'},405);
  }catch(cause){const code=cause instanceof Error?cause.message:'UNKNOWN';if(code.startsWith('INVALID_'))return out({error:'Wrong Answer 입력값 또는 연결 대상을 확인해 주세요.',code},400);throw cause}
}
