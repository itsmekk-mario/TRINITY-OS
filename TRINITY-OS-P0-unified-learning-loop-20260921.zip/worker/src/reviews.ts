export type ReviewTargetType='wrong_answer'|'core_rule'|'drill'|'learning_item';
export type ReviewResult='pending'|'success'|'fail';

const datePattern=/^\d{4}-\d{2}-\d{2}$/;

export function studyDaySchedule(date:string,days:number){
  if(!datePattern.test(date))throw new Error('INVALID_STUDY_DATE');
  const value=new Date(`${date}T12:00:00.000Z`);
  value.setUTCDate(value.getUTCDate()+days);
  // 06:00 Asia/Seoul is 21:00 UTC on the previous civil day.
  const due=value.toISOString().slice(0,10);
  const start=new Date(`${due}T00:00:00.000Z`);
  start.setUTCDate(start.getUTCDate()-1);
  return `${start.toISOString().slice(0,10)}T21:00:00.000Z`;
}

export function wrongAnswerRetryStatements(db:D1Database,userId:number,wrongAnswerId:string,date:string,now:string){
  return [3,7,14].map(days=>db.prepare(`INSERT OR IGNORE INTO learning_reviews(
    id,user_id,target_type,target_id,review_type,scheduled_at,reviewed_at,result,notes,created_at,updated_at
  ) VALUES(?,?, 'wrong_answer',?,?,?,NULL,'pending','',?,?)`).bind(
    `${wrongAnswerId}:retry_${days}d`,userId,wrongAnswerId,`retry_${days}d`,studyDaySchedule(date,days),now,now
  ));
}

export const learningReviewDto=(row:Record<string,unknown>)=>({
  id:String(row.id),targetType:String(row.target_type) as ReviewTargetType,targetId:String(row.target_id),
  reviewType:String(row.review_type??'manual'),scheduledAt:row.scheduled_at??null,reviewedAt:row.reviewed_at??null,
  result:String(row.result??'pending') as ReviewResult,notes:String(row.notes??''),
  createdAt:String(row.created_at??''),updatedAt:String(row.updated_at??''),
});

export async function backfillUnifiedReviews(db:D1Database,userId:number){
  const now=new Date().toISOString();
  await db.prepare(`INSERT OR IGNORE INTO learning_reviews(
    id,user_id,target_type,target_id,review_type,scheduled_at,reviewed_at,result,notes,created_at,updated_at
  ) SELECT 'archive_history_'||id,user_id,'learning_item',archive_entry_id,'archive_review',reviewed_at,reviewed_at,
    CASE WHEN success=1 THEN 'success' ELSE 'fail' END,'archive review history backfill',created_at,reviewed_at
    FROM archive_reviews WHERE user_id=?`).bind(userId).run();
  await db.prepare(`INSERT OR IGNORE INTO learning_reviews(
    id,user_id,target_type,target_id,review_type,scheduled_at,reviewed_at,result,notes,created_at,updated_at
  ) SELECT 'archive_pending_'||id,user_id,'learning_item',archive_entry_id,'archive_review',next_due_at,NULL,
    'pending','archive review schedule backfill',created_at,? FROM archive_reviews WHERE user_id=? AND next_due_at IS NOT NULL`)
    .bind(now,userId).run();
}
