-- 0021_canonical_learning_loop.sql
-- Additive P0 migration: canonical Wrong Answer / Drill / Review ownership.

CREATE TABLE IF NOT EXISTS canonical_mutation_requests (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  request_id TEXT NOT NULL,
  entity_type TEXT NOT NULL CHECK(entity_type IN ('wrong_answer','drill')),
  entity_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(user_id,request_id)
);

CREATE INDEX IF NOT EXISTS canonical_mutation_entity
  ON canonical_mutation_requests(user_id,entity_type,entity_id);
CREATE INDEX IF NOT EXISTS wrong_answers_user_bottleneck_date
  ON wrong_answers(user_id,bottleneck,date DESC,id DESC);
CREATE INDEX IF NOT EXISTS learning_drills_user_done_date
  ON learning_drills(user_id,done,date DESC,id DESC);
CREATE INDEX IF NOT EXISTS learning_reviews_queue_cover
  ON learning_reviews(user_id,result,scheduled_at,target_type,target_id);

DELETE FROM learning_reviews
WHERE result='pending' AND id NOT IN (
  SELECT MIN(id) FROM learning_reviews
  WHERE result='pending'
  GROUP BY user_id,target_type,target_id,review_type,scheduled_at
);

CREATE UNIQUE INDEX IF NOT EXISTS learning_reviews_unique_pending_schedule
  ON learning_reviews(user_id,target_type,target_id,review_type,scheduled_at)
  WHERE result='pending';

-- Preserve legacy retry JSON as canonical pending reviews. The unique index makes
-- the backfill safe when deployment or local migration is retried.
INSERT OR IGNORE INTO learning_reviews(
  id,user_id,target_type,target_id,review_type,scheduled_at,reviewed_at,result,notes,created_at,updated_at
)
SELECT lower(hex(randomblob(16))),w.user_id,'wrong_answer',w.id,
  'retry_'||json_extract(j.value,'$.id'),
  json_extract(j.value,'$.dueDate')||'T21:00:00.000Z',NULL,'pending','legacy retry backfill',w.created_at,w.updated_at
FROM wrong_answers w,json_each(w.retries_json) j
WHERE json_extract(j.value,'$.dueDate') IS NOT NULL
  AND COALESCE(json_extract(j.value,'$.completedDate'),'')='';

INSERT OR IGNORE INTO learning_reviews(
  id,user_id,target_type,target_id,review_type,scheduled_at,reviewed_at,result,notes,created_at,updated_at
)
SELECT 'archive_history_'||r.id,r.user_id,'learning_item',r.archive_entry_id,'archive_review',
  r.reviewed_at,r.reviewed_at,CASE WHEN r.success=1 THEN 'success' ELSE 'fail' END,
  'archive review history backfill',r.created_at,r.reviewed_at
FROM archive_reviews r;

INSERT OR IGNORE INTO learning_reviews(
  id,user_id,target_type,target_id,review_type,scheduled_at,reviewed_at,result,notes,created_at,updated_at
)
SELECT 'archive_pending_'||r.id,r.user_id,'learning_item',r.archive_entry_id,'archive_review',
  r.next_due_at,NULL,'pending','archive review schedule backfill',r.created_at,r.reviewed_at
FROM archive_reviews r WHERE r.next_due_at IS NOT NULL;

CREATE TRIGGER IF NOT EXISTS wrong_answers_learning_graph_cleanup
AFTER DELETE ON wrong_answers BEGIN
  DELETE FROM learning_reviews WHERE user_id=OLD.user_id AND target_type='wrong_answer' AND target_id=OLD.id;
  DELETE FROM core_rule_evidence WHERE user_id=OLD.user_id AND source_type='wrong_answer' AND source_id=OLD.id;
  DELETE FROM canonical_mutation_requests WHERE user_id=OLD.user_id AND entity_type='wrong_answer' AND entity_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS learning_drills_learning_graph_cleanup
AFTER DELETE ON learning_drills BEGIN
  DELETE FROM learning_reviews WHERE user_id=OLD.user_id AND target_type='drill' AND target_id=OLD.id;
  DELETE FROM core_rule_evidence WHERE user_id=OLD.user_id AND source_type='drill' AND source_id=OLD.id;
  DELETE FROM canonical_mutation_requests WHERE user_id=OLD.user_id AND entity_type='drill' AND entity_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS core_rules_learning_graph_cleanup
AFTER DELETE ON core_rules BEGIN
  DELETE FROM learning_reviews WHERE user_id=OLD.user_id AND target_type='core_rule' AND target_id=OLD.id;
  DELETE FROM core_rule_evidence WHERE user_id=OLD.user_id AND core_rule_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS archive_entries_learning_graph_cleanup
AFTER DELETE ON archive_entries BEGIN
  DELETE FROM learning_reviews WHERE user_id=OLD.user_id AND target_type='learning_item' AND target_id=OLD.id;
  DELETE FROM core_rule_evidence WHERE user_id=OLD.user_id AND source_type='archive' AND source_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS learning_reviews_evidence_cleanup
AFTER DELETE ON learning_reviews BEGIN
  DELETE FROM core_rule_evidence WHERE user_id=OLD.user_id AND source_type='review' AND source_id=OLD.id;
END;
