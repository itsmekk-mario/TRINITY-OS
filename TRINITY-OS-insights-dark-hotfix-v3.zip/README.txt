TRINITY OS — Insights Dark Mode Hotfix v3

수정 범위:
- Insights > Performance 화면 색상만 수정
- 오늘의 측정 기록 글자 대비
- 과목 비율 범례/도넛 글자 대비
- 오늘의 시작·종료 카드 글자 대비
- 달력 heatmap 글자/배경 대비
- 하단 주간/시간대/Capability/Mock Performance 대비
- 레이아웃, padding, 크기, display, overflow는 변경하지 않음
- Service Worker 캐시 키를 v3로 갱신하여 이전 CSS 캐시 제거

실행:
python3 apply-insights-dark-fix.py
npm run build
