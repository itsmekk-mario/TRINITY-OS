#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, subprocess, re, shutil, sys, json

def run(cmd, cwd, check=True):
    print("+", " ".join(cmd))
    return subprocess.run(cmd, cwd=cwd, text=True, check=check)

def text(cmd, cwd):
    return subprocess.check_output(cmd, cwd=cwd, text=True).strip()

def replace_once(content, old, new, label):
    count=content.count(old)
    if count!=1:
        raise RuntimeError(f"{label}: expected one anchor, found {count}")
    return content.replace(old,new,1)

def patch_file(path:Path, fn):
    old=path.read_text(encoding="utf-8")
    new=fn(old)
    if new==old:
        print(f"unchanged {path}")
        return
    path.write_text(new,encoding="utf-8")
    print(f"patched {path}")

def patch_security(c):
    return replace_once(c,"export const MAX_SYNC_BODY = 5 * 1024 * 1024;","export const MAX_SYNC_BODY = 20 * 1024 * 1024;","MAX_SYNC_BODY")

def patch_index(c):
    if "syncLearningProjection" not in c:
        c=c.replace("import { learningIntelligence } from './learning-intelligence.ts';",
                    "import { learningIntelligence } from './learning-intelligence.ts';\nimport { syncLearningProjection } from './learning-graph.ts';")
    anchor="await env.DB.prepare('INSERT INTO learning_state(user_id,payload,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at').bind(user.id, JSON.stringify(body.data), now).run();"
    replacement=anchor+"\n  await syncLearningProjection(env.DB,user.id,body.data,now);"
    if replacement not in c:
        c=replace_once(c,anchor,replacement,"sync projection hook")
    return c

def patch_archive(c):
    if not c.startswith("import "):
        c="import { MAX_SYNC_BODY } from './security.ts';\nimport { drillExists, ensureLearningGraphReady, recordCoreRuleEvidence, rebuildLegacyEvidence, wrongAnswerExists } from './learning-graph.ts';\n"+c
    elif "ensureLearningGraphReady" not in c:
        c="import { MAX_SYNC_BODY } from './security.ts';\nimport { drillExists, ensureLearningGraphReady, recordCoreRuleEvidence, rebuildLegacyEvidence, wrongAnswerExists } from './learning-graph.ts';\n"+c

    c=replace_once(c,
      "function arrayOf(value:unknown,max:number){if(!Array.isArray(value)||value.length>max)throw new Error('INVALID_BACKUP');return value as Record<string,unknown>[]}",
      """function arrayOf(value:unknown,max:number){if(!Array.isArray(value)||value.length>max)throw new Error('INVALID_BACKUP');return value as Record<string,unknown>[]}
async function batchInChunks(db:D1Database,statements:D1PreparedStatement[],size=100){for(let i=0;i<statements.length;i+=size)await db.batch(statements.slice(i,i+size))}
type ArchiveCursor={studiedAt:string;updatedAt:string;id:string};
const encodeCursor=(cursor:ArchiveCursor)=>btoa(JSON.stringify(cursor)).replace(/\\+/g,'-').replace(/\\//g,'_').replace(/=+$/,'');
const decodeCursor=(value:string|null):ArchiveCursor|undefined=>{if(!value)return undefined;try{const normalized=value.replace(/-/g,'+').replace(/_/g,'/').padEnd(Math.ceil(value.length/4)*4,'=');const parsed=JSON.parse(atob(normalized)) as ArchiveCursor;if(!parsed||typeof parsed.studiedAt!=='string'||typeof parsed.updatedAt!=='string'||typeof parsed.id!=='string'||parsed.id.length>100)throw new Error();return parsed}catch{throw new Error('INVALID_CURSOR')}};""",
      "archive helpers")

    old="const entries=arrayOf(source.entries,300),annotations=arrayOf(source.annotations,2000),rules=arrayOf(source.coreRules,500),links=arrayOf(source.ruleLinks,2000),reviews=arrayOf(source.reviews,3000),wrongLinks=arrayOf(source.wrongAnswerLinks,300),wrongRuleLinks=source.coreRuleWrongAnswerLinks===undefined?[]:arrayOf(source.coreRuleWrongAnswerLinks,5000),drillLinks=source.coreRuleDrillLinks===undefined?[]:arrayOf(source.coreRuleDrillLinks,2000),learningReviews=source.learningReviews===undefined?[]:arrayOf(source.learningReviews,5000);"
    new="const entries=arrayOf(source.entries,10000),annotations=arrayOf(source.annotations,50000),rules=arrayOf(source.coreRules,2000),links=arrayOf(source.ruleLinks,50000),reviews=arrayOf(source.reviews,50000),wrongLinks=arrayOf(source.wrongAnswerLinks,20000),wrongRuleLinks=source.coreRuleWrongAnswerLinks===undefined?[]:arrayOf(source.coreRuleWrongAnswerLinks,50000),drillLinks=source.coreRuleDrillLinks===undefined?[]:arrayOf(source.coreRuleDrillLinks,50000),learningReviews=source.learningReviews===undefined?[]:arrayOf(source.learningReviews,100000);"
    c=replace_once(c,old,new,"backup limits")

    # Replace all large in-memory D1 batch submissions with bounded chunks.
    c=re.sub(r"if\((\w+Statements)\.length\)await db\.batch\(\1\);",r"await batchInChunks(db,\1);",c)

    old_re=r" const state=await db\.prepare\('SELECT payload FROM learning_state WHERE user_id=\?'\).*?validWrong=new Set\(\(Array\.isArray\(app\.wrongAnswerDrills\)\?app\.wrongAnswerDrills:\[\]\).*?filter\(v=>typeof v==='string'\)\);"
    new_re=""" await ensureLearningGraphReady(db,userId);
 const validWrongRows=await db.prepare('SELECT id FROM wrong_answers WHERE user_id=?').bind(userId).all<{id:string}>(),validWrong=new Set(validWrongRows.results.map(v=>v.id));"""
    c,n=re.subn(old_re,new_re,c,flags=re.S)
    if n!=1: raise RuntimeError(f"validWrong projection anchor found {n}")

    old_drill=r" const validDrills=new Set\(\(Array\.isArray\(app\.dailyDrills\)\?app\.dailyDrills:\[\]\).*?filter\(v=>typeof v==='string'\)\),drillStatements:D1PreparedStatement\[\]=\[\];"
    new_drill=""" const validDrillRows=await db.prepare('SELECT id FROM learning_drills WHERE user_id=?').bind(userId).all<{id:string}>(),validDrills=new Set(validDrillRows.results.map(v=>v.id)),drillStatements:D1PreparedStatement[]=[];"""
    c,n=re.subn(old_drill,new_drill,c,flags=re.S)
    if n!=1: raise RuntimeError(f"validDrills projection anchor found {n}")

    # Rebuild derived evidence after Backup import.
    anchor="if(intervals.length)await db.batch([db.prepare('INSERT INTO archive_review_settings(user_id,intervals_json,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET intervals_json=excluded.intervals_json,updated_at=excluded.updated_at').bind(userId,JSON.stringify(intervals),now)]);"
    if "await rebuildLegacyEvidence(db,userId);" not in c:
        c=replace_once(c,anchor,anchor+"\n await rebuildLegacyEvidence(db,userId);","backup evidence rebuild")

    # Remove runtime DDL/backfill from the Archive route; graph readiness is delegated to the service.
    c,n=re.subn(r"async function ensureIntelligence\(db:D1Database,userId:number\)\{.*?\n\}", "async function ensureIntelligence(db:D1Database,userId:number){await ensureLearningGraphReady(db,userId)}", c, flags=re.S)
    if n!=1: raise RuntimeError(f"ensureIntelligence replacement found {n}")

    # Cursor page bundle with Map grouping (no O(n^2) repeated filter).
    bundle=r"""async function bundle(db:D1Database,userId:number,where:string,bind:unknown[],options:{limit?:number;cursor?:ArchiveCursor}={}){
 const limit=Math.max(1,Math.min(200,Math.floor(options.limit??100))),cursor=options.cursor,clauses=[where],cursorBind:unknown[]=[];
 if(cursor){clauses.push("AND (e.studied_at<? OR (e.studied_at=? AND (e.updated_at<? OR (e.updated_at=? AND e.id<?))))");cursorBind.push(cursor.studiedAt,cursor.studiedAt,cursor.updatedAt,cursor.updatedAt,cursor.id)}
 const result=await db.prepare(`SELECT e.*,w.wrong_answer_id FROM archive_entries e LEFT JOIN archive_wrong_answer_links w ON w.archive_entry_id=e.id WHERE e.user_id=? ${clauses.join(' ')} ORDER BY e.studied_at DESC,e.updated_at DESC,e.id DESC LIMIT ?`).bind(userId,...bind,...cursorBind,limit+1).all<Record<string,unknown>>();
 const hasMore=result.results.length>limit,rows=result.results.slice(0,limit),ids=rows.map(r=>String(r.id));
 if(!ids.length)return {entries:[],nextCursor:null,hasMore:false};
 const marks=ids.map(()=>'?').join(',');
 const [annotations,rules]=await Promise.all([
  db.prepare(`SELECT * FROM archive_annotations WHERE archive_entry_id IN (${marks}) ORDER BY sort_order,id`).bind(...ids).all<Record<string,unknown>>(),
  db.prepare(`SELECT l.archive_entry_id,l.relation_type,r.* FROM archive_entry_core_rules l JOIN core_rules r ON r.id=l.core_rule_id WHERE l.archive_entry_id IN (${marks}) AND r.user_id=? ORDER BY r.title`).bind(...ids,userId).all<Record<string,unknown>>()
 ]);
 const annotationsByEntry=new Map<string,Record<string,unknown>[]>(),rulesByEntry=new Map<string,Record<string,unknown>[]>();
 for(const item of annotations.results){const key=String(item.archive_entry_id),group=annotationsByEntry.get(key)||[];group.push(item);annotationsByEntry.set(key,group)}
 for(const item of rules.results){const key=String(item.archive_entry_id),group=rulesByEntry.get(key)||[];group.push(item);rulesByEntry.set(key,group)}
 const entries=rows.map(row=>{const key=String(row.id);return {...entryOut(row),annotations:(annotationsByEntry.get(key)||[]).map(annotationOut),coreRules:(rulesByEntry.get(key)||[]).map(ruleOut)}});
 const last=rows.at(-1),nextCursor=hasMore&&last?encodeCursor({studiedAt:String(last.studied_at),updatedAt:String(last.updated_at),id:String(last.id)}):null;
 return {entries,nextCursor,hasMore};
}"""
    c,n=re.subn(r"async function bundle\(db:D1Database,userId:number,where:string,bind:unknown\[\]\)\{.*?\n\}",bundle,c,flags=re.S)
    if n!=1: raise RuntimeError(f"bundle replacement found {n}")

    c=c.replace("await h.boundedJson<unknown>(request,5*1024*1024)","await h.boundedJson<unknown>(request,MAX_SYNC_BODY)")

    old_get="if(q){clauses.push(\"(e.title LIKE ? OR e.memo LIKE ? OR e.exam_name LIKE ? OR e.source_name LIKE ? OR EXISTS(SELECT 1 FROM archive_annotations a WHERE a.archive_entry_id=e.id AND a.text LIKE ?))\");for(let i=0;i<5;i++)bind.push(`%${q.slice(0,100)}%`)}return out(await bundle(env.DB,user.id,clauses.length?'AND '+clauses.join(' AND '):'',bind));"
    new_get="if(q){clauses.push(\"(e.title LIKE ? OR e.memo LIKE ? OR e.exam_name LIKE ? OR e.source_name LIKE ? OR EXISTS(SELECT 1 FROM archive_annotations a WHERE a.archive_entry_id=e.id AND a.text LIKE ?))\");for(let i=0;i<5;i++)bind.push(`%${q.slice(0,100)}%`)}const rawLimit=Number(url.searchParams.get('limit')||100),limit=Math.max(1,Math.min(200,Number.isFinite(rawLimit)?Math.floor(rawLimit):100)),cursor=decodeCursor(url.searchParams.get('cursor'));return out(await bundle(env.DB,user.id,clauses.length?'AND '+clauses.join(' AND '):'',bind,{limit,cursor}));"
    c=replace_once(c,old_get,new_get,"archive pagination route")

    # Review endpoint also accepts cursor pagination.
    old_review='const data=await bundle(env.DB,user.id,"AND (e.review_enabled=1 OR EXISTS(SELECT 1 FROM archive_entry_core_rules l WHERE l.archive_entry_id=e.id))",[]);'
    new_review='const rawLimit=Number(url.searchParams.get("limit")||100),limit=Math.max(1,Math.min(200,Number.isFinite(rawLimit)?Math.floor(rawLimit):100)),cursor=decodeCursor(url.searchParams.get("cursor"));const data=await bundle(env.DB,user.id,"AND (e.review_enabled=1 OR EXISTS(SELECT 1 FROM archive_entry_core_rules l WHERE l.archive_entry_id=e.id))",[],{limit,cursor});'
    c=replace_once(c,old_review,new_review,"review pagination")

    # Archive delete cleans generic evidence.
    old_del="if(method==='DELETE'){await env.DB.prepare('DELETE FROM archive_entries WHERE id=? AND user_id=?').bind(id,user.id).run();return out({ok:true})}"
    new_del="if(method==='DELETE'){await env.DB.batch([env.DB.prepare(\"DELETE FROM core_rule_evidence WHERE user_id=? AND source_type='archive' AND source_id=?\").bind(user.id,id),env.DB.prepare('DELETE FROM archive_entries WHERE id=? AND user_id=?').bind(id,user.id)]);return out({ok:true})}"
    c=replace_once(c,old_del,new_del,"archive delete evidence")

    # Archive -> Core Rule evidence.
    old_link="await env.DB.prepare('INSERT INTO archive_entry_core_rules(archive_entry_id,core_rule_id,created_at,relation_type) VALUES(?,?,?,?) ON CONFLICT(archive_entry_id,core_rule_id) DO UPDATE SET relation_type=excluded.relation_type').bind(entryId,ruleId,now,relation).run();"
    new_link=old_link+"await recordCoreRuleEvidence(env.DB,user.id,ruleId,'archive',entryId,relation as any,now);"
    c=replace_once(c,old_link,new_link,"archive evidence")

    # Wrong Answer link ownership + evidence promotion.
    old_wrong="if(path==='/api/archive/wrong-answer-links'&&method==='POST'){const b=await h.boundedJson<Record<string,unknown>>(request),entryId=clean(b.archiveEntryId,80),wrong=clean(b.wrongAnswerId,100);if(!wrong||!await owner(env.DB,entryId,user.id))return out({error:'Not found'},404);const now=new Date().toISOString();"
    new_wrong="if(path==='/api/archive/wrong-answer-links'&&method==='POST'){const b=await h.boundedJson<Record<string,unknown>>(request),entryId=clean(b.archiveEntryId,80),wrong=clean(b.wrongAnswerId,100);if(!wrong||!await owner(env.DB,entryId,user.id)||!await wrongAnswerExists(env.DB,user.id,wrong))return out({error:'Not found',code:'NOT_FOUND',message:'연결 대상을 찾을 수 없습니다.'},404);const now=new Date().toISOString();"
    c=replace_once(c,old_wrong,new_wrong,"wrong answer ownership")

    promote="await env.DB.prepare(\"INSERT INTO core_rule_wrong_answer_links(user_id,core_rule_id,wrong_answer_id,relation_type,created_at) SELECT ?,l.core_rule_id,?,COALESCE(l.relation_type,'failed'),? FROM archive_entry_core_rules l JOIN core_rules r ON r.id=l.core_rule_id WHERE l.archive_entry_id=? AND r.user_id=? ON CONFLICT(core_rule_id,wrong_answer_id) DO UPDATE SET relation_type=excluded.relation_type\").bind(user.id,wrong,now,entryId,user.id).run();"
    if promote in c:
        c=c.replace(promote,promote+"const linkedRules=await env.DB.prepare('SELECT core_rule_id,COALESCE(relation_type,\\'failed\\') relation_type FROM archive_entry_core_rules WHERE archive_entry_id=?').bind(entryId).all<{core_rule_id:string;relation_type:string}>();for(const linked of linkedRules.results)await recordCoreRuleEvidence(env.DB,user.id,linked.core_rule_id,'wrong_answer',wrong,linked.relation_type as any,now);",1)

    # Cursor error response.
    c=c.replace("if(cause instanceof Error&&cause.message==='INVALID_BACKUP')return out({error:'Invalid Learning Archive backup'},400);throw cause",
                "if(cause instanceof Error&&cause.message==='INVALID_BACKUP')return out({error:'Invalid Learning Archive backup',code:'INVALID_BACKUP',message:'Learning Archive backup 형식이 올바르지 않습니다.'},400);if(cause instanceof Error&&cause.message==='INVALID_CURSOR')return out({error:'Invalid cursor',code:'INVALID_CURSOR',message:'Archive cursor가 올바르지 않습니다.'},400);throw cause")
    return c

def patch_archive_api(c):
    if "export type ArchivePage" not in c:
        c=c.replace("export type LearningReview=", "export type ArchivePage={entries:ArchiveEntry[];nextCursor:string|null;hasMore:boolean};\nexport type LearningReview=")
        c += """
export async function archiveAllEntries(path='/api/archive/entries',params=new URLSearchParams()):Promise<ArchiveEntry[]>{
 const all:ArchiveEntry[]=[];let cursor:string|undefined;
 for(let page=0;page<100;page++){
  const query=new URLSearchParams(params);query.set('limit','200');if(cursor)query.set('cursor',cursor);
  const response=await archiveApi<ArchivePage>(`${path}?${query.toString()}`);
  all.push(...response.entries);
  if(!response.hasMore||!response.nextCursor)return all;
  cursor=response.nextCursor;
 }
 throw new Error('Archive pagination exceeded the safety limit.');
}
"""
    return c

def patch_learning_archive(c):
    c=c.replace("archiveApi,type ArchiveEntry,type ArchiveSubject,type CoreRule,type MasteryStatus,type RuleRelation",
                "archiveAllEntries,archiveApi,type ArchiveEntry,type ArchiveSubject,type CoreRule,type MasteryStatus,type RuleRelation")
    old="const [a,r,reviewData]=await Promise.all([archiveApi<{entries:ArchiveEntry[]}>(`/api/archive/entries?${params}`),archiveApi<{rules:CoreRule[]}>('/api/archive/rules'),archiveApi<{entries:ArchiveEntry[]}>('/api/archive/review')]);const reviews=new Map(reviewData.entries.map(entry=>[entry.id,entry]));const merged=a.entries.map(entry=>({...entry,...(reviews.get(entry.id)||{})}));"
    new="const [archiveEntries,r,reviewEntries]=await Promise.all([archiveAllEntries('/api/archive/entries',params),archiveApi<{rules:CoreRule[]}>('/api/archive/rules'),archiveAllEntries('/api/archive/review')]);const reviews=new Map(reviewEntries.map(entry=>[entry.id,entry]));const merged=archiveEntries.map(entry=>({...entry,...(reviews.get(entry.id)||{})}));"
    return replace_once(c,old,new,"LearningArchive paginated loading")

def patch_schema(c, support_schema, schema_tail):
    if "CREATE TABLE IF NOT EXISTS support_accounts" not in c:
        anchor="CREATE TABLE IF NOT EXISTS arena_profiles ("
        c=replace_once(c,anchor,support_schema+"\n"+anchor,"support schema")
    marker="CREATE TABLE IF NOT EXISTS core_rule_drill_links ("
    idx=c.find(marker)
    if idx<0: raise RuntimeError("schema learning-intelligence tail not found")
    return c[:idx]+schema_tail+"\n"

def patch_tests(c):
    c=c.replace("for(const name of ['0001_support_portal.sql','0002_feedback_collaboration.sql','0003_feedback_context.sql','0008_security_hardening.sql','0009_arena_14_day_seasons.sql','0011_learning_archive.sql'])",
                "for(const name of ['0001_support_portal.sql','0002_feedback_collaboration.sql','0003_feedback_context.sql','0008_security_hardening.sql','0009_arena_14_day_seasons.sql','0011_learning_archive.sql','0012_learning_intelligence_arena_v2.sql','0014_learning_graph_scale.sql'])")
    c=c.replace("String(5*1024*1024+1)","String(20*1024*1024+1)")
    return c

def patch_deploy(c):
    if "Run tests" in c or "- run: npm test" in c:return c
    return replace_once(c,
"""      - run: npm ci
      - run: npm run build
      - uses: actions/configure-pages@v5""",
"""      - run: npm ci
      - name: Run tests
        run: npm test
      - run: npm run build
      - name: Install Worker dependencies
        working-directory: worker
        run: npm ci
      - name: Bundle Worker (dry run)
        working-directory: worker
        run: npx wrangler deploy --dry-run --config wrangler.toml --outdir ../.worker-dist
      - uses: actions/configure-pages@v5""","deploy verification")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",default=".")
    ap.add_argument("--commit",action="store_true")
    ap.add_argument("--push",action="store_true")
    args=ap.parse_args()
    repo=Path(args.repo).resolve()
    payload=Path(__file__).resolve().parent/"payload"
    branch=text(["git","branch","--show-current"],repo)
    if branch!="main":raise SystemExit(f"Expected main branch, got {branch}")
    dirty=text(["git","status","--porcelain"],repo)
    if dirty:raise SystemExit("Working tree is not clean. Commit/stash existing changes first:\n"+dirty)
    print("A. before",json.dumps({"branch":branch,"head":text(["git","rev-parse","HEAD"],repo),"status":"clean"},ensure_ascii=False))
    run(["git","pull","origin","main"],repo)
    print("pulled HEAD",text(["git","rev-parse","HEAD"],repo))

    # New files.
    (repo/"worker/src/learning-graph.ts").write_text((payload/"learning-graph.ts").read_text(encoding="utf-8"),encoding="utf-8")
    (repo/"worker/src/learning-intelligence.ts").write_text((payload/"learning-intelligence.ts").read_text(encoding="utf-8"),encoding="utf-8")
    (repo/"worker/migrations/0014_learning_graph_scale.sql").write_text((payload/"0014_learning_graph_scale.sql").read_text(encoding="utf-8"),encoding="utf-8")
    (repo/"tests/learning-graph-scale.test.mjs").write_text((payload/"learning-graph-scale.test.mjs").read_text(encoding="utf-8"),encoding="utf-8")

    patch_file(repo/"worker/src/security.ts",patch_security)
    patch_file(repo/"worker/src/index.ts",patch_index)
    patch_file(repo/"worker/src/archive.ts",patch_archive)
    patch_file(repo/"src/lib/archiveApi.ts",patch_archive_api)
    patch_file(repo/"src/pages/LearningArchive.tsx",patch_learning_archive)
    patch_file(repo/"worker/schema.sql",lambda c:patch_schema(c,(payload/"support-schema.sql").read_text(encoding="utf-8"),(payload/"schema-learning-graph-tail.sql").read_text(encoding="utf-8")))
    patch_file(repo/"tests/security.test.mjs",patch_tests)
    patch_file(repo/".github/workflows/deploy.yml",patch_deploy)

    # Remove only temporary artifacts created by the previous patch workflow.
    for pattern in ["*.pre-core-wrong.bak"]:
        for path in repo.rglob(pattern):
            path.unlink()
            print("removed temp",path.relative_to(repo))
    temp=repo/"TRINITY-OS-core-rule-wrong-answer-fix-20260918.zip"
    if temp.exists():
        temp.unlink();print("removed temp",temp.name)

    print("\nRunning verification...")
    run(["npm","ci"],repo)
    run(["npm","test"],repo)
    run(["npm","run","build"],repo)
    run(["npm","ci"],repo/"worker")
    run(["npx","wrangler","deploy","--dry-run","--config","wrangler.toml","--outdir","../.worker-dist"],repo/"worker")

    status=text(["git","status","--short"],repo)
    print("\nB. changed files\n"+status)
    if args.commit or args.push:
        run(["git","add",
             "worker/src/learning-graph.ts","worker/src/learning-intelligence.ts","worker/src/archive.ts","worker/src/index.ts","worker/src/security.ts",
             "worker/schema.sql","worker/migrations/0014_learning_graph_scale.sql",
             "src/lib/archiveApi.ts","src/pages/LearningArchive.tsx",
             "tests/security.test.mjs","tests/learning-graph-scale.test.mjs",".github/workflows/deploy.yml"],repo)
        # Include deletions of tracked temp files.
        run(["git","add","-u"],repo)
        run(["git","commit","-m","refactor: scale learning graph backend"],repo)
        print("commit",text(["git","rev-parse","HEAD"],repo))
    if args.push:
        run(["git","push","origin","main"],repo)
        print("pushed main")
    print("\nProduction D1 was NOT modified.")
    print("After reviewing the commit, apply: cd worker && npx wrangler d1 migrations apply trinity-os-db --remote --config wrangler.toml")
    print("Then deploy Worker: npx wrangler deploy --config wrangler.toml")

if __name__=="__main__":
    main()
