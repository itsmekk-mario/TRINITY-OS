
CREATE TABLE IF NOT EXISTS support_accounts (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK(role IN ('tutor','parent')),
  collaboration_role TEXT,
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  password_iterations INTEGER NOT NULL DEFAULT 100000,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS support_sessions (
  token_hash TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES support_accounts(id),
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS support_comments (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES support_accounts(id),
  target TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS support_comments_created ON support_comments(created_at);
CREATE TABLE IF NOT EXISTS support_login_attempts (key TEXT PRIMARY KEY,attempts INTEGER NOT NULL,expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS exam_documents (
  id TEXT PRIMARY KEY,title TEXT NOT NULL,agency TEXT NOT NULL,year INTEGER NOT NULL,
  subject TEXT NOT NULL,object_key TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS student_teacher_assignments (
  id TEXT PRIMARY KEY,student_id TEXT NOT NULL,teacher_id TEXT NOT NULL REFERENCES support_accounts(id),
  role TEXT NOT NULL CHECK(role IN ('subject_teacher','academic_manager')),subject TEXT,
  permissions_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS assignments_teacher ON student_teacher_assignments(teacher_id,role);
CREATE TABLE IF NOT EXISTS teacher_feedback (
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL,
  student_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  teacher_id TEXT NOT NULL REFERENCES support_accounts(id),
  type TEXT NOT NULL CHECK(type IN ('subject','academic_management')),
  subject TEXT,title TEXT,categories_json TEXT NOT NULL DEFAULT '[]',
  status TEXT NOT NULL CHECK(status IN ('needs_improvement','normal','stable')),
  progress TEXT NOT NULL DEFAULT 'active' CHECK(progress IN ('active','achieved','replaced','archived')),
  bottleneck TEXT,observation TEXT,action TEXT,success_criterion TEXT,comment TEXT,
  linked_weekly_goal_id TEXT,linked_daily_drill_id TEXT,acknowledged_at TEXT,
  context_type TEXT NOT NULL DEFAULT 'general',context_target_id TEXT,
  created_at TEXT NOT NULL,updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS feedback_student ON teacher_feedback(student_id,progress,created_at DESC);
CREATE INDEX IF NOT EXISTS feedback_student_user ON teacher_feedback(student_user_id,progress,created_at DESC);
CREATE TABLE IF NOT EXISTS teacher_feedback_audit (
  id TEXT PRIMARY KEY,feedback_id TEXT NOT NULL REFERENCES teacher_feedback(id),editor_id TEXT NOT NULL,
  snapshot_json TEXT NOT NULL,edited_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS student_support_assignments (
  id TEXT PRIMARY KEY,
  student_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  support_account_id TEXT NOT NULL REFERENCES support_accounts(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK(role IN ('subject_teacher','academic_manager','parent','admin')),
  subject TEXT,permissions_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL,
  UNIQUE(student_user_id,support_account_id,role,subject)
);
CREATE INDEX IF NOT EXISTS support_assignments_account ON student_support_assignments(support_account_id,role);
CREATE INDEX IF NOT EXISTS support_assignments_student ON student_support_assignments(student_user_id,role);
