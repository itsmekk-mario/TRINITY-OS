CREATE TABLE IF NOT EXISTS archive_entries (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject TEXT NOT NULL CHECK(subject IN ('korean','math','english')),
  year INTEGER NOT NULL CHECK(year BETWEEN 2000 AND 2100),
  month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),
  institution TEXT NOT NULL CHECK(institution IN ('KICE','education_office','EBS','private','textbook','custom')),
  institution_custom_name TEXT,
  exam_name TEXT NOT NULL DEFAULT '',
  source_name TEXT NOT NULL DEFAULT '',
  question_number TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  subcategory TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL,
  studied_at TEXT NOT NULL,
  mastery_status TEXT NOT NULL CHECK(mastery_status IN ('input','understanding','reproduction','automated')),
  memo TEXT NOT NULL DEFAULT '',
  condition_summary TEXT,
  first_thought TEXT,
  representation TEXT,
  solution_flow TEXT,
  bottleneck TEXT,
  transfer TEXT,
  main_idea TEXT,
  structure_summary TEXT,
  key_expression TEXT,
  review_enabled INTEGER NOT NULL DEFAULT 0 CHECK(review_enabled IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS archive_entries_user_subject ON archive_entries(user_id,subject);
CREATE INDEX IF NOT EXISTS archive_entries_user_year_month ON archive_entries(user_id,year,month);
CREATE INDEX IF NOT EXISTS archive_entries_user_institution ON archive_entries(user_id,institution);
CREATE INDEX IF NOT EXISTS archive_entries_user_category ON archive_entries(user_id,category,subcategory);
CREATE INDEX IF NOT EXISTS archive_entries_user_mastery ON archive_entries(user_id,mastery_status);
CREATE INDEX IF NOT EXISTS archive_entries_cursor ON archive_entries(user_id,studied_at DESC,updated_at DESC,id DESC);
CREATE INDEX IF NOT EXISTS archive_entries_subject_cursor ON archive_entries(user_id,subject,studied_at DESC,updated_at DESC,id DESC);

CREATE TABLE IF NOT EXISTS archive_annotations (
  id TEXT PRIMARY KEY,
  archive_entry_id TEXT NOT NULL REFERENCES archive_entries(id) ON DELETE CASCADE,
  color TEXT NOT NULL,
  type TEXT NOT NULL,
  text TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS archive_annotations_entry_color_order ON archive_annotations(archive_entry_id,color,sort_order);

CREATE TABLE IF NOT EXISTS core_rules (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject TEXT NOT NULL CHECK(subject IN ('korean','math','english')),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  tags_json TEXT NOT NULL DEFAULT '[]',
  mastery_status TEXT NOT NULL CHECK(mastery_status IN ('input','understanding','reproduction','automated')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS core_rules_user_subject_mastery ON core_rules(user_id,subject,mastery_status);

CREATE TABLE IF NOT EXISTS archive_entry_core_rules (
  archive_entry_id TEXT NOT NULL REFERENCES archive_entries(id) ON DELETE CASCADE,
  core_rule_id TEXT NOT NULL REFERENCES core_rules(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  relation_type TEXT NOT NULL DEFAULT 'derived'
    CHECK(relation_type IN ('derived','applied','failed','reinforced')),
  PRIMARY KEY(archive_entry_id,core_rule_id)
);
CREATE INDEX IF NOT EXISTS archive_rule_links_rule ON archive_entry_core_rules(core_rule_id,archive_entry_id);
CREATE INDEX IF NOT EXISTS archive_rule_links_rule_relation ON archive_entry_core_rules(core_rule_id,relation_type,archive_entry_id);

CREATE TABLE IF NOT EXISTS archive_review_settings (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  intervals_json TEXT NOT NULL DEFAULT '[3,7,14,30]',
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS archive_reviews (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  archive_entry_id TEXT NOT NULL REFERENCES archive_entries(id) ON DELETE CASCADE,
  reviewed_at TEXT NOT NULL,
  success INTEGER NOT NULL CHECK(success IN (0,1)),
  core_rule_revealed INTEGER NOT NULL DEFAULT 0,
  next_due_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS archive_reviews_user_due ON archive_reviews(user_id,next_due_at);
CREATE INDEX IF NOT EXISTS archive_reviews_user_reviewed ON archive_reviews(user_id,reviewed_at DESC,archive_entry_id);

CREATE TABLE IF NOT EXISTS wrong_answers (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL,
  date TEXT NOT NULL DEFAULT '',
  subject TEXT NOT NULL DEFAULT '',
  source TEXT NOT NULL DEFAULT '',
  question TEXT NOT NULL DEFAULT '',
  wrong_judgment TEXT NOT NULL DEFAULT '',
  missed_cue TEXT NOT NULL DEFAULT '',
  correction TEXT NOT NULL DEFAULT '',
  transfer TEXT NOT NULL DEFAULT '',
  bottleneck TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  score_id TEXT,
  capability_goal_id TEXT,
  archive_entry_id TEXT,
  retries_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(user_id,id)
);
CREATE INDEX IF NOT EXISTS wrong_answers_user_subject_date ON wrong_answers(user_id,subject,date DESC,id DESC);
CREATE INDEX IF NOT EXISTS wrong_answers_user_updated ON wrong_answers(user_id,updated_at DESC,id DESC);

CREATE TABLE IF NOT EXISTS learning_drills (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL,
  date TEXT NOT NULL DEFAULT '',
  subject TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL DEFAULT '',
  success_criterion TEXT NOT NULL DEFAULT '',
  minutes INTEGER NOT NULL DEFAULT 0,
  capability_goal_id TEXT,
  feedback_id TEXT,
  done INTEGER NOT NULL DEFAULT 0,
  reflection TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(user_id,id)
);
CREATE INDEX IF NOT EXISTS learning_drills_user_subject_date ON learning_drills(user_id,subject,date DESC,id DESC);
CREATE INDEX IF NOT EXISTS learning_drills_user_updated ON learning_drills(user_id,updated_at DESC,id DESC);

CREATE TABLE IF NOT EXISTS archive_wrong_answer_links (
  archive_entry_id TEXT PRIMARY KEY REFERENCES archive_entries(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  wrong_answer_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(user_id,wrong_answer_id),
  FOREIGN KEY(user_id,wrong_answer_id) REFERENCES wrong_answers(user_id,id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS archive_wrong_answers_user ON archive_wrong_answer_links(user_id,wrong_answer_id);

CREATE TABLE IF NOT EXISTS core_rule_drill_links (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  core_rule_id TEXT NOT NULL REFERENCES core_rules(id) ON DELETE CASCADE,
  drill_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(core_rule_id,drill_id),
  FOREIGN KEY(user_id,drill_id) REFERENCES learning_drills(user_id,id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS core_rule_drills_user_drill ON core_rule_drill_links(user_id,drill_id);

CREATE TABLE IF NOT EXISTS core_rule_wrong_answer_links (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  core_rule_id TEXT NOT NULL REFERENCES core_rules(id) ON DELETE CASCADE,
  wrong_answer_id TEXT NOT NULL,
  relation_type TEXT NOT NULL DEFAULT 'failed'
    CHECK(relation_type IN ('derived','applied','failed','reinforced')),
  created_at TEXT NOT NULL,
  PRIMARY KEY(core_rule_id,wrong_answer_id),
  FOREIGN KEY(user_id,wrong_answer_id) REFERENCES wrong_answers(user_id,id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS core_rule_wrong_answer_user_wrong ON core_rule_wrong_answer_links(user_id,wrong_answer_id);

CREATE TABLE IF NOT EXISTS learning_reviews (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_type TEXT NOT NULL CHECK(target_type IN ('wrong_answer','core_rule','drill','learning_item')),
  target_id TEXT NOT NULL,
  review_type TEXT NOT NULL DEFAULT 'retry',
  scheduled_at TEXT,
  reviewed_at TEXT,
  result TEXT NOT NULL DEFAULT 'pending' CHECK(result IN ('pending','success','fail')),
  notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS learning_reviews_user_target ON learning_reviews(user_id,target_type,target_id);
CREATE INDEX IF NOT EXISTS learning_reviews_user_schedule ON learning_reviews(user_id,result,scheduled_at);
CREATE INDEX IF NOT EXISTS learning_reviews_user_reviewed ON learning_reviews(user_id,target_type,target_id,reviewed_at DESC);

CREATE TABLE IF NOT EXISTS core_rule_evidence (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  core_rule_id TEXT NOT NULL REFERENCES core_rules(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL CHECK(source_type IN ('archive','wrong_answer','drill','review')),
  source_id TEXT NOT NULL,
  relation_type TEXT NOT NULL CHECK(relation_type IN ('derived','applied','failed','reinforced')),
  occurred_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(user_id,core_rule_id,source_type,source_id,relation_type)
);
CREATE INDEX IF NOT EXISTS core_rule_evidence_rule_time ON core_rule_evidence(user_id,core_rule_id,occurred_at DESC);
CREATE INDEX IF NOT EXISTS core_rule_evidence_relation_time ON core_rule_evidence(user_id,relation_type,occurred_at DESC);
CREATE INDEX IF NOT EXISTS core_rule_evidence_source ON core_rule_evidence(user_id,source_type,source_id);

CREATE TABLE IF NOT EXISTS learning_graph_user_state (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  source_updated_at TEXT NOT NULL DEFAULT '',
  projected_at TEXT NOT NULL,
  legacy_evidence_backfilled INTEGER NOT NULL DEFAULT 0
);
