# TRINITY OS Learning Graph Refactor

기준: 2026-09-18 `main`, 시작 HEAD `1dd704673db1d947b3d9561498a5215641f7fbf2` 이후에도 anchor가 유지되면 적용 가능.

## 실행

Codespaces 저장소 루트에서 압축을 푼 후:

```bash
python3 /path/to/apply_learning_graph_refactor.py --repo /workspaces/TRINITY-OS --commit --push
```

스크립트가 자동으로:
1. main / clean working tree 확인
2. `git pull origin main`
3. Learning Graph 리팩터 적용
4. `npm ci`
5. `npm test`
6. `npm run build`
7. Worker `npm ci`
8. Wrangler dry-run
9. 위 검증이 모두 성공한 경우에만 commit / push

production D1 migration/deploy는 안전상 자동 실행하지 않습니다.

## 생성되는 migration

`worker/migrations/0014_learning_graph_scale.sql`

적용:

```bash
cd /workspaces/TRINITY-OS/worker
npx wrangler d1 migrations apply trinity-os-db --remote --config wrangler.toml
npx wrangler deploy --config wrangler.toml
```

## 핵심 변경

- Archive cursor pagination: 기본 100, 최대 200
- 300개 hard cap 제거
- page 단위 Annotation/Core Rule 로딩 + Map grouping
- Backup import cap 상향 + D1 batch chunking
- `wrong_answers`, `learning_drills` relational projection
- Learning Intelligence의 Wrong Answer/Drill JSON 전체 파싱 제거(변경 시 projection)
- `core_rule_evidence` 추가
- Core Rule 통계/priority/active-rules API
- 사용자 격리와 relation ownership 검증
- `schema.sql` fresh DB Learning Archive/Graph 동기화
- Archive/Review 프론트에서 cursor 페이지를 자동 순회
- main deploy workflow에 tests + Worker dry-run gate 추가
