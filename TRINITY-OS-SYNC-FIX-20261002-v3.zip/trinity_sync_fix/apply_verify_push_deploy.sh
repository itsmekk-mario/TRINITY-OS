#!/usr/bin/env bash
set -euo pipefail

REPO="/workspaces/TRINITY-OS"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"

cd "$REPO"

if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "ERROR: 추적 중인 파일에 미커밋 변경이 있습니다. 안전을 위해 자동 적용을 중단합니다."
  echo "먼저 git status를 확인하고 커밋 또는 stash한 뒤 다시 실행하세요."
  exit 2
fi

echo "[1/9] Pull latest main"
git checkout main
git pull --ff-only origin main

echo "[2/9] Apply patch"
python3 "$PATCH_DIR/apply_fix.py"

echo "[3/9] Check diff"
git diff --check
git diff --stat

echo "[4/9] Run tests"
npm test

echo "[5/9] Build frontend"
npm run build

echo "[6/9] Worker compile dry-run"
cd worker
npm install
npx wrangler deploy --dry-run --config wrangler.toml
cd ..

echo "[7/9] Commit"
git add src/App.tsx src/lib/cloudflare.ts src/components/CloudflareSync.tsx worker/src/index.ts
git commit -m "fix: prevent sync race data loss and add safe recovery"

echo "[8/9] Push main"
git push origin main

echo "[9/9] Deploy Worker"
cd worker
npm run deploy
cd ..

echo
echo "DONE: sync race fix pushed and Worker deployed."
echo "TRINITY OS 설정 > Cloudflare 기기 간 저장 > 이전 저장본 확인에서 누락 자료·오답을 병합 복구하세요."
