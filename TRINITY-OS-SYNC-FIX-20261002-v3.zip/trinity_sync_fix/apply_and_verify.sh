#!/usr/bin/env bash
set -euo pipefail

REPO="/workspaces/TRINITY-OS"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"

cd "$REPO"
echo "[1/7] Updating main..."
git checkout main
git pull --ff-only origin main

echo "[2/7] Applying sync safety patch..."
python3 "$PATCH_DIR/apply_fix.py"

echo "[3/7] Frontend tests..."
npm test

echo "[4/7] Frontend typecheck/build..."
npm run build

echo "[5/7] Worker dry-run compile..."
cd worker
npm install
npx wrangler deploy --dry-run --config wrangler.toml
cd ..

echo "[6/7] Diff summary..."
git diff --check
git status --short
git diff --stat

echo "[7/7] Done. Review the diff, then run:"
echo "  git add src/App.tsx src/lib/cloudflare.ts src/components/CloudflareSync.tsx worker/src/index.ts"
echo "  git commit -m 'fix: prevent sync race data loss and add safe recovery'"
echo "  git push origin main"
echo "  cd worker && npm run deploy"
