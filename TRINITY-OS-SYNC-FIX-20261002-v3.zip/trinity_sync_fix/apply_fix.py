from pathlib import Path
import re
import sys

ROOT = Path.cwd()


def replace_once(path: str, old: str, new: str):
    p = ROOT / path
    text = p.read_text(encoding='utf-8')
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{path}: expected exactly 1 literal match, found {count}')
    p.write_text(text.replace(old, new, 1), encoding='utf-8')
    print(f'[ok] {path}')


def regex_replace_once(path: str, pattern: str, replacement: str):
    p = ROOT / path
    text = p.read_text(encoding='utf-8')
    new_text, count = re.subn(pattern, replacement, text, count=1, flags=re.S)
    if count != 1:
        raise RuntimeError(f'{path}: expected exactly 1 regex match, found {count}')
    p.write_text(new_text, encoding='utf-8')
    print(f'[ok] {path}')


# 1) React auto-sync: prevent stale in-flight results from overwriting newer edits,
#    and never lose a follow-up sync request while another sync is running.
replace_once(
    'src/App.tsx',
    '''  const syncing = useRef(false);\n  const scrollPositions = useRef(new Map<string, number>());''',
    '''  const syncing = useRef(false);\n  const syncPending = useRef(false);\n  const latestDataRef = useRef<AppData>(data);\n  const latestIdentityRef = useRef<SessionIdentity | null>(identity);\n  latestDataRef.current = data;\n  latestIdentityRef.current = identity;\n  const scrollPositions = useRef(new Map<string, number>());''',
)

new_sync_block = '''  const runAutoSync = async () => {\n    if (syncing.current) {\n      syncPending.current = true;\n      return;\n    }\n    syncing.current = true;\n    try {\n      do {\n        syncPending.current = false;\n        const activeIdentity = latestIdentityRef.current;\n        if (!activeIdentity) return;\n\n        const snapshot = latestDataRef.current;\n        const result = await autoSyncCloudflareData(snapshot, activeIdentity.userId);\n\n        if (latestIdentityRef.current?.userId !== activeIdentity.userId) return;\n\n        // The request started from `snapshot`. If the user edited anything while it was\n        // in flight, its response is stale and must never replace the newer local state.\n        // Reconcile the newest state immediately instead of dropping this sync request.\n        if (latestDataRef.current !== snapshot) {\n          syncPending.current = true;\n          continue;\n        }\n\n        if (result.action === "downloaded" && result.data) {\n          saveRecoveryCopy(activeIdentity.userId, snapshot);\n          saveData(activeIdentity.userId, result.data);\n          latestDataRef.current = result.data;\n          setData(result.data);\n        } else if (result.action === "conflict") {\n          saveRecoveryCopy(activeIdentity.userId, snapshot);\n          setToast(result.reason || "동기화 충돌을 감지해 자동 덮어쓰기를 중단했습니다.");\n          window.setTimeout(() => setToast(""), 5000);\n        }\n      } while (syncPending.current);\n    } catch {\n      /* Local data remains authoritative until the next retry. */\n    } finally {\n      syncing.current = false;\n    }\n  };\n  useEffect(() => {\n    if (!identity) return;\n    const timer = window.setTimeout(() => {\n      syncPending.current = true;\n      void runAutoSync();\n    }, 1500);\n    return () => window.clearTimeout(timer);\n  }, [data, identity]);\n'''

regex_replace_once(
    'src/App.tsx',
    r'''  useEffect\(\(\) => \{\n    if \(!identity\) return;\n    const timer = window\.setTimeout\(async \(\) => \{.*?\n  \}, \[data, identity\]\);\n''',
    new_sync_block,
)

# 2) Cloudflare sync library: conflict detection must be side-effect free so a stale
#    snapshot cannot overwrite the useful recovery copy. Add authenticated history APIs.
replace_once(
    'src/lib/cloudflare.ts',
    '''  const conflict = (reason: string, updatedAt = remote.updatedAt ?? null): AutoSyncResult => {\n    saveRecoveryCopy(userId, data);\n    return { action: 'conflict', updatedAt, reason };\n  };''',
    '''  const conflict = (reason: string, updatedAt = remote.updatedAt ?? null): AutoSyncResult =>\n    ({ action: 'conflict', updatedAt, reason });''',
)

history_client = r'''

export type SyncHistoryItem = {
  id: number;
  savedAt: string;
  resourceCount: number;
  wrongAnswerCount: number;
  sessionCount: number;
  scoreCount: number;
  invalid?: boolean;
};

export async function fetchCloudflareHistory(config: CloudflareConfig): Promise<SyncHistoryItem[]> {
  const { base, headers } = requestParts(config);
  const response = await fetch(`${base}/api/sync/history`, { headers, cache: 'no-store' });
  if (!response.ok) {
    let payload: { error?: string } = {};
    try { payload = await response.json() as typeof payload; } catch { /* no body */ }
    throw new Error(payload.error || `이전 저장본 조회 실패 (${response.status})`);
  }
  const payload = await response.json() as { history?: SyncHistoryItem[] };
  return Array.isArray(payload.history) ? payload.history : [];
}

export async function recoverCloudflareHistoryMissing(
  historyId: number,
  config: CloudflareConfig,
): Promise<{ data: AppData; updatedAt: string; addedResources: number; addedWrongAnswers: number }> {
  const { base, headers } = requestParts(config);
  const response = await fetch(`${base}/api/sync/history/${historyId}/recover-missing`, {
    method: 'POST',
    headers,
    body: JSON.stringify({}),
  });
  let payload: {
    error?: string;
    data?: AppData;
    updatedAt?: string;
    addedResources?: number;
    addedWrongAnswers?: number;
  } = {};
  try { payload = await response.json() as typeof payload; } catch { /* no body */ }
  if (!response.ok || !payload.data || !payload.updatedAt) {
    throw new Error(payload.error || `이전 저장본 복구 실패 (${response.status})`);
  }
  return {
    data: migratePlans(payload.data),
    updatedAt: payload.updatedAt,
    addedResources: payload.addedResources ?? 0,
    addedWrongAnswers: payload.addedWrongAnswers ?? 0,
  };
}
'''

replace_once(
    'src/lib/cloudflare.ts',
    '''export async function fetchCloudflareData(config: CloudflareConfig): Promise<RemotePayload> {\n  const { base, headers } = requestParts(config);\n  const response = await fetch(`${base}/api/sync`, { headers, cache: 'no-store' });\n  if (!response.ok) throw new Error(`Worker 연결 실패 (${response.status})`);\n  return response.json() as Promise<RemotePayload>;\n}\n''',
    '''export async function fetchCloudflareData(config: CloudflareConfig): Promise<RemotePayload> {\n  const { base, headers } = requestParts(config);\n  const response = await fetch(`${base}/api/sync`, { headers, cache: 'no-store' });\n  if (!response.ok) throw new Error(`Worker 연결 실패 (${response.status})`);\n  return response.json() as Promise<RemotePayload>;\n}\n''' + history_client,
)

# 3) Manual sync: protect the write with the exact server revision we just inspected.
#    Expose safe history recovery that only merges missing resource/wrong-answer IDs.
replace_once(
    'src/components/CloudflareSync.tsx',
    '''import { fetchCloudflareData, loadCloudflareConfig, loadRecoveryCopy, rememberCloudflareSyncBaseline, saveRecoveryCopy, uploadCloudflareData } from '../lib/cloudflare';''',
    '''import { fetchCloudflareData, fetchCloudflareHistory, loadCloudflareConfig, loadRecoveryCopy, recoverCloudflareHistoryMissing, rememberCloudflareSyncBaseline, saveRecoveryCopy, uploadCloudflareData, type SyncHistoryItem } from '../lib/cloudflare';''',
)

replace_once(
    'src/components/CloudflareSync.tsx',
    '''const countRecords = (value: AppData) => Object.keys(value.calendar).length + value.sessions.length + Object.keys(value.journals).length + value.scores.length + Object.keys(value.plaire).length + value.trinity.length;''',
    '''const countRecords = (value: AppData) => Object.keys(value.calendar).length + value.sessions.length + Object.keys(value.journals).length + value.scores.length + Object.keys(value.plaire).length + value.trinity.length + value.resources.length + value.wrongAnswerDrills.length + value.dailyDrills.length + value.weeklyCapabilityGoals.length;''',
)

replace_once(
    'src/components/CloudflareSync.tsx',
    '''  const [busy, setBusy] = useState(false);''',
    '''  const [busy, setBusy] = useState(false);\n  const [history, setHistory] = useState<SyncHistoryItem[]>([]);\n  const [historyOpen, setHistoryOpen] = useState(false);''',
)

replace_once(
    'src/components/CloudflareSync.tsx',
    '''      const saved = await uploadCloudflareData(data, config());''',
    '''      const saved = await uploadCloudflareData(data, config(), { expectedUpdatedAt: remote.updatedAt ?? null });''',
)

insert_after_upload = r'''

  const loadHistory = async () => {
    if (historyOpen) { setHistoryOpen(false); return; }
    setBusy(true); setStatus('이전 저장본을 확인하는 중…');
    try {
      setHistory(await fetchCloudflareHistory(config()));
      setHistoryOpen(true);
      setStatus('서버에 남아 있는 최근 저장본입니다. 현재 데이터는 덮어쓰지 않습니다.');
    } catch (error) { setStatus(error instanceof Error ? error.message : '이전 저장본 조회에 실패했습니다.'); }
    finally { setBusy(false); }
  };

  const recoverMissing = async (historyId: number) => {
    if (userId === undefined) { setStatus('세션을 다시 확인해 주세요.'); return; }
    if (!window.confirm('선택한 이전 저장본에서 현재 목록에 없는 자료와 오답만 추가할까요? 현재 항목은 덮어쓰지 않습니다.')) return;
    setBusy(true); setStatus('누락 항목을 복구하는 중…');
    try {
      saveRecoveryCopy(userId, data);
      const restored = await recoverCloudflareHistoryMissing(historyId, config());
      rememberCloudflareSyncBaseline(userId, restored.data, restored.updatedAt);
      update(() => restored.data);
      setStatus(`복구 완료 · 자료 ${restored.addedResources}개 · 오답 ${restored.addedWrongAnswers}개 추가`);
      setHistory(await fetchCloudflareHistory(config()));
    } catch (error) { setStatus(error instanceof Error ? error.message : '누락 항목 복구에 실패했습니다.'); }
    finally { setBusy(false); }
  };
'''

replace_once(
    'src/components/CloudflareSync.tsx',
    '''  const download = async () => {''',
    insert_after_upload + '''\n  const download = async () => {''',
)

replace_once(
    'src/components/CloudflareSync.tsx',
    '''      {recovery&&<button className="button" onClick={restore} disabled={busy}><History size={16}/>가져오기 전 데이터 복구</button>}\n      <button className="button" onClick={()=>{if(onLogout)onLogout();else void logout().finally(()=>location.reload());}} disabled={busy}><LogOut size={16}/>로그아웃</button>''',
    '''      {recovery&&<button className="button" onClick={restore} disabled={busy}><History size={16}/>가져오기 전 데이터 복구</button>}\n      <button className="button" onClick={()=>void loadHistory()} disabled={busy}><History size={16}/>{historyOpen?'이전 저장본 닫기':'이전 저장본 확인'}</button>\n      <button className="button" onClick={()=>{if(onLogout)onLogout();else void logout().finally(()=>location.reload());}} disabled={busy}><LogOut size={16}/>로그아웃</button>''',
)

replace_once(
    'src/components/CloudflareSync.tsx',
    '''    </div>{status&&<p className="drive-status">{status}</p>}\n  </div>;''',
    '''    </div>{historyOpen&&<div className="sync-history">{history.length?history.map(item=><div className="team-record" key={item.id}><span><b>{new Date(item.savedAt).toLocaleString('ko-KR')}</b><small>자료 {item.resourceCount} · 오답 {item.wrongAnswerCount} · 학습 {item.sessionCount} · 시험 {item.scoreCount}</small></span><button className="button" disabled={busy||item.invalid} onClick={()=>void recoverMissing(item.id)}>누락 자료·오답 병합</button></div>):<p className="drive-status">복구 가능한 서버 저장본이 없습니다.</p>}</div>}{status&&<p className="drive-status">{status}</p>}\n  </div>;''',
)

# 4) Worker: authenticated, user-scoped history inspection and non-destructive merge recovery.
worker_history = r'''  if (url.pathname === '/api/sync/history' && request.method === 'GET') {
    if (!auth || !user) return json({ error: 'Unauthorized' }, 401, origin);
    if (auth.authType === 'api_token' && !auth.scopes.includes('sync:read')) return json({ error: 'Token scope does not allow this operation.' }, 403, origin);
    const rows = await env.DB.prepare('SELECT id,payload,saved_at FROM learning_state_history WHERE user_id=? ORDER BY id DESC LIMIT 100').bind(user.id).all<{ id: number; payload: string; saved_at: string }>();
    const history = rows.results.map((row) => {
      try {
        const payload = JSON.parse(row.payload) as Record<string, unknown>;
        return {
          id: row.id,
          savedAt: row.saved_at,
          resourceCount: Array.isArray(payload.resources) ? payload.resources.length : 0,
          wrongAnswerCount: Array.isArray(payload.wrongAnswerDrills) ? payload.wrongAnswerDrills.length : 0,
          sessionCount: Array.isArray(payload.sessions) ? payload.sessions.length : 0,
          scoreCount: Array.isArray(payload.scores) ? payload.scores.length : 0,
        };
      } catch {
        return { id: row.id, savedAt: row.saved_at, resourceCount: 0, wrongAnswerCount: 0, sessionCount: 0, scoreCount: 0, invalid: true };
      }
    });
    return json({ history }, 200, origin);
  }
  const historyRecoveryMatch = url.pathname.match(/^\/api\/sync\/history\/(\d+)\/recover-missing$/);
  if (historyRecoveryMatch && request.method === 'POST') {
    if (!auth || !user) return json({ error: 'Unauthorized' }, 401, origin);
    if (auth.authType === 'api_token' && !auth.scopes.includes('sync:write')) return json({ error: 'Token scope does not allow this operation.' }, 403, origin);
    const historyId = Number(historyRecoveryMatch[1]);
    if (!Number.isSafeInteger(historyId) || historyId <= 0) return json({ error: '올바르지 않은 저장본 ID입니다.' }, 400, origin);
    const snapshotRow = await env.DB.prepare('SELECT payload,saved_at FROM learning_state_history WHERE user_id=? AND id=?').bind(user.id, historyId).first<{ payload: string; saved_at: string }>();
    if (!snapshotRow) return json({ error: '해당 저장본을 찾을 수 없습니다.' }, 404, origin);
    const currentRow = await env.DB.prepare('SELECT payload,updated_at FROM learning_state WHERE user_id=?').bind(user.id).first<{ payload: string; updated_at: string }>();
    if (!currentRow) return json({ error: '현재 학습 데이터가 없습니다.' }, 409, origin);

    let snapshot: unknown;
    let currentData: unknown;
    try { snapshot = JSON.parse(snapshotRow.payload); currentData = JSON.parse(currentRow.payload); }
    catch { return json({ error: '저장본 데이터가 손상되어 복구할 수 없습니다.' }, 409, origin); }
    if (!validateAppData(snapshot) || !validateAppData(currentData)) return json({ error: '저장본 데이터 형식을 확인할 수 없습니다.' }, 409, origin);

    const mergeMissingById = (currentList: unknown[], snapshotList: unknown[]) => {
      const ids = new Set(currentList.map((item) => item && typeof item === 'object' && !Array.isArray(item) ? (item as Record<string, unknown>).id : null).filter((id): id is string => typeof id === 'string'));
      const added = snapshotList.filter((item) => {
        if (!item || typeof item !== 'object' || Array.isArray(item)) return false;
        const id = (item as Record<string, unknown>).id;
        if (typeof id !== 'string' || ids.has(id)) return false;
        ids.add(id);
        return true;
      });
      return { items: [...currentList, ...added], added: added.length };
    };

    const resources = mergeMissingById(currentData.resources as unknown[], snapshot.resources as unknown[]);
    const wrongAnswers = mergeMissingById(currentData.wrongAnswerDrills as unknown[], snapshot.wrongAnswerDrills as unknown[]);
    const next = { ...currentData, resources: resources.items, wrongAnswerDrills: wrongAnswers.items };
    if (!validateAppData(next)) return json({ error: '복구 결과 데이터 형식이 올바르지 않습니다.' }, 409, origin);
    if (resources.added === 0 && wrongAnswers.added === 0) return json({ ok: true, data: currentData, updatedAt: currentRow.updated_at, addedResources: 0, addedWrongAnswers: 0 }, 200, origin);

    const now = new Date().toISOString();
    const write = await env.DB.prepare('UPDATE learning_state SET payload=?,updated_at=? WHERE user_id=? AND updated_at=?').bind(JSON.stringify(next), now, user.id, currentRow.updated_at).run();
    if ((write.meta?.changes ?? 0) !== 1) {
      const latest = await env.DB.prepare('SELECT updated_at FROM learning_state WHERE user_id=?').bind(user.id).first<{ updated_at: string }>();
      return json({ error: '복구 중 다른 기기에서 데이터가 변경되었습니다. 다시 시도해 주세요.', conflict: true, updatedAt: latest?.updated_at ?? null }, 409, origin);
    }
    await env.DB.prepare('INSERT INTO learning_state_history(user_id,payload,saved_at) VALUES(?,?,?)').bind(user.id, currentRow.payload, now).run();
    await syncLearningProjection(env.DB, user.id, next, now);
    await env.DB.prepare('DELETE FROM learning_state_history WHERE user_id=? AND id NOT IN (SELECT id FROM learning_state_history WHERE user_id=? ORDER BY id DESC LIMIT 100)').bind(user.id, user.id).run();
    return json({ ok: true, data: next, updatedAt: now, addedResources: resources.added, addedWrongAnswers: wrongAnswers.added }, 200, origin);
  }
'''

replace_once(
    'worker/src/index.ts',
    '''  if (url.pathname !== '/api/sync' || !['GET', 'PUT'].includes(request.method)) return json({ error: 'Not found' }, 404, origin);''',
    worker_history + '''  if (url.pathname !== '/api/sync' || !['GET', 'PUT'].includes(request.method)) return json({ error: 'Not found' }, 404, origin);''',
)

replace_once(
    'worker/src/index.ts',
    '''  await env.DB.prepare('DELETE FROM learning_state_history WHERE user_id=? AND id NOT IN (SELECT id FROM learning_state_history WHERE user_id=? ORDER BY id DESC LIMIT 20)').bind(user.id, user.id).run();''',
    '''  await env.DB.prepare('DELETE FROM learning_state_history WHERE user_id=? AND id NOT IN (SELECT id FROM learning_state_history WHERE user_id=? ORDER BY id DESC LIMIT 100)').bind(user.id, user.id).run();''',
)

print('\nTRINITY OS sync race/recovery patch applied successfully.')
