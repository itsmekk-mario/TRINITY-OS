# TRINITY OS — sync race + recovery fix

대상: `itsmekk-mario/TRINITY-OS` 최신 `main` (2026-10-02 기준)

## 수정 내용

1. **in-flight 자동 동기화 race condition 차단**
   - 동기화 요청이 시작된 뒤 사용자가 새 데이터를 입력하면, 오래된 응답이 최신 상태를 덮지 못하게 합니다.
   - 동기화 중 발생한 추가 변경은 누락시키지 않고 즉시 다음 동기화 루프로 넘깁니다.

2. **수동 서버 저장에도 CAS 적용**
   - 서버 상태 조회 뒤 다른 기기에서 서버가 변경되면 `409`로 차단합니다.
   - `resources`/`wrongAnswerDrills`도 수동 저장 경고의 레코드 수에 포함합니다.

3. **D1 history 기반 비파괴 복구**
   - 설정의 Cloudflare 동기화 영역에서 `이전 저장본 확인`을 제공합니다.
   - 선택한 snapshot에서 현재 목록에 **없는 ID의 자료와 오답만** 추가합니다.
   - 현재 항목은 수정/삭제/덮어쓰기하지 않습니다.

4. **D1 history 보존 20 → 100**

## 적용

ZIP을 Codespaces에 올리고 압축 해제한 뒤, 전체 자동 적용은 다음 스크립트를 실행합니다.

```bash
bash /workspaces/trinity_sync_fix/apply_verify_push_deploy.sh
```

이 스크립트는 `git pull → 패치 → 테스트 → 프론트 빌드 → Worker dry-run → commit → push → Worker deploy`까지 수행합니다.

검증만 하고 직접 커밋하려면 `apply_and_verify.sh`를 사용합니다.

## 기존 유실 데이터 복구

Worker 배포 후 TRINITY OS → 설정 → Cloudflare 기기 간 저장 → **이전 저장본 확인**에서
10월 1일 전후 snapshot을 선택해 **누락 자료·오답 병합**을 누릅니다.

이 복구는 현재 데이터를 과거 snapshot 전체로 되돌리지 않고 `resources`, `wrongAnswerDrills`의 누락 ID만 추가합니다.
