# TRINITY OS — Tutor Simple Workspace

목표: subject_teacher(수학 과외 선생님 포함) 화면을 4개만 남긴 경량 UI로 변경합니다.

- 오답
- Core Rule
- Learning Archive
- Feedback (기본 탭)

Feedback 입력은 다음 4개뿐입니다.

1. 오늘 관찰한 태도
2. 잘하고 있는 점
3. 다음 수업까지 가져갈 태도
4. 태도 태그

## 적용

현재 ChatGPT의 GitHub 연결은 이 저장소에 대해 읽기 전용이라 직접 push하지 못했습니다.

1. `src/components/teacher/TutorWorkspace.tsx`를 프로젝트의 같은 경로에 추가
2. `apply.patch`의 CollaborativePortal 변경을 적용
3. `team.css.append.css` 내용을 `src/team.css` 맨 아래에 추가
4. 선택: `tests/tutor-workspace.test.mjs` 추가
5. 실행
   - `npm test`
   - `npm run build`
6. 성공하면 commit/push

권장 커밋 메시지:

`feat: simplify tutor workspace around learning feedback`

주의:
- academic_manager 화면은 그대로 유지합니다.
- subject_teacher만 새 4탭 UI를 사용합니다.
- 백엔드 스키마 변경은 없습니다.
- 기존 `/api/collab/students/:id/data`, `/feedback`, `/archive` API를 재사용합니다.
