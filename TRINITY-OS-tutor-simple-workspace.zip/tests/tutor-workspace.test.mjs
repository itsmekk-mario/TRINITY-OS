import assert from 'node:assert/strict';
import {test} from 'node:test';
import {readFileSync} from 'node:fs';

const tutor=readFileSync(new URL('../src/components/teacher/TutorWorkspace.tsx',import.meta.url),'utf8');
const portal=readFileSync(new URL('../src/pages/CollaborativePortal.tsx',import.meta.url),'utf8');

test('Tutor workspace is intentionally limited to four surfaces',()=>{
  for(const label of ['오답','Core Rule','Learning Archive','Feedback']) assert.match(tutor,new RegExp(label));
  assert.match(tutor,/useState<Tab>\('feedback'\)/);
});

test('Tutor feedback focuses on lesson attitude',()=>{
  assert.match(tutor,/오늘 관찰한 태도/);
  assert.match(tutor,/잘하고 있는 점/);
  assert.match(tutor,/다음 수업까지 가져갈 태도/);
  assert.match(tutor,/피드백 발송/);
});

test('Subject teacher uses the lightweight tutor workspace',()=>{
  assert.match(portal,/role==='subject_teacher'/);
  assert.match(portal,/TutorWorkspace/);
});
