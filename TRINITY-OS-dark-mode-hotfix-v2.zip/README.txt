TRINITY OS dark mode hotfix v2

이 패치는 src/theme-dark.css만 교체합니다.

수정:
- Light Overview를 다시 카드화하던 전역 .card override 제거
- Dark Overview도 기존 borderless hierarchy 유지
- Calendar 날짜 셀/hover/entry/study time을 dark surface로 개별 대응
- modal 및 일부 legacy white surface만 targeted override
- display / padding / overflow / line-clamp 등 레이아웃 속성은 변경하지 않음

적용:
unzip -o TRINITY-OS-dark-mode-hotfix-v2.zip -d /workspaces/TRINITY-OS
cd /workspaces/TRINITY-OS
npm run build
