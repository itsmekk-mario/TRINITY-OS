import { readFile, writeFile } from 'node:fs/promises';

const scoreTrackerPath = 'src/pages/ScoreTracker.tsx';
const orderingCssPath = 'src/ordering.css';

let source = await readFile(scoreTrackerPath, 'utf8');

if (source.includes('const startEdit = (entry: ScoreEntry) =>')) {
  console.log('Mock exam edit patch is already applied.');
  process.exit(0);
}

function replaceOnce(from, to, label) {
  if (!source.includes(from)) {
    throw new Error(`${label}: expected source block not found. Run git pull origin main and retry.`);
  }
  source = source.replace(from, to);
}

replaceOnce(
  "import { BarChart3, ChevronDown, Plus, Trash2, TrendingUp, X } from 'lucide-react';",
  "import { BarChart3, ChevronDown, Pencil, Plus, Trash2, TrendingUp, X } from 'lucide-react';",
  'lucide import',
);

replaceOnce(
  "  const bottleneckMax = Math.max(...bottleneckItems.map(([, count]) => count), 1);\n  const setReview =",
  `  const bottleneckMax = Math.max(...bottleneckItems.map(([, count]) => count), 1);\n  const closeEditor = () => { setOpen(false); setDraft(blank()); setFormError(''); };\n  const startCreate = () => { setDraft(blank()); setFormError(''); setOpen(true); };\n  const startEdit = (entry: ScoreEntry) => {\n    setDraft({\n      ...entry,\n      reviews: {\n        국어: { ...emptyReview(), ...reviewOf(entry, '국어') },\n        수학: { ...emptyReview(), ...reviewOf(entry, '수학') },\n        영어: { ...emptyReview(), ...reviewOf(entry, '영어') },\n      },\n      overallReview: entry.overallReview ?? '',\n    });\n    setFormError('');\n    setOpen(true);\n  };\n  const setReview =`,
  'editor helpers',
);

replaceOnce(
  `  const save = () => {\n    const reviews = draft.reviews ?? {}; const hasScore = SCORE_SUBJECTS.some((item) => typeof reviews[item]?.score === 'number');\n    if (!draft.name.trim() || !hasScore) { setFormError('실모명과 최소 한 과목의 점수를 입력하세요.'); return; }\n    update((value) => ({ ...value, scores: [{ ...draft, id: uid(), name: draft.name.trim(), subject: '국어', korean: reviews.국어?.score, math: reviews.수학?.score, english: reviews.영어?.score, duration: SCORE_SUBJECTS.reduce((sum, item) => sum + (reviews[item]?.duration ?? 0), 0) }, ...value.scores] })); setDraft(blank()); setFormError(''); setOpen(false);\n  };`,
  `  const save = () => {\n    const reviews = draft.reviews ?? {}; const hasScore = SCORE_SUBJECTS.some((item) => typeof reviews[item]?.score === 'number');\n    if (!draft.name.trim() || !hasScore) { setFormError('실모명과 최소 한 과목의 점수를 입력하세요.'); return; }\n    const saved: ScoreEntry = { ...draft, id: draft.id || uid(), name: draft.name.trim(), subject: '국어', korean: reviews.국어?.score, math: reviews.수학?.score, english: reviews.영어?.score, duration: SCORE_SUBJECTS.reduce((sum, item) => sum + (reviews[item]?.duration ?? 0), 0) };\n    update((value) => ({ ...value, scores: draft.id ? value.scores.map((item) => item.id === draft.id ? saved : item) : [saved, ...value.scores] }));\n    closeEditor();\n  };`,
  'save behavior',
);

replaceOnce(
  `action={<button className="button primary" onClick={() => setOpen(true)}><Plus size={17} /> 실모 기록</button>}`,
  `action={<button className="button primary" onClick={startCreate}><Plus size={17} /> 실모 기록</button>}`,
  'new record button',
);

replaceOnce(
  `<button className="icon-button danger" onClick={() => remove(score.id)} aria-label="삭제"><Trash2 size={17} /></button>`,
  `<div className="mock-record-actions"><button className="icon-button" onClick={() => startEdit(score)} aria-label="수정" title="실모 분석 수정"><Pencil size={17} /></button><button className="icon-button danger" onClick={() => remove(score.id)} aria-label="삭제"><Trash2 size={17} /></button></div>`,
  'record actions',
);

replaceOnce(
  `{open && <div className="modal-backdrop" onClick={() => setOpen(false)}><div className="modal mock-modal" onClick={(e) => e.stopPropagation()}><div className="modal-head"><div><p className="eyebrow">NEW MOCK EXAM</p><h2>실모 기록</h2></div><button onClick={() => setOpen(false)}><X /></button></div>`,
  `{open && <div className="modal-backdrop" onClick={closeEditor}><div className="modal mock-modal" onClick={(e) => e.stopPropagation()}><div className="modal-head"><div><p className="eyebrow">{draft.id ? 'EDIT MOCK EXAM' : 'NEW MOCK EXAM'}</p><h2>{draft.id ? '실모 분석 수정' : '실모 기록'}</h2></div><button onClick={closeEditor}><X /></button></div>`,
  'modal mode',
);

replaceOnce(
  `<SaveButton onClick={save} label="실모 분석 저장" />`,
  `<SaveButton onClick={save} label={draft.id ? '수정 내용 저장' : '실모 분석 저장'} />`,
  'save label',
);

await writeFile(scoreTrackerPath, source);

let css = await readFile(orderingCssPath, 'utf8');
if (!css.includes('.mock-record-actions{')) {
  css += `\n/* Mock exam record edit actions */\n.mock-record-actions{display:flex;align-items:center;gap:4px;flex-shrink:0}\n`;
  await writeFile(orderingCssPath, css);
}

console.log('Applied: mock exam records can now be edited without changing their scoreId.');
