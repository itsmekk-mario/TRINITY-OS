import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../src/pages/ScoreTracker.tsx', import.meta.url), 'utf8');

test('saved mock exam analyses expose an edit action', () => {
  assert.match(source, /startEdit\(score\)/);
  assert.match(source, /Pencil size=\{17\}/);
  assert.match(source, /실모 분석 수정/);
});

test('editing preserves the original score id and replaces the existing entry', () => {
  assert.match(source, /id: draft\.id \|\| uid\(\)/);
  assert.match(source, /draft\.id \? value\.scores\.map/);
  assert.match(source, /item\.id === draft\.id \? saved : item/);
});

test('editing hydrates modern fields from legacy mock exam records', () => {
  for (const subject of ['국어', '수학', '영어']) {
    assert.ok(source.includes(`...reviewOf(entry, '${subject}')`));
  }
});
