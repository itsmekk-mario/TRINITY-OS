# TRINITY OS — 실모 분석 수정 기능 패치

현재 GitHub `main`을 먼저 pull한 뒤 적용하는 패치입니다.

## 변경점

- 저장된 모든 실모 카드에 `수정` 버튼 추가
- 기존 시험명 / 날짜 / 점수 / 시험 시간 / 오답문항 / 객관화 / 개선방향 / 총평을 편집 가능
- 과거 legacy 실모 기록도 편집창에서 현재 reviews 구조로 자동 변환해 표시
- 수정 저장 시 기존 `ScoreEntry.id` 유지
- 따라서 기존 `WrongAnswerDrill.scoreId` 연결 유지
- 수정 후 점수 추이 그래프와 목록이 즉시 갱신
- 신규 기록과 수정 모달을 명확히 구분

## Codespaces 적용

```bash
git checkout main
git pull --ff-only origin main
unzip -o TRINITY-OS-mock-exam-edit-20260927.zip -d .
node apply-mock-exam-edit.mjs
npm ci
npm test
npm run build
git status
git diff -- src/pages/ScoreTracker.tsx src/ordering.css tests/mock-exam-edit.test.mjs
git add src/pages/ScoreTracker.tsx src/ordering.css tests/mock-exam-edit.test.mjs
git commit -m "feat: allow editing mock exam analyses"
git push origin main
```

`main` push 후 `.github/workflows/deploy.yml`이 GitHub Pages 배포를 자동 실행합니다. 이번 패치는 프론트엔드 데이터 편집 로직만 바꾸므로 Worker 재배포는 필요하지 않습니다.

## 확인

1. Test → 실모 기록에서 기존 기록 하나를 연다.
2. 우측 연필 아이콘을 누른다.
3. 기존 분석 내용이 그대로 채워지는지 확인한다.
4. 점수 또는 분석 내용을 수정해 저장한다.
5. 새 카드가 중복 생성되지 않고 기존 카드가 갱신되는지 확인한다.
6. 해당 실모에 연결된 오답 Drill 개수가 그대로 유지되는지 확인한다.
